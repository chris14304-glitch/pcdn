# Public Cyber Defense Network — Image Metadata Analyzer

A desktop GUI tool for extracting, viewing, downloading, and scrubbing metadata from images.

---

## Requirements

- Python 3.8 or higher
- The following Python packages:

| Package | Purpose |
|---|---|
| `pillow` | Image reading and metadata scrubbing |
| `pillow-heif` | HEIC / HEIF format support |
| `exifread` | Deep EXIF tag extraction |
| `tkinterdnd2` | Drag-and-drop support *(optional but recommended)* |

Install all at once:

```bash
pip install pillow pillow-heif exifread tkinterdnd2
```

If `tkinterdnd2` is not installed, the app still works fully — drag-and-drop will simply be disabled and you can use the **Add Files / Folder** button instead.

---

## Supported Image Formats

`.jpg` `.jpeg` `.png` `.heic` `.heif` `.tiff` `.bmp` `.webp`

---

## How to Run

```bash
python "Image Metadata GUI.py"
```

Or double-click the file if your system is configured to open `.py` files with Python.

---

## Using the App

### Loading Images

You have three ways to load images:

1. **Drag & Drop** — drag one image, multiple images, or an entire folder directly onto the drop zone at the top of the window.
2. **Add Files / Folder button** — opens a dialog asking whether you want to select a folder or individual files.
3. **Click the drop zone** — same as the button above.

Only supported image formats will be loaded; unsupported files are silently skipped.

---

### Viewing Metadata

- All loaded images appear in the **file list** on the left.
- Click any filename to display its metadata in the panel on the right.
- Metadata is organized into two collapsible sections:
  - **Basic Info** — file format, color mode, pixel dimensions
  - **EXIF Data** — camera make/model, GPS coordinates, timestamps, lens info, and all other embedded EXIF tags

---

### Downloading Metadata

1. Click **Download Metadata** in the bottom-right corner.
2. Choose an export format:
   - **JSON** — structured file, one entry per image; good for programmatic use
   - **Plain Text** — human-readable report covering all loaded images
   - **CSV** — spreadsheet-friendly, one row per tag
3. Choose a save location and filename.

The export always includes **all loaded images**, not just the currently selected one.

---

### Scrubbing Metadata

Scrubbing creates **clean copies** of your images with all embedded metadata removed. Your original files are never modified.

1. Load the images you want to clean.
2. Click **Scrub Metadata**.
3. Confirm the prompt.
4. Clean copies are saved in the **same folder** as each original, named `<original name>_clean.<ext>`.
   - Example: `photo.jpg` → `photo_clean.jpg`

---

### Clearing the List

Click **Clear All** to remove all loaded images and reset the viewer.

---

## File Overview

| File | Description |
|---|---|
| `Image Metadata GUI.py` | Main GUI application — run this file |
| `Image Metadata Analysis Tool.py` | Original command-line script |
| `README.md` | This file |

---

## Notes

- Metadata extraction runs in a background thread so the interface stays responsive with large batches.
- HEIC/HEIF files (common from iPhones) are fully supported via `pillow-heif`.
- GPS coordinates, if present, will appear in the EXIF section under tags like `GPS GPSLatitude` and `GPS GPSLongitude`.
- Some images (especially PNGs) carry little or no EXIF data — this is normal.
