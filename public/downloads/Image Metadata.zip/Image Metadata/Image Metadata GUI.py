import os
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading

from PIL import Image
import pillow_heif
import exifread

# Enable HEIC/HEIF support
pillow_heif.register_heif_opener()

# Try to import tkinterdnd2 for drag-and-drop support
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_AVAILABLE = False

SUPPORTED_EXT = (".jpg", ".jpeg", ".png", ".heic", ".heif", ".tiff", ".bmp", ".webp")

# ── Metadata extraction (returns dicts instead of printing) ──────────────────

def extract_basic_info(image_path):
    info = {}
    try:
        with Image.open(image_path) as img:
            info["File"] = image_path
            info["Format"] = img.format or "Unknown"
            info["Mode"] = img.mode
            info["Width"] = img.width
            info["Height"] = img.height
            info["Size (pixels)"] = f"{img.width} x {img.height}"
    except Exception as e:
        info["Basic Info Error"] = str(e)
    return info


def extract_exif_data(image_path):
    exif = {}
    try:
        with open(image_path, "rb") as f:
            tags = exifread.process_file(f, details=False)
        for tag, value in tags.items():
            exif[tag] = str(value)
    except Exception as e:
        exif["EXIF Error"] = str(e)
    return exif


def get_all_metadata(image_path):
    basic = extract_basic_info(image_path)
    exif = extract_exif_data(image_path)
    return {"basic": basic, "exif": exif}


def scrub_image(input_path, output_path=None):
    """Return (success: bool, message: str, output_path: str|None)"""
    try:
        with Image.open(input_path) as img:
            data = list(img.getdata())
            clean = Image.new(img.mode, img.size)
            clean.putdata(data)
            if not output_path:
                name, ext = os.path.splitext(input_path)
                output_path = f"{name}_clean{ext}"
            clean.save(output_path)
        return True, f"Saved: {output_path}", output_path
    except Exception as e:
        return False, str(e), None


# ── GUI ──────────────────────────────────────────────────────────────────────

DARK_BG       = "#1e1e2e"
PANEL_BG      = "#2a2a3e"
ACCENT        = "#7c6af7"
ACCENT_HOVER  = "#6a58e0"
TEXT_COLOR    = "#cdd6f4"
MUTED         = "#6c7086"
SUCCESS       = "#a6e3a1"
DANGER        = "#f38ba8"
BORDER        = "#45475a"
DROP_ACTIVE   = "#313244"


class ImageMetadataApp(tk.Tk if not DND_AVAILABLE else TkinterDnD.Tk):
    def __init__(self):
        super().__init__()
        self.title("Public Cyber Defense Network")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(bg=DARK_BG)

        # State
        self.image_metadata = {}   # path -> {basic, exif}
        self.image_list_order = [] # ordered list of paths
        self.selected_path = None

        self._build_ui()
        self._apply_styles()

        if DND_AVAILABLE:
            self._setup_dnd()

    # ── UI construction ──────────────────────────────────────────────────────

    def _build_ui(self):
        # ── Top bar ──────────────────────────────────────────────────────────
        top = tk.Frame(self, bg=DARK_BG, pady=10, padx=16)
        top.pack(fill="x")

        tk.Label(
            top, text="Image Metadata Analyzer",
            bg=DARK_BG, fg=TEXT_COLOR,
            font=("Segoe UI", 16, "bold")
        ).pack(side="left")

        # Buttons (right side of top bar)
        btn_frame = tk.Frame(top, bg=DARK_BG)
        btn_frame.pack(side="right")

        self.btn_add = self._make_button(btn_frame, "Add Files / Folder", self._browse, ACCENT)
        self.btn_add.pack(side="left", padx=4)

        self.btn_clear = self._make_button(btn_frame, "Clear All", self._clear_all, MUTED)
        self.btn_clear.pack(side="left", padx=4)

        # ── Drop zone ────────────────────────────────────────────────────────
        drop_outer = tk.Frame(self, bg=DARK_BG, padx=16)
        drop_outer.pack(fill="x")

        self.drop_frame = tk.Frame(
            drop_outer, bg=PANEL_BG,
            highlightbackground=BORDER, highlightthickness=1,
            height=90, cursor="hand2"
        )
        self.drop_frame.pack(fill="x")
        self.drop_frame.pack_propagate(False)

        self.drop_label = tk.Label(
            self.drop_frame,
            text="⬇  Drag & drop images or folders here  ⬇\n(or use Add Files / Folder above)",
            bg=PANEL_BG, fg=MUTED,
            font=("Segoe UI", 11),
            justify="center"
        )
        self.drop_label.place(relx=0.5, rely=0.5, anchor="center")

        # Make the whole drop zone clickable as a fallback
        self.drop_frame.bind("<Button-1>", lambda e: self._browse())
        self.drop_label.bind("<Button-1>", lambda e: self._browse())

        # ── Main body (left list + right metadata) ───────────────────────────
        body = tk.Frame(self, bg=DARK_BG, padx=16, pady=8)
        body.pack(fill="both", expand=True)

        # Left panel – file list
        left = tk.Frame(body, bg=PANEL_BG, width=240,
                        highlightbackground=BORDER, highlightthickness=1)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        tk.Label(left, text="Loaded Images", bg=PANEL_BG, fg=MUTED,
                 font=("Segoe UI", 9, "bold"), padx=8, pady=6).pack(anchor="w")

        list_frame = tk.Frame(left, bg=PANEL_BG)
        list_frame.pack(fill="both", expand=True)

        self.file_listbox = tk.Listbox(
            list_frame, bg=PANEL_BG, fg=TEXT_COLOR,
            selectbackground=ACCENT, selectforeground="#ffffff",
            activestyle="none", borderwidth=0, highlightthickness=0,
            font=("Segoe UI", 9), relief="flat", exportselection=False
        )
        self.file_listbox.pack(side="left", fill="both", expand=True)

        list_scroll = tk.Scrollbar(list_frame, orient="vertical",
                                   command=self.file_listbox.yview,
                                   bg=PANEL_BG, troughcolor=PANEL_BG)
        list_scroll.pack(side="right", fill="y")
        self.file_listbox.config(yscrollcommand=list_scroll.set)
        self.file_listbox.bind("<<ListboxSelect>>", self._on_file_select)

        # Right panel – metadata display
        right = tk.Frame(body, bg=PANEL_BG,
                         highlightbackground=BORDER, highlightthickness=1)
        right.pack(side="left", fill="both", expand=True)

        # Metadata header
        meta_top = tk.Frame(right, bg=PANEL_BG, padx=10, pady=6)
        meta_top.pack(fill="x")

        self.meta_title = tk.Label(
            meta_top, text="Select an image to view metadata",
            bg=PANEL_BG, fg=TEXT_COLOR, font=("Segoe UI", 10, "bold")
        )
        self.meta_title.pack(side="left")

        # Metadata tree
        tree_frame = tk.Frame(right, bg=PANEL_BG)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        self.tree = ttk.Treeview(
            tree_frame, columns=("value",), show="tree headings",
            selectmode="browse"
        )
        self.tree.heading("#0", text="Tag")
        self.tree.heading("value", text="Value")
        self.tree.column("#0", width=280, minwidth=140, stretch=True)
        self.tree.column("value", width=400, minwidth=120, stretch=True)

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        # ── Bottom action bar ────────────────────────────────────────────────
        bottom = tk.Frame(self, bg=DARK_BG, padx=16, pady=10)
        bottom.pack(fill="x", side="bottom")

        self.status_var = tk.StringVar(value="Ready – no images loaded.")
        tk.Label(bottom, textvariable=self.status_var,
                 bg=DARK_BG, fg=MUTED, font=("Segoe UI", 9)).pack(side="left")

        right_btns = tk.Frame(bottom, bg=DARK_BG)
        right_btns.pack(side="right")

        self.btn_download = self._make_button(
            right_btns, "Download Metadata", self._download_metadata, ACCENT
        )
        self.btn_download.pack(side="left", padx=4)

        self.btn_scrub = self._make_button(
            right_btns, "Scrub Metadata", self._scrub_images, DANGER
        )
        self.btn_scrub.pack(side="left", padx=4)

    def _make_button(self, parent, text, command, color):
        btn = tk.Button(
            parent, text=text, command=command,
            bg=color, fg="#ffffff", activebackground=ACCENT_HOVER,
            activeforeground="#ffffff", relief="flat", padx=14, pady=6,
            font=("Segoe UI", 9, "bold"), cursor="hand2", borderwidth=0
        )
        btn.bind("<Enter>", lambda e, b=btn, c=color: b.config(bg=self._darken(c)))
        btn.bind("<Leave>", lambda e, b=btn, c=color: b.config(bg=c))
        return btn

    @staticmethod
    def _darken(hex_color):
        """Return a slightly darker shade of a hex color."""
        hex_color = hex_color.lstrip("#")
        r, g, b = (int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        r, g, b = max(0, r - 20), max(0, g - 20), max(0, b - 20)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _apply_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview",
                         background=PANEL_BG, foreground=TEXT_COLOR,
                         fieldbackground=PANEL_BG, borderwidth=0,
                         font=("Segoe UI", 9), rowheight=24)
        style.configure("Treeview.Heading",
                         background=DARK_BG, foreground=MUTED,
                         font=("Segoe UI", 9, "bold"), borderwidth=0)
        style.map("Treeview",
                  background=[("selected", ACCENT)],
                  foreground=[("selected", "#ffffff")])
        style.configure("Vertical.TScrollbar",
                         background=PANEL_BG, troughcolor=DARK_BG,
                         arrowcolor=MUTED, borderwidth=0)
        style.configure("Horizontal.TScrollbar",
                         background=PANEL_BG, troughcolor=DARK_BG,
                         arrowcolor=MUTED, borderwidth=0)

    # ── Drag-and-drop ────────────────────────────────────────────────────────

    def _setup_dnd(self):
        self.drop_target_register(DND_FILES)
        self.dnd_bind("<<Drop>>", self._on_drop)
        self.drop_frame.drop_target_register(DND_FILES)
        self.drop_frame.dnd_bind("<<Drop>>", self._on_drop)
        self.drop_frame.dnd_bind("<<DragEnter>>", self._on_drag_enter)
        self.drop_frame.dnd_bind("<<DragLeave>>", self._on_drag_leave)

    def _on_drag_enter(self, event):
        self.drop_frame.config(bg=DROP_ACTIVE)
        self.drop_label.config(bg=DROP_ACTIVE)

    def _on_drag_leave(self, event):
        self.drop_frame.config(bg=PANEL_BG)
        self.drop_label.config(bg=PANEL_BG)

    def _on_drop(self, event):
        self.drop_frame.config(bg=PANEL_BG)
        self.drop_label.config(bg=PANEL_BG)
        # tkinterdnd2 returns paths space-separated; braces used for paths with spaces
        raw = event.data
        paths = self._parse_drop_paths(raw)
        self._load_paths(paths)

    @staticmethod
    def _parse_drop_paths(raw):
        """Parse the DnD data string into a list of file/folder paths."""
        paths = []
        raw = raw.strip()
        # Paths with spaces are wrapped in {}
        import re
        for match in re.finditer(r'\{([^}]+)\}|(\S+)', raw):
            paths.append(match.group(1) or match.group(2))
        return paths

    # ── File loading ─────────────────────────────────────────────────────────

    def _browse(self):
        choice = messagebox.askquestion(
            "Add Images",
            "Do you want to add a FOLDER?\n\n"
            "Yes = select a folder\nNo = select individual files",
            icon="question"
        )
        if choice == "yes":
            folder = filedialog.askdirectory(title="Select Image Folder")
            if folder:
                self._load_paths([folder])
        else:
            files = filedialog.askopenfilenames(
                title="Select Images",
                filetypes=[
                    ("Image files", "*.jpg *.jpeg *.png *.heic *.heif *.tiff *.bmp *.webp"),
                    ("All files", "*.*")
                ]
            )
            if files:
                self._load_paths(list(files))

    def _load_paths(self, paths):
        collected = []
        for path in paths:
            if os.path.isdir(path):
                for fname in os.listdir(path):
                    if fname.lower().endswith(SUPPORTED_EXT):
                        collected.append(os.path.join(path, fname))
            elif os.path.isfile(path) and path.lower().endswith(SUPPORTED_EXT):
                collected.append(path)

        if not collected:
            self._set_status("No supported image files found in the dropped items.", error=True)
            return

        new_count = 0
        for p in collected:
            if p not in self.image_metadata:
                self.image_metadata[p] = None  # placeholder until extracted
                self.image_list_order.append(p)
                self.file_listbox.insert("end", os.path.basename(p))
                new_count += 1

        self._set_status(f"Added {new_count} image(s). Extracting metadata…")
        threading.Thread(target=self._extract_all, daemon=True).start()

    def _extract_all(self):
        for path in self.image_list_order:
            if self.image_metadata[path] is None:
                self.image_metadata[path] = get_all_metadata(path)
        total = len(self.image_list_order)
        self.after(0, lambda: self._set_status(
            f"{total} image(s) loaded. Select one to view metadata."
        ))
        # Auto-select first item if none selected
        if self.selected_path is None and self.image_list_order:
            self.after(0, lambda: self._display_metadata(self.image_list_order[0]))

    # ── Metadata display ─────────────────────────────────────────────────────

    def _on_file_select(self, event):
        sel = self.file_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        path = self.image_list_order[idx]
        self._display_metadata(path)

    def _display_metadata(self, path):
        self.selected_path = path
        self.tree.delete(*self.tree.get_children())

        meta = self.image_metadata.get(path)
        if not meta:
            return

        self.meta_title.config(text=os.path.basename(path))

        # Basic info section
        basic_node = self.tree.insert("", "end", text="Basic Info", open=True)
        for k, v in meta.get("basic", {}).items():
            self.tree.insert(basic_node, "end", text=k, values=(v,))

        # EXIF section
        exif = meta.get("exif", {})
        exif_node = self.tree.insert(
            "", "end",
            text=f"EXIF Data ({len(exif)} tag(s))",
            open=bool(exif)
        )
        if exif:
            for k, v in exif.items():
                self.tree.insert(exif_node, "end", text=k, values=(v,))
        else:
            self.tree.insert(exif_node, "end", text="No EXIF metadata found", values=("",))

    # ── Download ─────────────────────────────────────────────────────────────

    def _download_metadata(self):
        if not self.image_metadata:
            messagebox.showwarning("No Data", "No images loaded yet.")
            return

        fmt = self._ask_export_format()
        if not fmt:
            return

        file_types = {
            "json": [("JSON file", "*.json")],
            "txt":  [("Text file", "*.txt")],
            "csv":  [("CSV file", "*.csv")],
        }
        save_path = filedialog.asksaveasfilename(
            title="Save Metadata",
            defaultextension=f".{fmt}",
            filetypes=file_types[fmt]
        )
        if not save_path:
            return

        try:
            if fmt == "json":
                self._export_json(save_path)
            elif fmt == "txt":
                self._export_txt(save_path)
            elif fmt == "csv":
                self._export_csv(save_path)
            self._set_status(f"Metadata exported: {save_path}")
            messagebox.showinfo("Exported", f"Metadata saved to:\n{save_path}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    def _ask_export_format(self):
        dialog = tk.Toplevel(self)
        dialog.title("Export Format")
        dialog.configure(bg=DARK_BG)
        dialog.resizable(False, False)
        dialog.grab_set()

        # Center over main window
        self.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 280) // 2
        y = self.winfo_y() + (self.winfo_height() - 160) // 2
        dialog.geometry(f"280x160+{x}+{y}")

        tk.Label(dialog, text="Choose export format:",
                 bg=DARK_BG, fg=TEXT_COLOR, font=("Segoe UI", 10)).pack(pady=(18, 10))

        chosen = tk.StringVar(value="")

        btn_frame = tk.Frame(dialog, bg=DARK_BG)
        btn_frame.pack()

        for fmt, label in [("json", "JSON"), ("txt", "Plain Text"), ("csv", "CSV")]:
            def pick(f=fmt):
                chosen.set(f)
                dialog.destroy()
            tk.Button(
                btn_frame, text=label, command=pick,
                bg=ACCENT, fg="#fff", relief="flat",
                padx=10, pady=5, font=("Segoe UI", 9, "bold"),
                cursor="hand2"
            ).pack(side="left", padx=5)

        tk.Button(dialog, text="Cancel", command=dialog.destroy,
                  bg=MUTED, fg="#fff", relief="flat",
                  padx=10, pady=4, font=("Segoe UI", 9),
                  cursor="hand2").pack(pady=10)

        dialog.wait_window()
        return chosen.get() or None

    def _export_json(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.image_metadata, f, indent=2, default=str)

    def _export_txt(self, path):
        lines = []
        for img_path, meta in self.image_metadata.items():
            lines.append("=" * 60)
            lines.append(f"File: {img_path}")
            lines.append("=" * 60)
            lines.append("[ Basic Info ]")
            for k, v in meta.get("basic", {}).items():
                lines.append(f"  {k}: {v}")
            lines.append("[ EXIF Data ]")
            exif = meta.get("exif", {})
            if exif:
                for k, v in exif.items():
                    lines.append(f"  {k}: {v}")
            else:
                lines.append("  No EXIF metadata found.")
            lines.append("")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _export_csv(self, path):
        import csv
        rows = []
        for img_path, meta in self.image_metadata.items():
            fname = os.path.basename(img_path)
            for k, v in meta.get("basic", {}).items():
                rows.append([fname, "Basic", k, v])
            for k, v in meta.get("exif", {}).items():
                rows.append([fname, "EXIF", k, v])
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Filename", "Category", "Tag", "Value"])
            writer.writerows(rows)

    # ── Scrub ────────────────────────────────────────────────────────────────

    def _scrub_images(self):
        if not self.image_metadata:
            messagebox.showwarning("No Images", "No images loaded yet.")
            return

        confirm = messagebox.askyesno(
            "Scrub Metadata",
            f"This will create clean copies of all {len(self.image_metadata)} "
            f"image(s) with metadata removed.\n\n"
            f"Clean copies will be saved as  <name>_clean.<ext>  in the same folders.\n\n"
            "Proceed?"
        )
        if not confirm:
            return

        self._set_status("Scrubbing images…")
        threading.Thread(target=self._run_scrub, daemon=True).start()

    def _run_scrub(self):
        results = []
        for path in self.image_list_order:
            ok, msg, out = scrub_image(path)
            results.append((ok, msg))

        successes = sum(1 for ok, _ in results if ok)
        failures  = [(m) for ok, m in results if not ok]

        def finish():
            if failures:
                detail = "\n".join(failures[:10])
                messagebox.showwarning(
                    "Scrub Complete",
                    f"{successes} image(s) scrubbed.\n"
                    f"{len(failures)} error(s):\n{detail}"
                )
            else:
                messagebox.showinfo(
                    "Scrub Complete",
                    f"All {successes} image(s) scrubbed successfully.\n"
                    "Clean copies saved alongside originals."
                )
            self._set_status(f"Scrub complete: {successes} saved, {len(failures)} error(s).")

        self.after(0, finish)

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _clear_all(self):
        self.image_metadata.clear()
        self.image_list_order.clear()
        self.selected_path = None
        self.file_listbox.delete(0, "end")
        self.tree.delete(*self.tree.get_children())
        self.meta_title.config(text="Select an image to view metadata")
        self._set_status("Cleared. Ready.")

    def _set_status(self, msg, error=False):
        self.status_var.set(msg)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not DND_AVAILABLE:
        # Warn once at launch; app still works via Add Files button
        import warnings
        warnings.warn(
            "tkinterdnd2 not installed – drag-and-drop is disabled.\n"
            "Install it with:  pip install tkinterdnd2",
            stacklevel=1
        )

    app = ImageMetadataApp()
    app.mainloop()
