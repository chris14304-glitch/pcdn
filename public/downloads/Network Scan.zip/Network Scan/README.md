# Network Port Scanner

A GUI-based network port scanner that automatically detects your current Wi-Fi or LAN network and scans all connected devices for open ports and service information.

---

## Features

- Auto-detects your local network — no IP address entry required
- Discovers all live devices on your network
- Scans common ports and identifies running services with version info
- Clean dark-themed GUI with a two-pane layout
- Click any device to view its full port details

---

## Requirements

### 1. Python 3.8+
Download from [python.org](https://www.python.org/downloads/)

### 2. Nmap (the binary)
Download and install from [nmap.org/download.html](https://nmap.org/download.html)

During installation on Windows, make sure **"Add nmap to PATH"** is checked.

To verify it installed correctly, open a terminal and run:
```
nmap --version
```

### 3. python-nmap (Python library)
Open a terminal and run:
```
pip install python-nmap
```

---

## How to Run

> **Important:** You must run the script as Administrator on Windows.
> Nmap's port scanning requires elevated privileges to send raw packets.

### Option A — Right-click method
1. Right-click on `Network Scan.py`
2. Select **"Run as administrator"** (if Python is set as the default handler)

### Option B — Terminal method (recommended)
1. Open **Command Prompt** or **PowerShell** as Administrator
   - Press `Win`, search for **cmd** or **PowerShell**, right-click → **Run as administrator**
2. Navigate to the script folder:
   ```
   cd "C:\Users\chris\Desktop\Program\Python\Network Scan"
   ```
3. Run the script:
   ```
   python "Network Scan.py"
   ```

---

## Using the App

1. **Launch the app** — your current network (e.g. `192.168.1.0/24`) and your IP address are detected and displayed automatically at the top.

2. **Click "Scan Network"** — the scanner will:
   - First sweep the network for live devices
   - Then probe each device for open ports and service versions

3. **View results** — discovered devices appear in the left table with:
   - IP Address
   - Hostname
   - MAC Address
   - Vendor (device manufacturer)
   - Number of open ports

4. **Click any device row** to see its open ports in the right panel:
   - Port number
   - Protocol (tcp/udp)
   - Service name (e.g. http, ssh, rdp)
   - Version / banner info

---

## Scanned Ports

The scanner checks the following common ports by default:

| Port | Service        |
|------|----------------|
| 21   | FTP            |
| 22   | SSH            |
| 23   | Telnet         |
| 25   | SMTP           |
| 53   | DNS            |
| 80   | HTTP           |
| 110  | POP3           |
| 135  | MS RPC         |
| 139  | NetBIOS        |
| 143  | IMAP           |
| 443  | HTTPS          |
| 445  | SMB            |
| 993  | IMAPS          |
| 995  | POP3S          |
| 1433 | MSSQL          |
| 1723 | PPTP VPN       |
| 3306 | MySQL          |
| 3389 | RDP            |
| 5432 | PostgreSQL     |
| 5900 | VNC            |
| 8080 | HTTP Alt       |
| 8443 | HTTPS Alt      |
| 27017| MongoDB        |

---

## Troubleshooting

**"nmap not found" error**
- Make sure nmap is installed and added to PATH
- Restart your terminal after installing nmap and try again

**Scan returns 0 devices**
- Make sure you are connected to Wi-Fi or Ethernet
- Run the script as Administrator
- Check that your firewall is not blocking nmap

**MAC address shows N/A**
- MAC addresses are only visible for devices on the same Layer 2 network segment
- Devices behind a router/switch may not expose their MAC to your machine

**Scan is slow**
- This is normal — service version detection (`-sV`) takes time per host
- Larger networks (many devices) will take longer

---

## Dependencies Summary

| Dependency   | Type    | Install                        |
|--------------|---------|--------------------------------|
| Python 3.8+  | Runtime | python.org                     |
| nmap         | Binary  | nmap.org                       |
| python-nmap  | Library | `pip install python-nmap`      |
| tkinter      | Library | Included with Python (built-in)|
