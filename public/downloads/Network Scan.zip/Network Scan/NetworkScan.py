import tkinter as tk
from tkinter import ttk, messagebox
import nmap
import socket
import ipaddress
import threading


# ---------------------------------------------------------------------------
# Network helpers
# ---------------------------------------------------------------------------

def get_local_network():
    """
    Auto-detect the subnet we're currently connected to by routing a dummy
    UDP packet (nothing is actually sent) and reading which local interface
    the OS would use.  Returns (network_cidr, local_ip) or (None, None).
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        # Assume a /24 subnet — works for the vast majority of home/office nets
        network = str(ipaddress.IPv4Network(f"{local_ip}/24", strict=False))
        return network, local_ip
    except Exception:
        return None, None


def scan_network(network_range):
    """
    1. Discover live hosts (fast ping sweep).
    2. For each live host, scan common ports with service/version detection.
    Returns a list of device dicts.
    """
    nm = nmap.PortScanner()

    # ---- Phase 1: host discovery ----
    nm.scan(hosts=network_range, arguments="-sn -T4")
    live_hosts = [h for h in nm.all_hosts() if nm[h].state() == "up"]

    if not live_hosts:
        return []

    # ---- Phase 2: port + service scan on live hosts only ----
    COMMON_PORTS = (
        "21,22,23,25,53,80,110,135,139,143,443,445,"
        "993,995,1433,1723,3306,3389,5432,5900,8080,8443,27017"
    )
    host_list = " ".join(live_hosts)
    nm.scan(
        hosts=host_list,
        arguments=f"-sT -sV -T4 --open -p {COMMON_PORTS}",
    )

    devices = []
    for host in nm.all_hosts():
        info = nm[host]

        mac = "N/A"
        if "addresses" in info:
            mac = info["addresses"].get("mac", "N/A")

        vendor = "Unknown"
        if "vendor" in info and info["vendor"]:
            vendor = list(info["vendor"].values())[0]

        open_ports = []
        for proto in info.all_protocols():
            for port in sorted(info[proto].keys()):
                pd = info[proto][port]
                if pd["state"] == "open":
                    version = " ".join(
                        filter(None, [pd.get("product", ""), pd.get("version", "")])
                    )
                    open_ports.append(
                        {
                            "port": port,
                            "proto": proto,
                            "service": pd.get("name", ""),
                            "version": version,
                        }
                    )

        devices.append(
            {
                "ip": host,
                "hostname": info.hostname() or "—",
                "mac": mac,
                "vendor": vendor,
                "ports": open_ports,
            }
        )

    # Sort by last octet so the list reads in order
    devices.sort(key=lambda d: int(d["ip"].split(".")[-1]))
    return devices


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

DARK_BG     = "#1e1e2e"
PANEL_BG    = "#313244"
HEADER_BG   = "#45475a"
ACCENT      = "#89b4fa"
TEXT        = "#cdd6f4"
MUTED       = "#a6adc8"
SEL_BG      = "#585b70"


class NetworkScannerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Public Cyber Defense Network")
        self.root.geometry("1200x720")
        self.root.configure(bg=DARK_BG)
        self.root.minsize(900, 550)

        self.scanning = False
        self.scan_results: list[dict] = []

        self._apply_styles()
        self._build_ui()
        self._detect_network()

    # ------------------------------------------------------------------
    # Style
    # ------------------------------------------------------------------

    def _apply_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Treeview",
            background=PANEL_BG,
            foreground=TEXT,
            fieldbackground=PANEL_BG,
            rowheight=26,
            font=("Consolas", 9),
            borderwidth=0,
        )
        style.configure(
            "Treeview.Heading",
            background=HEADER_BG,
            foreground=TEXT,
            font=("Helvetica", 9, "bold"),
            relief="flat",
        )
        style.map("Treeview", background=[("selected", SEL_BG)])
        style.configure(
            "Horizontal.TProgressbar",
            troughcolor=PANEL_BG,
            background=ACCENT,
            borderwidth=0,
        )

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self):
        # ---- Top bar ----
        top = tk.Frame(self.root, bg=DARK_BG)
        top.pack(fill="x", padx=20, pady=(14, 0))

        tk.Label(
            top, text="Network Port Scanner",
            font=("Helvetica", 18, "bold"),
            bg=DARK_BG, fg=TEXT,
        ).pack(side="left")

        # ---- Info bar ----
        info = tk.Frame(self.root, bg=PANEL_BG, padx=14, pady=8)
        info.pack(fill="x", padx=20, pady=10)

        tk.Label(info, text="Detected network:", bg=PANEL_BG, fg=MUTED,
                 font=("Helvetica", 10)).pack(side="left")

        self.network_var = tk.StringVar(value="Detecting…")
        tk.Label(
            info, textvariable=self.network_var,
            bg=PANEL_BG, fg=ACCENT, font=("Consolas", 10, "bold"),
        ).pack(side="left", padx=(6, 20))

        self.local_ip_label = tk.Label(info, text="", bg=PANEL_BG, fg=MUTED,
                                        font=("Helvetica", 10))
        self.local_ip_label.pack(side="left")

        self.scan_btn = tk.Button(
            info, text="  Scan Network  ",
            command=self.start_scan,
            bg=ACCENT, fg=DARK_BG, font=("Helvetica", 10, "bold"),
            relief="flat", cursor="hand2", padx=12, pady=5,
            activebackground="#b4d0f7", activeforeground=DARK_BG,
        )
        self.scan_btn.pack(side="right")

        # ---- Status + progress ----
        status_row = tk.Frame(self.root, bg=DARK_BG)
        status_row.pack(fill="x", padx=20, pady=(0, 4))

        self.status_var = tk.StringVar(value="Ready — click  Scan Network  to begin")
        tk.Label(
            status_row, textvariable=self.status_var,
            bg=DARK_BG, fg=MUTED, font=("Helvetica", 9), anchor="w",
        ).pack(side="left")

        self.progress = ttk.Progressbar(
            status_row, mode="indeterminate", length=220,
            style="Horizontal.TProgressbar",
        )
        self.progress.pack(side="right")

        # ---- Main split: device table | port detail ----
        paned = tk.PanedWindow(
            self.root, orient="horizontal",
            bg=DARK_BG, sashwidth=8, sashrelief="flat",
        )
        paned.pack(fill="both", expand=True, padx=20, pady=(0, 14))

        # Left — device list
        left = tk.Frame(paned, bg=DARK_BG)
        paned.add(left, minsize=460)

        tk.Label(left, text="Devices", bg=DARK_BG, fg=TEXT,
                 font=("Helvetica", 11, "bold")).pack(anchor="w", pady=(0, 4))

        dev_cols = ("IP Address", "Hostname", "MAC Address", "Vendor", "Open Ports")
        self.device_tree = ttk.Treeview(left, columns=dev_cols, show="headings")
        widths = [120, 150, 140, 160, 80]
        for col, w in zip(dev_cols, widths):
            self.device_tree.heading(col, text=col)
            self.device_tree.column(col, width=w, anchor="w")

        dev_sb = ttk.Scrollbar(left, orient="vertical",
                                command=self.device_tree.yview)
        self.device_tree.configure(yscrollcommand=dev_sb.set)
        self.device_tree.pack(side="left", fill="both", expand=True)
        dev_sb.pack(side="right", fill="y")
        self.device_tree.bind("<<TreeviewSelect>>", self._on_device_select)

        # Right — port details
        right = tk.Frame(paned, bg=DARK_BG)
        paned.add(right, minsize=320)

        self.detail_header = tk.Label(
            right, text="Port Details", bg=DARK_BG, fg=TEXT,
            font=("Helvetica", 11, "bold"),
        )
        self.detail_header.pack(anchor="w", pady=(0, 4))

        port_cols = ("Port", "Proto", "Service", "Version / Banner")
        self.port_tree = ttk.Treeview(right, columns=port_cols, show="headings")
        port_widths = [65, 55, 95, 200]
        for col, w in zip(port_cols, port_widths):
            self.port_tree.heading(col, text=col)
            self.port_tree.column(col, width=w, anchor="w")

        port_sb = ttk.Scrollbar(right, orient="vertical",
                                  command=self.port_tree.yview)
        self.port_tree.configure(yscrollcommand=port_sb.set)
        self.port_tree.pack(side="left", fill="both", expand=True)
        port_sb.pack(side="right", fill="y")

    # ------------------------------------------------------------------
    # Network detection
    # ------------------------------------------------------------------

    def _detect_network(self):
        network, local_ip = get_local_network()
        if network:
            self.network_var.set(network)
            self.local_ip_label.config(text=f"Your IP: {local_ip}")
        else:
            self.network_var.set("Could not detect")
            self.local_ip_label.config(text="Check your connection")

    # ------------------------------------------------------------------
    # Scan lifecycle
    # ------------------------------------------------------------------

    def start_scan(self):
        if self.scanning:
            return
        network = self.network_var.get()
        if network in ("Could not detect", "Detecting…"):
            messagebox.showwarning(
                "No Network",
                "Could not detect your local network.\n"
                "Please make sure you are connected to Wi-Fi or Ethernet.",
            )
            return

        self.scanning = True
        self.scan_btn.config(state="disabled", text="  Scanning…  ")
        self.status_var.set("Phase 1/2 — discovering live hosts…")
        self.progress.start(8)

        for item in self.device_tree.get_children():
            self.device_tree.delete(item)
        for item in self.port_tree.get_children():
            self.port_tree.delete(item)
        self.scan_results = []
        self.detail_header.config(text="Port Details")

        threading.Thread(target=self._scan_thread, args=(network,), daemon=True).start()

    def _scan_thread(self, network: str):
        try:
            results = scan_network(network)
            self.root.after(0, self._scan_done, results)
        except nmap.PortScannerError as exc:
            self.root.after(0, self._scan_error,
                            f"{exc}\n\nMake sure nmap is installed:\n"
                            "  https://nmap.org/download.html\n"
                            "and run this script as Administrator.")
        except Exception as exc:
            self.root.after(0, self._scan_error, str(exc))

    def _scan_done(self, results: list[dict]):
        self.scanning = False
        self.progress.stop()
        self.scan_btn.config(state="normal", text="  Scan Network  ")
        self.scan_results = results

        for device in results:
            self.device_tree.insert(
                "", "end",
                values=(
                    device["ip"],
                    device["hostname"],
                    device["mac"],
                    device["vendor"],
                    len(device["ports"]),
                ),
            )

        noun = "device" if len(results) == 1 else "devices"
        self.status_var.set(
            f"Scan complete — {len(results)} {noun} found.  "
            "Click a row to see open ports."
        )

    def _scan_error(self, message: str):
        self.scanning = False
        self.progress.stop()
        self.scan_btn.config(state="normal", text="  Scan Network  ")
        self.status_var.set("Scan failed — see error dialog")
        messagebox.showerror("Scan Error", message)

    # ------------------------------------------------------------------
    # Selection handler
    # ------------------------------------------------------------------

    def _on_device_select(self, _event):
        sel = self.device_tree.selection()
        if not sel:
            return
        idx = self.device_tree.index(sel[0])

        for item in self.port_tree.get_children():
            self.port_tree.delete(item)

        if idx >= len(self.scan_results):
            return

        device = self.scan_results[idx]
        self.detail_header.config(
            text=f"Port Details — {device['ip']}  ({device['hostname']})"
        )

        if device["ports"]:
            for p in device["ports"]:
                self.port_tree.insert(
                    "", "end",
                    values=(p["port"], p["proto"], p["service"], p["version"]),
                )
        else:
            self.port_tree.insert(
                "", "end", values=("—", "—", "No open ports detected", "—")
            )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    root = tk.Tk()
    app = NetworkScannerApp(root)
    root.mainloop()
