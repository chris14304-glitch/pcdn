import time
import threading
import tkinter as tk
from pynput.mouse import Button, Controller
from pynput.keyboard import Listener, KeyCode

mouse = Controller()


class Clicker(threading.Thread):
    def __init__(self, delay, button):
        super().__init__(daemon=True)
        self.delay = delay
        self.button = button
        self.running = False
        self.program_running = True

    def start_clicking(self):
        self.running = True

    def stop_clicking(self):
        self.running = False

    def exit(self):
        self.stop_clicking()
        self.program_running = False

    def run(self):
        while self.program_running:
            while self.running:
                mouse.click(self.button)
                time.sleep(self.delay)
            time.sleep(0.1)


class AutoClickerApp:
    TOGGLE_KEY = KeyCode(char='s')
    EXIT_KEY = KeyCode(char='e')

    def __init__(self, root):
        self.root = root
        self.root.title("Public Cyber Defense Network")
        self.root.geometry("340x300")
        self.root.resizable(False, False)

        self.delay_var = tk.DoubleVar(value=0.1)
        self.button_var = tk.StringVar(value="Left")

        self.clicker = Clicker(delay=0.1, button=Button.left)
        self.clicker.start()

        self._build_ui()
        self._start_listener()
        self._poll_status()

    def _build_ui(self):
        # Status indicator
        self.status_label = tk.Label(
            self.root, text="● STOPPED",
            font=("Segoe UI", 16, "bold"), fg="#cc3333"
        )
        self.status_label.pack(pady=(18, 4))

        # Start / Exit buttons
        ctrl = tk.Frame(self.root)
        ctrl.pack(pady=4)
        self.toggle_btn = tk.Button(ctrl, text="Start", width=11, command=self._toggle)
        self.toggle_btn.pack(side=tk.LEFT, padx=6)
        tk.Button(ctrl, text="Exit", width=11, command=self._exit).pack(side=tk.LEFT, padx=6)

        # Click interval slider
        interval_frame = tk.LabelFrame(self.root, text="Click Interval (seconds)", padx=10, pady=4)
        interval_frame.pack(fill=tk.X, padx=20, pady=10)

        self.delay_display = tk.Label(interval_frame, text="0.10 s", font=("Segoe UI", 9))
        self.delay_display.pack(anchor=tk.E)

        tk.Scale(
            interval_frame, from_=0.01, to=2.0, resolution=0.01,
            orient=tk.HORIZONTAL, variable=self.delay_var,
            showvalue=False, command=self._update_delay
        ).pack(fill=tk.X)

        # Mouse button selector
        btn_frame = tk.LabelFrame(self.root, text="Mouse Button", padx=10, pady=4)
        btn_frame.pack(fill=tk.X, padx=20, pady=4)
        for label in ("Left", "Right", "Middle"):
            tk.Radiobutton(
                btn_frame, text=label, variable=self.button_var,
                value=label, command=self._update_button
            ).pack(side=tk.LEFT, padx=8)

        # Hotkey hint
        tk.Label(
            self.root, text="Hotkeys:  [S] Start / Stop     [E] Exit",
            fg="gray", font=("Segoe UI", 8)
        ).pack(pady=(12, 0))

    # ── actions ──────────────────────────────────────────────────────────────

    def _toggle(self):
        if self.clicker.running:
            self.clicker.stop_clicking()
        else:
            self.clicker.start_clicking()

    def _exit(self):
        self.clicker.exit()
        self.listener.stop()
        self.root.destroy()

    def _update_delay(self, val):
        v = float(val)
        self.clicker.delay = v
        self.delay_display.config(text=f"{v:.2f} s")

    def _update_button(self):
        mapping = {"Left": Button.left, "Right": Button.right, "Middle": Button.middle}
        self.clicker.button = mapping[self.button_var.get()]

    # ── key listener (runs in its own daemon thread) ──────────────────────────

    def _start_listener(self):
        def on_press(key):
            if key == self.TOGGLE_KEY:
                self.root.after(0, self._toggle)
            elif key == self.EXIT_KEY:
                self.root.after(0, self._exit)

        self.listener = Listener(on_press=on_press)
        self.listener.daemon = True
        self.listener.start()

    # ── status polling (keeps GUI in sync without blocking) ──────────────────

    def _poll_status(self):
        if self.clicker.running:
            self.status_label.config(text="● ACTIVE", fg="#22aa44")
            self.toggle_btn.config(text="Stop")
        else:
            self.status_label.config(text="● STOPPED", fg="#cc3333")
            self.toggle_btn.config(text="Start")
        self.root.after(100, self._poll_status)


if __name__ == "__main__":
    root = tk.Tk()
    app = AutoClickerApp(root)
    root.mainloop()
