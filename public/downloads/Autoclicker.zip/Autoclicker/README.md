# AutoClicker

A lightweight Python autoclicker with a graphical interface. Supports adjustable click speed, mouse button selection, and global hotkeys that work even when the window is not in focus.

---

## Requirements

- Python 3.7 or higher
- `pynput` library

---

## Installation

**1. Install Python**

Download and install Python from [python.org](https://www.python.org/downloads/).
During installation, check **"Add Python to PATH"**.

**2. Install the required dependency**

Open a terminal (Command Prompt or PowerShell) and run:

```
pip install pynput
```

`tkinter` is included with standard Python installations on Windows and does not need to be installed separately.

---

## Running the Program

Navigate to the folder containing `Autoclicker.py` and run:

```
python Autoclicker.py
```

Or double-click the file if `.py` files are associated with Python on your system.

---

## Using the Interface

| Control | Description |
|---|---|
| **Status indicator** | Shows `● ACTIVE` (green) or `● STOPPED` (red) |
| **Start / Stop button** | Toggles clicking on or off |
| **Click Interval slider** | Sets the delay between clicks (0.01 – 2.00 seconds) |
| **Mouse Button selector** | Choose Left, Right, or Middle click |
| **Exit button** | Stops the clicker and closes the program |

---

## Hotkeys

Hotkeys are **global** — they work even when the AutoClicker window is minimized or in the background.

| Key | Action |
|---|---|
| `S` | Start / Stop clicking |
| `E` | Exit the program |

---

## Notes

- The click interval defaults to **0.10 seconds** (10 clicks per second) on launch.
- Settings (interval and button) can be changed at any time, including while clicking is active.
- Closing the window via the title bar X also stops all background threads cleanly.
