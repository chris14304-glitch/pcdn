using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace MemPurge.Converters
{
    /// <summary>
    /// Converts a percentage (0-100) to an arc geometry for the ring gauge.
    /// Creates a donut-arc path from the top center, going clockwise.
    /// </summary>
    public class PercentToArcConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Length < 2) return null!;

            double percent = System.Convert.ToDouble(values[0]);
            double size = System.Convert.ToDouble(values[1]);

            double strokeWidth = 12;
            double radius = (size - strokeWidth) / 2;
            double centerX = size / 2;
            double centerY = size / 2;

            percent = Math.Clamp(percent, 0, 99.99); // Avoid full-circle edge case
            double angle = (percent / 100.0) * 360.0;
            double angleRad = angle * Math.PI / 180.0;

            double startX = centerX;
            double startY = centerY - radius;

            double endX = centerX + radius * Math.Sin(angleRad);
            double endY = centerY - radius * Math.Cos(angleRad);

            bool largeArc = angle > 180;

            var geometry = new StreamGeometry();
            using (var ctx = geometry.Open())
            {
                ctx.BeginFigure(new Point(startX, startY), false, false);
                ctx.ArcTo(
                    new Point(endX, endY),
                    new Size(radius, radius),
                    0,
                    largeArc,
                    SweepDirection.Clockwise,
                    true,
                    false);
            }
            geometry.Freeze();
            return geometry;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Converts a hex color string (#RRGGBB) to a SolidColorBrush.
    /// </summary>
    public class StringToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string hex)
            {
                try
                {
                    var color = (Color)ColorConverter.ConvertFromString(hex);
                    return new SolidColorBrush(color);
                }
                catch { }
            }
            return new SolidColorBrush(Colors.White);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Converts bytes (long) to a human-readable string like "1.2 GB" or "345 MB".
    /// </summary>
    public class BytesToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            long bytes = System.Convert.ToInt64(value);
            double mb = bytes / (1024.0 * 1024.0);
            return mb >= 1024 ? $"{mb / 1024:F1} GB" : $"{mb:F0} MB";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Converts a boolean to Visibility (true = Visible, false = Collapsed).
    /// </summary>
    public class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => (value is bool b && b) ? Visibility.Visible : Visibility.Collapsed;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => value is Visibility v && v == Visibility.Visible;
    }

    /// <summary>
    /// Inverts a boolean.
    /// </summary>
    public class InverseBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : value;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : value;
    }

    /// <summary>
    /// Returns a color brush based on log level.
    /// </summary>
    public class LogLevelToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (value as string) switch
            {
                "Success" => new SolidColorBrush(Color.FromRgb(0x00, 0xFF, 0xC8)),
                "Warning" => new SolidColorBrush(Color.FromRgb(0xFF, 0xAA, 0x2C)),
                "Error" => new SolidColorBrush(Color.FromRgb(0xFF, 0x3B, 0x5C)),
                _ => new SolidColorBrush(Color.FromRgb(0xC8, 0xCC, 0xD4)),
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Converts memory MB to bar width (max 200px, scaled to 2GB max).
    /// </summary>
    public class MemoryToBarWidthConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double mb = System.Convert.ToDouble(value);
            double maxWidth = 200;
            double maxMB = 2048; // 2 GB as max scale
            return Math.Min(mb / maxMB * maxWidth, maxWidth);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Converts a percentage (0-100) to a StrokeDashOffset for the ring gauge.
    /// StrokeDashArray="100,100": offset 100 = empty, offset 0 = full ring.
    /// </summary>
    public class PercentToDashOffsetConverter : IValueConverter
    {
        public static readonly PercentToDashOffsetConverter Instance = new();

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double pct = System.Convert.ToDouble(value);
            return 100.0 - Math.Clamp(pct, 0, 100);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Converts IsCritical bool to "PROTECTED" or "CLEAN" button label.
    /// </summary>
    public class CriticalToLabelConverter : IValueConverter
    {
        public static readonly CriticalToLabelConverter Instance = new();

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => (value is bool b && b) ? "PROTECTED" : "CLEAN";

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
