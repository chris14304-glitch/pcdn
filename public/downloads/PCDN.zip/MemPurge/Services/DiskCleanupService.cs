using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MemPurge.Services
{
    /// <summary>
    /// Represents a category of cleanable junk files (like Disk Cleanup categories).
    /// </summary>
    public class CleanupCategory
    {
        public string Id { get; set; } = "";
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public long SizeBytes { get; set; }
        public int FileCount { get; set; }
        public bool IsSelected { get; set; }
        public bool IsScanned { get; set; }
        public List<string> Paths { get; set; } = new();

        public string SizeText
        {
            get
            {
                if (SizeBytes >= 1024L * 1024 * 1024)
                    return $"{SizeBytes / (1024.0 * 1024 * 1024):F2} GB";
                if (SizeBytes >= 1024 * 1024)
                    return $"{SizeBytes / (1024.0 * 1024):F1} MB";
                if (SizeBytes >= 1024)
                    return $"{SizeBytes / 1024.0:F0} KB";
                return $"{SizeBytes} B";
            }
        }
    }

    /// <summary>
    /// Scans and cleans junk files across standard Windows temp/cache locations.
    /// Mirrors what the built-in Disk Cleanup tool does.
    /// </summary>
    public static class DiskCleanupService
    {
        // ── Scan All Categories ────────────────────────────────────────
        public static async Task<List<CleanupCategory>> ScanAsync(
            IProgress<string>? progress = null,
            CancellationToken ct = default)
        {
            var categories = new List<CleanupCategory>();

            // 1. Windows Temp
            categories.Add(await ScanCategoryAsync("wintemp", "Windows Temp Files",
                "Temporary files created by Windows in the system temp folder.",
                new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp") },
                "*.*", progress, ct));

            // 2. User Temp
            categories.Add(await ScanCategoryAsync("usertemp", "User Temp Files",
                "Temporary files in your user profile temp folder.",
                new[] { Path.GetTempPath() },
                "*.*", progress, ct));

            // 3. Recycle Bin (report size only — cleaned via shell)
            categories.Add(await ScanRecycleBinAsync(progress, ct));

            // 4. Windows Prefetch
            categories.Add(await ScanCategoryAsync("prefetch", "Prefetch Files",
                "Windows prefetch cache files used to speed up app launches. Safe to delete.",
                new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Prefetch") },
                "*.pf", progress, ct));

            // 5. Thumbnail Cache
            var thumbPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Microsoft", "Windows", "Explorer");
            categories.Add(await ScanCategoryAsync("thumbs", "Thumbnail Cache",
                "Cached thumbnail images for files and folders. Windows will regenerate them.",
                new[] { thumbPath },
                "thumbcache_*.db", progress, ct));

            // 6. Windows Update Cleanup
            categories.Add(await ScanCategoryAsync("wuclean", "Windows Update Cache",
                "Downloaded Windows Update files that are no longer needed.",
                new[] { @"C:\Windows\SoftwareDistribution\Download" },
                "*.*", progress, ct));

            // 7. Windows Log Files
            categories.Add(await ScanCategoryAsync("logs", "Windows Log Files",
                "Setup logs, CBS logs, DISM logs, and other system log files.",
                new[]
                {
                    @"C:\Windows\Logs",
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Temp"),
                },
                "*.log", progress, ct));

            // 8. Browser Cache (Chrome, Edge, Firefox)
            categories.Add(await ScanBrowserCacheAsync(progress, ct));

            // 9. Windows Error Reports
            categories.Add(await ScanCategoryAsync("wer", "Windows Error Reports",
                "Crash dumps and error reports sent to Microsoft.",
                new[]
                {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "Microsoft", "Windows", "WER"),
                    @"C:\ProgramData\Microsoft\Windows\WER",
                },
                "*.*", progress, ct));

            // 10. Recent items / temp downloads
            categories.Add(await ScanCategoryAsync("dltemp", "Temporary Download Files",
                "Partial and temporary download files left behind by browsers and apps.",
                new[] { Path.GetTempPath() },
                "*.tmp", progress, ct));

            return categories;
        }

        // ── Scan a Single Category ─────────────────────────────────────
        private static async Task<CleanupCategory> ScanCategoryAsync(
            string id, string name, string description,
            string[] directories, string searchPattern,
            IProgress<string>? progress, CancellationToken ct)
        {
            var category = new CleanupCategory
            {
                Id = id,
                Name = name,
                Description = description,
                IsSelected = false,
            };

            await Task.Run(() =>
            {
                foreach (var dir in directories)
                {
                    try
                    {
                        if (!Directory.Exists(dir)) continue;

                        progress?.Report($"Scanning {name}...");

                        var files = Directory.EnumerateFiles(dir, searchPattern, new EnumerationOptions
                        {
                            IgnoreInaccessible = true,
                            RecurseSubdirectories = true,
                            AttributesToSkip = FileAttributes.System,
                        });

                        foreach (var file in files)
                        {
                            if (ct.IsCancellationRequested) break;

                            try
                            {
                                var info = new FileInfo(file);
                                category.SizeBytes += info.Length;
                                category.FileCount++;
                                category.Paths.Add(file);
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
            }, ct);

            category.IsScanned = true;
            return category;
        }

        // ── Scan Browser Caches ────────────────────────────────────────
        private static async Task<CleanupCategory> ScanBrowserCacheAsync(
            IProgress<string>? progress, CancellationToken ct)
        {
            var category = new CleanupCategory
            {
                Id = "browser",
                Name = "Browser Cache",
                Description = "Cached web data from Chrome, Edge, and Firefox. Won't affect bookmarks or passwords.",
                IsSelected = false,
            };

            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

            var cacheDirs = new[]
            {
                Path.Combine(localAppData, "Google", "Chrome", "User Data", "Default", "Cache"),
                Path.Combine(localAppData, "Google", "Chrome", "User Data", "Default", "Code Cache"),
                Path.Combine(localAppData, "Microsoft", "Edge", "User Data", "Default", "Cache"),
                Path.Combine(localAppData, "Microsoft", "Edge", "User Data", "Default", "Code Cache"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Mozilla", "Firefox", "Profiles"),
            };

            await Task.Run(() =>
            {
                foreach (var dir in cacheDirs)
                {
                    try
                    {
                        if (!Directory.Exists(dir)) continue;

                        progress?.Report("Scanning browser caches...");

                        var files = Directory.EnumerateFiles(dir, "*.*", new EnumerationOptions
                        {
                            IgnoreInaccessible = true,
                            RecurseSubdirectories = true,
                        });

                        foreach (var file in files)
                        {
                            if (ct.IsCancellationRequested) break;

                            try
                            {
                                var info = new FileInfo(file);
                                category.SizeBytes += info.Length;
                                category.FileCount++;
                                category.Paths.Add(file);
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
            }, ct);

            category.IsScanned = true;
            return category;
        }

        // ── Scan Recycle Bin ───────────────────────────────────────────
        private static async Task<CleanupCategory> ScanRecycleBinAsync(
            IProgress<string>? progress, CancellationToken ct)
        {
            var category = new CleanupCategory
            {
                Id = "recycle",
                Name = "Recycle Bin",
                Description = "Deleted files sitting in the Recycle Bin across all drives.",
                IsSelected = false,
            };

            await Task.Run(() =>
            {
                try
                {
                    progress?.Report("Scanning Recycle Bin...");

                    // Scan $Recycle.Bin on each drive
                    foreach (var drive in DriveInfo.GetDrives())
                    {
                        if (ct.IsCancellationRequested) break;

                        try
                        {
                            if (!drive.IsReady) continue;

                            var recyclePath = Path.Combine(drive.RootDirectory.FullName, "$Recycle.Bin");
                            if (!Directory.Exists(recyclePath)) continue;

                            var files = Directory.EnumerateFiles(recyclePath, "*.*", new EnumerationOptions
                            {
                                IgnoreInaccessible = true,
                                RecurseSubdirectories = true,
                                AttributesToSkip = 0, // include hidden/system
                            });

                            foreach (var file in files)
                            {
                                if (ct.IsCancellationRequested) break;

                                try
                                {
                                    var info = new FileInfo(file);
                                    category.SizeBytes += info.Length;
                                    category.FileCount++;
                                    // Don't store individual recycle bin paths — we'll use SHEmptyRecycleBin
                                }
                                catch { }
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }, ct);

            category.IsScanned = true;
            return category;
        }

        // ── Clean Selected Categories ──────────────────────────────────
        public static async Task<CleanupResult> CleanAsync(
            List<CleanupCategory> categories,
            IProgress<string>? progress = null,
            CancellationToken ct = default)
        {
            var result = new CleanupResult();

            foreach (var cat in categories.Where(c => c.IsSelected && c.IsScanned))
            {
                if (ct.IsCancellationRequested) break;

                progress?.Report($"Cleaning {cat.Name}...");

                // Special handling for Recycle Bin
                if (cat.Id == "recycle")
                {
                    try
                    {
                        // Use SHEmptyRecycleBin via shell
                        await Task.Run(() =>
                        {
                            try
                            {
                                SHEmptyRecycleBin(IntPtr.Zero, null, 0x00000007); // SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
                                result.BytesCleaned += (ulong)cat.SizeBytes;
                                result.FilesCleaned += cat.FileCount;
                                result.CategoriesCleaned++;
                            }
                            catch { }
                        }, ct);
                    }
                    catch { }
                    continue;
                }

                // Normal file deletion
                await Task.Run(() =>
                {
                    foreach (var path in cat.Paths)
                    {
                        if (ct.IsCancellationRequested) break;

                        try
                        {
                            var info = new FileInfo(path);
                            long size = info.Length;
                            info.Delete();
                            result.BytesCleaned += (ulong)size;
                            result.FilesCleaned++;
                        }
                        catch
                        {
                            result.FilesSkipped++;
                        }
                    }

                    // Try to remove empty directories
                    foreach (var path in cat.Paths)
                    {
                        try
                        {
                            var dir = Path.GetDirectoryName(path);
                            if (dir != null && Directory.Exists(dir) &&
                                !Directory.EnumerateFileSystemEntries(dir).Any())
                            {
                                Directory.Delete(dir);
                            }
                        }
                        catch { }
                    }

                    result.CategoriesCleaned++;
                }, ct);
            }

            return result;
        }

        // ── Shell32 for Recycle Bin ────────────────────────────────────
        [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        private static extern int SHEmptyRecycleBin(IntPtr hwnd, string? pszRootPath, uint dwFlags);
    }

    public class CleanupResult
    {
        public ulong BytesCleaned { get; set; }
        public int FilesCleaned { get; set; }
        public int FilesSkipped { get; set; }
        public int CategoriesCleaned { get; set; }

        public string SizeText
        {
            get
            {
                if (BytesCleaned >= 1024UL * 1024 * 1024)
                    return $"{BytesCleaned / (1024.0 * 1024 * 1024):F2} GB";
                if (BytesCleaned >= 1024 * 1024)
                    return $"{BytesCleaned / (1024.0 * 1024):F1} MB";
                return $"{BytesCleaned / 1024.0:F0} KB";
            }
        }
    }
}
