using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace MemPurge.Services
{
    // ═══════════════════════════════════════════════════════════════════
    // THREAT SCORING MODEL
    // ═══════════════════════════════════════════════════════════════════

    public class ThreatIndicator
    {
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public int Points { get; set; }
        public string Severity { get; set; } = "Low"; // Low, Medium, High, Critical
    }

    public class FileScanResult
    {
        public string FilePath { get; set; } = "";
        public string FileName { get; set; } = "";
        public long FileSize { get; set; }
        public string SHA256 { get; set; } = "";
        public string MD5 { get; set; } = "";
        public double Entropy { get; set; }
        public int ThreatScore { get; set; } // 0-100
        public string ThreatLevel { get; set; } = "Clean"; // Clean, Low, Medium, High, Critical
        public List<ThreatIndicator> Indicators { get; set; } = new();
        public bool IsExecutable { get; set; }
        public bool IsSigned { get; set; }
        public DateTime ScanTime { get; set; } = DateTime.Now;

        public string ThreatColor => ThreatLevel switch
        {
            "Critical" => "#FF3B5C",
            "High" => "#FF6B3B",
            "Medium" => "#FFAA2C",
            "Low" => "#FFD93D",
            _ => "#00FFC8"
        };

        public string FileSizeText
        {
            get
            {
                if (FileSize >= 1024L * 1024 * 1024) return $"{FileSize / (1024.0 * 1024 * 1024):F1} GB";
                if (FileSize >= 1024 * 1024) return $"{FileSize / (1024.0 * 1024):F1} MB";
                if (FileSize >= 1024) return $"{FileSize / 1024.0:F0} KB";
                return $"{FileSize} B";
            }
        }
    }

    public class ProcessScanResult
    {
        public int Pid { get; set; }
        public string Name { get; set; } = "";
        public string Path { get; set; } = "";
        public int ThreatScore { get; set; }
        public string ThreatLevel { get; set; } = "Clean";
        public List<ThreatIndicator> Indicators { get; set; } = new();
        public double MemoryMB { get; set; }

        public string ThreatColor => ThreatLevel switch
        {
            "Critical" => "#FF3B5C",
            "High" => "#FF6B3B",
            "Medium" => "#FFAA2C",
            "Low" => "#FFD93D",
            _ => "#00FFC8"
        };
    }

    public class StartupEntry
    {
        public string Name { get; set; } = "";
        public string Command { get; set; } = "";
        public string Location { get; set; } = "";
        public int ThreatScore { get; set; }
        public string ThreatLevel { get; set; } = "Clean";
        public List<ThreatIndicator> Indicators { get; set; } = new();

        public string ThreatColor => ThreatLevel switch
        {
            "Critical" => "#FF3B5C",
            "High" => "#FF6B3B",
            "Medium" => "#FFAA2C",
            "Low" => "#FFD93D",
            _ => "#00FFC8"
        };
    }

    public class FullScanResult
    {
        public int FilesScanned { get; set; }
        public int ThreatsFound { get; set; }
        public int ProcessesScanned { get; set; }
        public int SuspiciousProcesses { get; set; }
        public int StartupItemsScanned { get; set; }
        public int SuspiciousStartupItems { get; set; }
        public List<FileScanResult> FileResults { get; set; } = new();
        public List<ProcessScanResult> ProcessResults { get; set; } = new();
        public List<StartupEntry> StartupResults { get; set; } = new();
        public TimeSpan Duration { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════
    // KNOWN MALWARE HASHES (sample database)
    // ═══════════════════════════════════════════════════════════════════

    public static class ThreatDatabase
    {
        // SHA256 hashes of well-known malware samples (public test hashes)
        // In a real product you'd load these from an updatable database file
        public static readonly HashSet<string> KnownMalwareHashes = new(StringComparer.OrdinalIgnoreCase)
        {
            // EICAR test file hash (standard AV test string)
            "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f",
            // WannaCry samples
            "ed01ebfbc9eb5bbea545af4d01bf5f1071661840480439c6e5babe8e080e41aa",
            "24d004a104d4d54034dbcffc2a4b19a11f39008a575aa614ea04703480b1022c",
            // Petya/NotPetya
            "027cc450ef5f8c5f653329641ec1fed91f694e0d229928963b30f6b0d7d3a745",
            // Emotet
            "f97e9cd160f10cf868e6d3a3d33ceccf622262e4e94939cb10e5c7173c87faab",
            // Mimikatz (pen test tool, often malicious context)
            "61c0810a23580cf492a6ba4f7654566108331e7a4134c968c2d6a05261b2d8a1",
        };

        // Suspicious strings commonly found in malware
        public static readonly string[] SuspiciousStrings =
        {
            "powershell -enc", "powershell -e ", "powershell -w hidden",
            "cmd /c ", "cmd.exe /c",
            "FromBase64String", "Convert.FromBase64",
            "Invoke-Expression", "IEX(",
            "Net.WebClient", "DownloadString", "DownloadFile",
            "WScript.Shell", "Shell.Application",
            "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
            "RegWrite", "RegDelete",
            "taskkill /f", "sc stop", "sc delete",
            "vssadmin delete shadows",
            "bcdedit /set", "wbadmin delete",
            "Mimikatz", "sekurlsa", "lsadump",
            "keylog", "screenshot", "webcam",
            "reverse_tcp", "meterpreter", "payload",
            "bind_tcp", "shell_reverse",
        };

        // Suspicious file extensions that warrant extra scrutiny
        public static readonly HashSet<string> RiskyExtensions = new(StringComparer.OrdinalIgnoreCase)
        {
            ".exe", ".dll", ".scr", ".bat", ".cmd", ".ps1", ".vbs",
            ".js", ".wsf", ".hta", ".com", ".pif", ".msi", ".jar",
        };

        // Known safe system processes
        public static readonly HashSet<string> TrustedProcesses = new(StringComparer.OrdinalIgnoreCase)
        {
            "explorer", "svchost", "csrss", "dwm", "taskmgr", "winlogon",
            "services", "lsass", "smss", "wininit", "fontdrvhost",
            "sihost", "ctfmon", "conhost", "dllhost", "RuntimeBroker",
            "SearchHost", "StartMenuExperienceHost", "TextInputHost",
            "SecurityHealthSystray", "SecurityHealthService",
        };
    }

    // ═══════════════════════════════════════════════════════════════════
    // SCANNER ENGINE
    // ═══════════════════════════════════════════════════════════════════

    public static class SecurityScannerService
    {
        // ── File Scanning ──────────────────────────────────────────────
        public static async Task<List<FileScanResult>> ScanDirectoryAsync(
            string directory,
            bool deepScan,
            IProgress<(string message, int filesScanned)>? progress = null,
            CancellationToken ct = default)
        {
            var results = new List<FileScanResult>();
            int scanned = 0;

            await Task.Run(() =>
            {
                IEnumerable<string> files;
                try
                {
                    files = Directory.EnumerateFiles(directory, "*.*", new EnumerationOptions
                    {
                        IgnoreInaccessible = true,
                        RecurseSubdirectories = true,
                        AttributesToSkip = FileAttributes.System | FileAttributes.ReparsePoint,
                        MaxRecursionDepth = deepScan ? 15 : 5,
                    });
                }
                catch { return; }

                foreach (var filePath in files)
                {
                    if (ct.IsCancellationRequested) break;

                    try
                    {
                        var info = new FileInfo(filePath);

                        // Skip very large files (>500MB) and very small files (<16 bytes)
                        if (info.Length > 500L * 1024 * 1024 || info.Length < 16) continue;

                        // For quick scan, only check executables and scripts
                        bool isRisky = ThreatDatabase.RiskyExtensions.Contains(info.Extension);
                        if (!deepScan && !isRisky) continue;

                        scanned++;
                        if (scanned % 50 == 0)
                            progress?.Report(($"Scanning: {info.Name}", scanned));

                        var result = ScanFile(filePath, info);
                        if (result.ThreatScore > 0 || isRisky)
                            results.Add(result);
                    }
                    catch { }
                }

                progress?.Report(("Scan complete", scanned));
            }, ct);

            return results.OrderByDescending(r => r.ThreatScore).ToList();
        }

        public static FileScanResult ScanFile(string filePath, FileInfo? info = null)
        {
            info ??= new FileInfo(filePath);
            var result = new FileScanResult
            {
                FilePath = filePath,
                FileName = info.Name,
                FileSize = info.Length,
                IsExecutable = ThreatDatabase.RiskyExtensions.Contains(info.Extension),
            };

            var indicators = new List<ThreatIndicator>();
            int score = 0;

            try
            {
                // 1. Hash the file
                byte[] fileBytes;
                try
                {
                    // Read up to 10MB for hashing
                    using var fs = File.OpenRead(filePath);
                    int readSize = (int)Math.Min(info.Length, 10 * 1024 * 1024);
                    fileBytes = new byte[readSize];
                    fs.Read(fileBytes, 0, readSize);

                    result.SHA256 = ComputeSHA256(filePath);
                    result.MD5 = ComputeMD5(filePath);
                }
                catch
                {
                    fileBytes = Array.Empty<byte>();
                }

                // 2. Check against known malware hashes
                if (!string.IsNullOrEmpty(result.SHA256) &&
                    ThreatDatabase.KnownMalwareHashes.Contains(result.SHA256))
                {
                    score += 95;
                    indicators.Add(new ThreatIndicator
                    {
                        Name = "Known Malware Hash",
                        Description = $"SHA256 matches known malware signature database",
                        Points = 95,
                        Severity = "Critical"
                    });
                }

                // 3. Calculate entropy
                if (fileBytes.Length > 0)
                {
                    result.Entropy = CalculateEntropy(fileBytes);

                    if (result.Entropy > 7.5 && result.IsExecutable)
                    {
                        int pts = result.Entropy > 7.9 ? 30 : 15;
                        score += pts;
                        indicators.Add(new ThreatIndicator
                        {
                            Name = "High Entropy (Packed/Encrypted)",
                            Description = $"Entropy: {result.Entropy:F2}/8.0 — indicates the file may be packed, encrypted, or obfuscated",
                            Points = pts,
                            Severity = result.Entropy > 7.9 ? "High" : "Medium"
                        });
                    }
                }

                // 4. Check file location
                string dirLower = Path.GetDirectoryName(filePath)?.ToLowerInvariant() ?? "";

                if (dirLower.Contains("\\temp") || dirLower.Contains("\\tmp"))
                {
                    if (result.IsExecutable)
                    {
                        score += 20;
                        indicators.Add(new ThreatIndicator
                        {
                            Name = "Executable in Temp Directory",
                            Description = "Executables running from temp folders are a common malware pattern",
                            Points = 20,
                            Severity = "Medium"
                        });
                    }
                }

                if (dirLower.Contains("\\appdata\\roaming") && result.IsExecutable)
                {
                    score += 10;
                    indicators.Add(new ThreatIndicator
                    {
                        Name = "Executable in AppData\\Roaming",
                        Description = "Many malware families hide in the Roaming profile directory",
                        Points = 10,
                        Severity = "Low"
                    });
                }

                if (dirLower.Contains("\\downloads") && result.IsExecutable)
                {
                    score += 5;
                    indicators.Add(new ThreatIndicator
                    {
                        Name = "Executable in Downloads",
                        Description = "Downloaded executable — verify you trust the source",
                        Points = 5,
                        Severity = "Low"
                    });
                }

                // 5. Suspicious string analysis (for text-readable files or small executables)
                if (fileBytes.Length > 0 && fileBytes.Length < 5 * 1024 * 1024)
                {
                    string content = "";
                    try { content = Encoding.ASCII.GetString(fileBytes); } catch { }

                    if (!string.IsNullOrEmpty(content))
                    {
                        int suspiciousMatches = 0;
                        var matchedStrings = new List<string>();

                        foreach (var pattern in ThreatDatabase.SuspiciousStrings)
                        {
                            if (content.Contains(pattern, StringComparison.OrdinalIgnoreCase))
                            {
                                suspiciousMatches++;
                                if (matchedStrings.Count < 5)
                                    matchedStrings.Add(pattern);
                            }
                        }

                        if (suspiciousMatches > 0)
                        {
                            int pts = Math.Min(suspiciousMatches * 8, 40);
                            score += pts;
                            indicators.Add(new ThreatIndicator
                            {
                                Name = $"Suspicious Strings ({suspiciousMatches} matches)",
                                Description = $"Contains: {string.Join(", ", matchedStrings.Take(3))}",
                                Points = pts,
                                Severity = suspiciousMatches > 3 ? "High" : "Medium"
                            });
                        }

                        // Base64 blob detection
                        var base64Regex = new Regex(@"[A-Za-z0-9+/]{100,}={0,2}", RegexOptions.None,
                            TimeSpan.FromMilliseconds(500));
                        try
                        {
                            if (base64Regex.IsMatch(content))
                            {
                                score += 10;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Large Base64 Encoded Block",
                                    Description = "File contains large base64 data, often used to hide payloads",
                                    Points = 10,
                                    Severity = "Medium"
                                });
                            }
                        }
                        catch { }
                    }
                }

                // 6. PE header checks for executables
                if (fileBytes.Length >= 2 && fileBytes[0] == 0x4D && fileBytes[1] == 0x5A) // MZ header
                {
                    // Check for double extension trick
                    string name = info.Name;
                    if (name.Count(c => c == '.') > 1)
                    {
                        score += 25;
                        indicators.Add(new ThreatIndicator
                        {
                            Name = "Double Extension",
                            Description = $"File uses multiple extensions ({name}) — common social engineering trick",
                            Points = 25,
                            Severity = "High"
                        });
                    }

                    // Very small PE file (likely dropper/loader)
                    if (info.Length < 50 * 1024 && info.Length > 1024)
                    {
                        score += 10;
                        indicators.Add(new ThreatIndicator
                        {
                            Name = "Unusually Small Executable",
                            Description = $"PE file is only {info.Length / 1024}KB — could be a dropper or loader",
                            Points = 10,
                            Severity = "Low"
                        });
                    }
                }

                // 7. Hidden file that's executable
                if (info.Attributes.HasFlag(FileAttributes.Hidden) && result.IsExecutable)
                {
                    score += 15;
                    indicators.Add(new ThreatIndicator
                    {
                        Name = "Hidden Executable",
                        Description = "File is both hidden and executable — suspicious combination",
                        Points = 15,
                        Severity = "Medium"
                    });
                }
            }
            catch { }

            result.ThreatScore = Math.Min(score, 100);
            result.Indicators = indicators;
            result.ThreatLevel = result.ThreatScore switch
            {
                >= 80 => "Critical",
                >= 60 => "High",
                >= 35 => "Medium",
                >= 10 => "Low",
                _ => "Clean"
            };

            return result;
        }

        // ── Process Scanning ───────────────────────────────────────────
        public static List<ProcessScanResult> ScanProcesses()
        {
            var results = new List<ProcessScanResult>();

            Process[] procs;
            try { procs = Process.GetProcesses(); }
            catch { return results; }

            foreach (var proc in procs)
            {
                try
                {
                    int pid = 0;
                    string name = "";
                    string path = "";
                    double memMB = 0;

                    try { pid = proc.Id; } catch { continue; }
                    try { name = proc.ProcessName; } catch { continue; }
                    try { path = proc.MainModule?.FileName ?? ""; } catch { path = ""; }
                    try { memMB = proc.WorkingSet64 / (1024.0 * 1024); } catch { }

                    if (pid <= 4) continue;

                    var indicators = new List<ThreatIndicator>();
                    int score = 0;

                    // Skip known trusted processes
                    bool trusted = ThreatDatabase.TrustedProcesses.Contains(name);

                    if (!trusted && !string.IsNullOrEmpty(path))
                    {
                        string pathLower = path.ToLowerInvariant();

                        // Running from temp
                        if (pathLower.Contains("\\temp\\") || pathLower.Contains("\\tmp\\"))
                        {
                            score += 30;
                            indicators.Add(new ThreatIndicator
                            {
                                Name = "Running from Temp Directory",
                                Description = $"Process is executing from a temp folder",
                                Points = 30,
                                Severity = "High"
                            });
                        }

                        // Running from AppData
                        if (pathLower.Contains("\\appdata\\") && !pathLower.Contains("\\local\\microsoft\\"))
                        {
                            score += 10;
                            indicators.Add(new ThreatIndicator
                            {
                                Name = "Running from AppData",
                                Description = "Process location in user AppData (less common for legitimate software)",
                                Points = 10,
                                Severity = "Low"
                            });
                        }

                        // Not in Program Files or Windows
                        if (!pathLower.Contains("\\program files") &&
                            !pathLower.Contains("\\windows\\") &&
                            !pathLower.Contains("\\programdata\\"))
                        {
                            score += 5;
                            indicators.Add(new ThreatIndicator
                            {
                                Name = "Non-Standard Location",
                                Description = "Process is not in a standard installation directory",
                                Points = 5,
                                Severity = "Low"
                            });
                        }
                    }
                    else if (!trusted && string.IsNullOrEmpty(path))
                    {
                        score += 15;
                        indicators.Add(new ThreatIndicator
                        {
                            Name = "Unknown Path",
                            Description = "Could not determine the executable path for this process",
                            Points = 15,
                            Severity = "Medium"
                        });
                    }

                    // Suspicious process name patterns
                    if (!trusted)
                    {
                        // Process mimicking system names with slight variations
                        string nameLower = name.ToLowerInvariant();
                        var mimicTargets = new[] { "svchost", "csrss", "lsass", "explorer", "services" };
                        foreach (var target in mimicTargets)
                        {
                            if (nameLower != target &&
                                (nameLower.Contains(target) || LevenshteinDistance(nameLower, target) <= 2))
                            {
                                score += 35;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Process Name Mimicry",
                                    Description = $"Name '{name}' resembles system process '{target}' — possible impersonation",
                                    Points = 35,
                                    Severity = "High"
                                });
                                break;
                            }
                        }
                    }

                    score = Math.Min(score, 100);

                    results.Add(new ProcessScanResult
                    {
                        Pid = pid,
                        Name = name,
                        Path = path,
                        ThreatScore = score,
                        ThreatLevel = score switch
                        {
                            >= 80 => "Critical",
                            >= 60 => "High",
                            >= 35 => "Medium",
                            >= 10 => "Low",
                            _ => "Clean"
                        },
                        Indicators = indicators,
                        MemoryMB = memMB,
                    });
                }
                catch { }
                finally
                {
                    try { proc.Dispose(); } catch { }
                }
            }

            return results.OrderByDescending(r => r.ThreatScore).ToList();
        }

        // ── Startup Item Analysis ──────────────────────────────────────
        public static List<StartupEntry> ScanStartupItems()
        {
            var results = new List<StartupEntry>();

            // Registry Run keys
            var regLocations = new[]
            {
                (@"HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU\\Run"),
                (@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM\\Run"),
                (@"HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU\\RunOnce"),
                (@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM\\RunOnce"),
            };

            foreach (var (regPath, label) in regLocations)
            {
                try
                {
                    // Use RegistryKey directly
                    string hivePath = regPath.Replace("HKEY_CURRENT_USER\\", "").Replace("HKEY_LOCAL_MACHINE\\", "");
                    Microsoft.Win32.RegistryKey? hive = regPath.StartsWith("HKEY_CURRENT_USER")
                        ? Microsoft.Win32.Registry.CurrentUser
                        : Microsoft.Win32.Registry.LocalMachine;

                    using var subKey = hive?.OpenSubKey(hivePath);
                    if (subKey == null) continue;

                    foreach (var valueName in subKey.GetValueNames())
                    {
                        try
                        {
                            string command = subKey.GetValue(valueName)?.ToString() ?? "";
                            if (string.IsNullOrWhiteSpace(command)) continue;

                            var indicators = new List<ThreatIndicator>();
                            int score = 0;

                            string cmdLower = command.ToLowerInvariant();

                            // Check if pointing to temp/appdata
                            if (cmdLower.Contains("\\temp\\") || cmdLower.Contains("\\tmp\\"))
                            {
                                score += 35;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Startup from Temp",
                                    Description = "Startup entry points to temp directory — highly suspicious",
                                    Points = 35,
                                    Severity = "High"
                                });
                            }

                            if (cmdLower.Contains("\\appdata\\"))
                            {
                                score += 10;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Startup from AppData",
                                    Description = "Runs from AppData on startup",
                                    Points = 10,
                                    Severity = "Low"
                                });
                            }

                            // PowerShell/cmd in startup
                            if (cmdLower.Contains("powershell") || cmdLower.Contains("cmd /c") ||
                                cmdLower.Contains("wscript") || cmdLower.Contains("cscript"))
                            {
                                score += 25;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Script Engine in Startup",
                                    Description = "Uses a script interpreter (PowerShell/CMD/WScript) at startup",
                                    Points = 25,
                                    Severity = "Medium"
                                });
                            }

                            // Encoded/hidden commands
                            if (cmdLower.Contains("-enc") || cmdLower.Contains("-w hidden") ||
                                cmdLower.Contains("frombase64"))
                            {
                                score += 40;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Obfuscated Startup Command",
                                    Description = "Startup command uses encoding or hidden windows",
                                    Points = 40,
                                    Severity = "Critical"
                                });
                            }

                            // Check if the target executable exists
                            string exePath = ExtractExePath(command);
                            if (!string.IsNullOrEmpty(exePath) && !File.Exists(exePath))
                            {
                                score += 5;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Missing Executable",
                                    Description = "The startup target file does not exist (orphaned entry)",
                                    Points = 5,
                                    Severity = "Low"
                                });
                            }

                            score = Math.Min(score, 100);

                            results.Add(new StartupEntry
                            {
                                Name = valueName,
                                Command = command,
                                Location = label,
                                ThreatScore = score,
                                ThreatLevel = score switch
                                {
                                    >= 80 => "Critical",
                                    >= 60 => "High",
                                    >= 35 => "Medium",
                                    >= 10 => "Low",
                                    _ => "Clean"
                                },
                                Indicators = indicators,
                            });
                        }
                        catch { }
                    }
                }
                catch { }
            }

            // Startup folder
            try
            {
                string startupFolder = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
                if (Directory.Exists(startupFolder))
                {
                    foreach (var file in Directory.GetFiles(startupFolder))
                    {
                        try
                        {
                            var info = new FileInfo(file);
                            var indicators = new List<ThreatIndicator>();
                            int score = 0;

                            if (info.Extension.Equals(".bat", StringComparison.OrdinalIgnoreCase) ||
                                info.Extension.Equals(".cmd", StringComparison.OrdinalIgnoreCase) ||
                                info.Extension.Equals(".vbs", StringComparison.OrdinalIgnoreCase) ||
                                info.Extension.Equals(".ps1", StringComparison.OrdinalIgnoreCase))
                            {
                                score += 15;
                                indicators.Add(new ThreatIndicator
                                {
                                    Name = "Script in Startup Folder",
                                    Description = $"Script file ({info.Extension}) in user startup folder",
                                    Points = 15,
                                    Severity = "Medium"
                                });
                            }

                            results.Add(new StartupEntry
                            {
                                Name = info.Name,
                                Command = file,
                                Location = "Startup Folder",
                                ThreatScore = Math.Min(score, 100),
                                ThreatLevel = score >= 35 ? "Medium" : score >= 10 ? "Low" : "Clean",
                                Indicators = indicators,
                            });
                        }
                        catch { }
                    }
                }
            }
            catch { }

            return results.OrderByDescending(r => r.ThreatScore).ToList();
        }

        // ── Full System Scan ───────────────────────────────────────────
        public static async Task<FullScanResult> RunFullScanAsync(
            string[] directories,
            bool deepScan,
            IProgress<(string message, int count)>? progress = null,
            CancellationToken ct = default)
        {
            var stopwatch = Stopwatch.StartNew();
            var result = new FullScanResult();

            // 1. File scan
            progress?.Report(("Scanning files...", 0));
            foreach (var dir in directories)
            {
                if (ct.IsCancellationRequested) break;
                if (!Directory.Exists(dir)) continue;

                var fileResults = await ScanDirectoryAsync(dir, deepScan, progress, ct);
                result.FileResults.AddRange(fileResults);
                result.FilesScanned += fileResults.Count;
            }
            result.ThreatsFound = result.FileResults.Count(f => f.ThreatScore >= 10);

            // 2. Process scan
            if (!ct.IsCancellationRequested)
            {
                progress?.Report(("Scanning running processes...", result.FilesScanned));
                result.ProcessResults = ScanProcesses();
                result.ProcessesScanned = result.ProcessResults.Count;
                result.SuspiciousProcesses = result.ProcessResults.Count(p => p.ThreatScore >= 10);
            }

            // 3. Startup scan
            if (!ct.IsCancellationRequested)
            {
                progress?.Report(("Analyzing startup items...", result.FilesScanned));
                result.StartupResults = ScanStartupItems();
                result.StartupItemsScanned = result.StartupResults.Count;
                result.SuspiciousStartupItems = result.StartupResults.Count(s => s.ThreatScore >= 10);
            }

            stopwatch.Stop();
            result.Duration = stopwatch.Elapsed;

            return result;
        }

        // ── Utility Methods ────────────────────────────────────────────
        private static string ComputeSHA256(string filePath)
        {
            try
            {
                using var sha = SHA256.Create();
                using var fs = File.OpenRead(filePath);
                var hash = sha.ComputeHash(fs);
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
            catch { return ""; }
        }

        private static string ComputeMD5(string filePath)
        {
            try
            {
                using var md5 = MD5.Create();
                using var fs = File.OpenRead(filePath);
                var hash = md5.ComputeHash(fs);
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
            catch { return ""; }
        }

        private static double CalculateEntropy(byte[] data)
        {
            if (data.Length == 0) return 0;

            var freq = new int[256];
            foreach (byte b in data) freq[b]++;

            double entropy = 0;
            double len = data.Length;
            for (int i = 0; i < 256; i++)
            {
                if (freq[i] == 0) continue;
                double p = freq[i] / len;
                entropy -= p * Math.Log2(p);
            }
            return entropy;
        }

        private static string ExtractExePath(string command)
        {
            try
            {
                command = command.Trim();
                if (command.StartsWith("\""))
                {
                    int end = command.IndexOf("\"", 1);
                    return end > 0 ? command.Substring(1, end - 1) : "";
                }
                int space = command.IndexOf(' ');
                return space > 0 ? command.Substring(0, space) : command;
            }
            catch { return ""; }
        }

        private static int LevenshteinDistance(string s, string t)
        {
            int n = s.Length, m = t.Length;
            var d = new int[n + 1, m + 1];
            for (int i = 0; i <= n; i++) d[i, 0] = i;
            for (int j = 0; j <= m; j++) d[0, j] = j;
            for (int i = 1; i <= n; i++)
                for (int j = 1; j <= m; j++)
                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + (s[i - 1] == t[j - 1] ? 0 : 1));
            return d[n, m];
        }
    }
}
