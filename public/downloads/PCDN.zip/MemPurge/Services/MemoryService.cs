using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace MemPurge.Services
{
    /// <summary>
    /// Core memory management engine. Every public method is designed to never throw.
    /// </summary>
    public class MemoryService
    {
        private static readonly HashSet<string> CriticalProcesses = new(StringComparer.OrdinalIgnoreCase)
        {
            "system", "idle", "smss", "csrss", "wininit", "services", "lsass", "lsaiso",
            "svchost", "fontdrvhost", "dwm", "winlogon", "logonui",
            "memory compression", "registry", "secure system",
            "ntoskrnl", "audiodg", "spoolsv", "searchindexer",
            "msmpsvc", "msmpeng", "nissrv",
        };

        // ── Privilege Elevation ────────────────────────────────────────
        public static bool EnablePrivileges()
        {
            try
            {
                bool allOk = true;
                allOk &= EnablePrivilege(NativeMethods.SE_DEBUG_NAME);
                allOk &= EnablePrivilege(NativeMethods.SE_INCREASE_QUOTA_NAME);
                allOk &= EnablePrivilege(NativeMethods.SE_PROF_SINGLE_PROCESS_NAME);
                return allOk;
            }
            catch
            {
                return false;
            }
        }

        private static bool EnablePrivilege(string privilegeName)
        {
            try
            {
                if (!NativeMethods.OpenProcessToken(
                        NativeMethods.GetCurrentProcess(),
                        NativeMethods.TOKEN_ADJUST_PRIVILEGES | NativeMethods.TOKEN_QUERY,
                        out IntPtr tokenHandle))
                    return false;

                try
                {
                    if (!NativeMethods.LookupPrivilegeValue(null, privilegeName, out var luid))
                        return false;

                    var tp = new NativeMethods.TOKEN_PRIVILEGES
                    {
                        PrivilegeCount = 1,
                        Privileges = new NativeMethods.LUID_AND_ATTRIBUTES
                        {
                            Luid = luid,
                            Attributes = NativeMethods.SE_PRIVILEGE_ENABLED
                        }
                    };

                    return NativeMethods.AdjustTokenPrivileges(
                        tokenHandle, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
                }
                finally
                {
                    NativeMethods.CloseHandle(tokenHandle);
                }
            }
            catch
            {
                return false;
            }
        }

        // ── Memory Info ────────────────────────────────────────────────
        public static MemoryInfo GetMemoryInfo()
        {
            try
            {
                var memStatus = new NativeMethods.MEMORYSTATUSEX
                {
                    dwLength = (uint)Marshal.SizeOf<NativeMethods.MEMORYSTATUSEX>()
                };
                NativeMethods.GlobalMemoryStatusEx(ref memStatus);

                return new MemoryInfo
                {
                    TotalPhysicalBytes = memStatus.ullTotalPhys,
                    AvailablePhysicalBytes = memStatus.ullAvailPhys,
                    UsedPhysicalBytes = memStatus.ullTotalPhys - memStatus.ullAvailPhys,
                    MemoryLoadPercent = memStatus.dwMemoryLoad,
                    TotalPageFileBytes = memStatus.ullTotalPageFile,
                    AvailablePageFileBytes = memStatus.ullAvailPageFile,
                };
            }
            catch
            {
                return new MemoryInfo();
            }
        }

        // ── Working Set Cleanup ────────────────────────────────────────
        public static CleanResult CleanWorkingSets(bool smartMode = true)
        {
            var result = new CleanResult();

            try
            {
                var before = GetMemoryInfo();
                Process[] processes;

                try { processes = Process.GetProcesses(); }
                catch { return result; }

                foreach (var proc in processes)
                {
                    try
                    {
                        int pid = 0;
                        try { pid = proc.Id; } catch { continue; }

                        if (pid <= 4)
                        {
                            result.SkippedCount++;
                            continue;
                        }

                        if (smartMode && IsCriticalProcess(proc))
                        {
                            result.SkippedCount++;
                            continue;
                        }

                        IntPtr hProcess = NativeMethods.OpenProcess(
                            NativeMethods.PROCESS_QUERY_INFORMATION | NativeMethods.PROCESS_SET_QUOTA,
                            false,
                            (uint)pid);

                        if (hProcess != IntPtr.Zero)
                        {
                            try
                            {
                                if (NativeMethods.EmptyWorkingSet(hProcess))
                                    result.CleanedCount++;
                                else
                                    result.FailedCount++;
                            }
                            finally
                            {
                                NativeMethods.CloseHandle(hProcess);
                            }
                        }
                        else
                        {
                            result.FailedCount++;
                        }
                    }
                    catch
                    {
                        result.FailedCount++;
                    }
                    finally
                    {
                        try { proc.Dispose(); } catch { }
                    }
                }

                var after = GetMemoryInfo();
                result.BytesFreed = after.AvailablePhysicalBytes > before.AvailablePhysicalBytes
                    ? after.AvailablePhysicalBytes - before.AvailablePhysicalBytes
                    : 0;
            }
            catch { }

            return result;
        }

        // ── Standby List Purge ─────────────────────────────────────────
        public static CleanResult PurgeStandbyList()
        {
            var result = new CleanResult();

            try
            {
                var before = GetMemoryInfo();

                int command = NativeMethods.MemoryPurgeStandbyList;
                int status = NativeMethods.NtSetSystemInformation(
                    NativeMethods.SystemMemoryListInformation,
                    ref command,
                    sizeof(int));

                result.Success = (status >= 0);
                if (!result.Success)
                    result.ErrorMessage = $"NtSetSystemInformation returned 0x{status:X8}";

                var after = GetMemoryInfo();
                result.BytesFreed = after.AvailablePhysicalBytes > before.AvailablePhysicalBytes
                    ? after.AvailablePhysicalBytes - before.AvailablePhysicalBytes
                    : 0;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
            }

            return result;
        }

        public static CleanResult FlushModifiedList()
        {
            var result = new CleanResult();

            try
            {
                int command = NativeMethods.MemoryFlushModifiedList;
                int status = NativeMethods.NtSetSystemInformation(
                    NativeMethods.SystemMemoryListInformation,
                    ref command,
                    sizeof(int));

                result.Success = (status >= 0);
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
            }

            return result;
        }

        // ── Full Clean ─────────────────────────────────────────────────
        public static FullCleanResult FullClean(bool smartMode = true)
        {
            var fullResult = new FullCleanResult { Timestamp = DateTime.Now };

            try
            {
                var totalBefore = GetMemoryInfo();

                fullResult.WorkingSetResult = CleanWorkingSets(smartMode);
                fullResult.FlushResult = FlushModifiedList();
                fullResult.StandbyResult = PurgeStandbyList();

                fullResult.MemoryBefore = totalBefore;
                fullResult.MemoryAfter = GetMemoryInfo();

                fullResult.TotalBytesFreed =
                    fullResult.MemoryAfter.AvailablePhysicalBytes > totalBefore.AvailablePhysicalBytes
                        ? fullResult.MemoryAfter.AvailablePhysicalBytes - totalBefore.AvailablePhysicalBytes
                        : 0;
            }
            catch { }

            return fullResult;
        }

        // ── Clean Specific Process ─────────────────────────────────────
        public static bool CleanProcess(int processId)
        {
            try
            {
                IntPtr hProcess = NativeMethods.OpenProcess(
                    NativeMethods.PROCESS_QUERY_INFORMATION | NativeMethods.PROCESS_SET_QUOTA,
                    false,
                    (uint)processId);

                if (hProcess == IntPtr.Zero) return false;

                try
                {
                    return NativeMethods.EmptyWorkingSet(hProcess);
                }
                finally
                {
                    NativeMethods.CloseHandle(hProcess);
                }
            }
            catch
            {
                return false;
            }
        }

        // ── Process Enumeration (HARDENED) ─────────────────────────────
        public static List<ProcessInfo> GetProcessList()
        {
            var list = new List<ProcessInfo>();

            Process[] processes;
            try { processes = Process.GetProcesses(); }
            catch { return list; }

            foreach (var proc in processes)
            {
                try
                {
                    // Each property access can throw — wrap individually
                    int pid = 0;
                    string name = "";
                    long memBytes = 0;

                    try { pid = proc.Id; } catch { continue; }
                    try { name = proc.ProcessName; } catch { name = $"PID_{pid}"; }
                    try { memBytes = proc.WorkingSet64; } catch { }

                    bool critical = false;
                    try { critical = IsCriticalProcess(pid, name); } catch { }

                    if (memBytes > 0 || critical)
                    {
                        list.Add(new ProcessInfo
                        {
                            Pid = pid,
                            Name = name,
                            MemoryBytes = memBytes,
                            IsCritical = critical,
                        });
                    }
                }
                catch { }
                finally
                {
                    try { proc.Dispose(); } catch { }
                }
            }

            try { return list.OrderByDescending(p => p.MemoryBytes).ToList(); }
            catch { return list; }
        }

        // ── Safety Checks (no Process object needed) ───────────────────
        public static bool IsCriticalProcess(Process proc)
        {
            try
            {
                int pid = 0;
                string name = "";
                try { pid = proc.Id; } catch { return true; }
                try { name = proc.ProcessName; } catch { return true; }
                return IsCriticalProcess(pid, name);
            }
            catch
            {
                return true;
            }
        }

        public static bool IsCriticalProcess(int pid, string name)
        {
            try
            {
                if (pid <= 4) return true;

                if (CriticalProcesses.Contains(name))
                    return true;

                if (pid == Environment.ProcessId)
                    return true;

                return false;
            }
            catch
            {
                return true;
            }
        }
    }

    // ── Data Classes ───────────────────────────────────────────────────

    public class MemoryInfo
    {
        public ulong TotalPhysicalBytes { get; set; }
        public ulong AvailablePhysicalBytes { get; set; }
        public ulong UsedPhysicalBytes { get; set; }
        public uint MemoryLoadPercent { get; set; }
        public ulong TotalPageFileBytes { get; set; }
        public ulong AvailablePageFileBytes { get; set; }

        public double TotalGB => TotalPhysicalBytes / (1024.0 * 1024 * 1024);
        public double UsedGB => UsedPhysicalBytes / (1024.0 * 1024 * 1024);
        public double AvailableGB => AvailablePhysicalBytes / (1024.0 * 1024 * 1024);
    }

    public class CleanResult
    {
        public int CleanedCount { get; set; }
        public int SkippedCount { get; set; }
        public int FailedCount { get; set; }
        public ulong BytesFreed { get; set; }
        public bool Success { get; set; } = true;
        public string? ErrorMessage { get; set; }

        public double MBFreed => BytesFreed / (1024.0 * 1024);
    }

    public class FullCleanResult
    {
        public CleanResult WorkingSetResult { get; set; } = new();
        public CleanResult FlushResult { get; set; } = new();
        public CleanResult StandbyResult { get; set; } = new();
        public ulong TotalBytesFreed { get; set; }
        public MemoryInfo MemoryBefore { get; set; } = new();
        public MemoryInfo MemoryAfter { get; set; } = new();
        public DateTime Timestamp { get; set; }

        public double TotalMBFreed => TotalBytesFreed / (1024.0 * 1024);
    }

    public class ProcessInfo
    {
        public int Pid { get; set; }
        public string Name { get; set; } = "";
        public long MemoryBytes { get; set; }
        public bool IsCritical { get; set; }

        public double MemoryMB => MemoryBytes / (1024.0 * 1024);
    }
}
