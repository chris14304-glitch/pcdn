# MemPurge — Real-Time Memory Optimizer

A Windows memory cleaner built with C# / WPF that uses the same kernel APIs as Mem Reduct.

## What It Does

MemPurge frees RAM using two real Windows kernel mechanisms:

1. **EmptyWorkingSet()** — Forces each process to release its physical memory pages
   back to the standby list. Apps keep running but their RAM gets reclaimed.

2. **NtSetSystemInformation(SystemMemoryListInformation)** — Purges the standby
   memory list directly. This is the call that produces the dramatic RAM drop
   you see in tools like Mem Reduct.

Additionally it calls **MemoryFlushModifiedList** to write dirty pages to disk
before purging, which is safer and more effective.

## Features

| Feature | Description |
|---------|-------------|
| **One-click clean** | Runs the full pipeline: working sets → flush → standby purge |
| **Real-time monitoring** | RAM usage updates every second with color-coded gauge |
| **Auto-clean** | Automatically triggers cleanup when RAM exceeds your threshold |
| **Smart mode** | Skips ~20 critical system processes (csrss, dwm, lsass, etc.) |
| **Process browser** | See all processes sorted by memory, clean individual ones |
| **Activity log** | Full audit trail of every cleanup with timestamps |
| **Dark UI** | Professional dark theme matching the React prototype |

## Project Structure

```
MemPurge/
├── MemPurge.sln                    # Solution file (open this in VS)
├── MemPurge.csproj                 # .NET 8 WPF project
├── app.manifest                    # Requires administrator elevation
├── App.xaml / App.xaml.cs          # Application entry point
├── Services/
│   ├── NativeMethods.cs            # P/Invoke declarations (kernel32, ntdll, psapi, advapi32)
│   └── MemoryService.cs            # Core engine: clean, purge, enumerate
├── ViewModels/
│   ├── ViewModelBase.cs            # INotifyPropertyChanged base
│   ├── RelayCommand.cs             # ICommand implementation
│   └── MainViewModel.cs            # Application state + logic
├── Views/
│   ├── MainWindow.xaml             # Full WPF UI (dark theme)
│   └── MainWindow.xaml.cs          # Code-behind + custom converters
├── Converters/
│   └── Converters.cs               # WPF value converters
└── Assets/
    └── icon.ico                    # (add your own app icon)
```

## Requirements

- **Windows 10/11**
- **.NET 8 SDK** — [Download](https://dotnet.microsoft.com/download/dotnet/8.0)
- **Visual Studio 2022** (17.8+) with the ".NET Desktop Development" workload
- **Administrator privileges** (required for kernel memory APIs)

## Build & Run

### Option 1: Visual Studio
1. Open `MemPurge.sln` in Visual Studio 2022
2. Set configuration to `Release`
3. Build → Build Solution (Ctrl+Shift+B)
4. Run with F5 (will prompt for admin elevation via UAC)

### Option 2: Command Line
```bash
cd MemPurge
dotnet build -c Release
```

Then run the exe from `bin/Release/net8.0-windows/MemPurge.exe` as Administrator.

### Option 3: Publish as Single File
```bash
dotnet publish -c Release -r win-x64 --self-contained -p:PublishSingleFile=true
```

This creates a single `MemPurge.exe` in `bin/Release/net8.0-windows/win-x64/publish/`.

## How the Kernel APIs Work

### EmptyWorkingSet (psapi.dll)
```
For each process:
  OpenProcess(PROCESS_SET_QUOTA | PROCESS_QUERY_INFORMATION)
  EmptyWorkingSet(hProcess)
  CloseHandle(hProcess)
```
This tells Windows to trim the process's working set — physical pages move to
the standby list but aren't lost (they'll be pulled back if the process needs them).

### NtSetSystemInformation (ntdll.dll)
```
int command = 4;  // MemoryPurgeStandbyList
NtSetSystemInformation(80, &command, sizeof(int));
```
- Class 80 = SystemMemoryListInformation
- Command 4 = Purge the entire standby list
- Command 5 = Purge only low-priority standby pages (less aggressive)
- Command 3 = Flush modified page list (write dirty pages to disk)

### Required Privileges
The app elevates these token privileges at startup:
- **SeDebugPrivilege** — Access any process regardless of security descriptor
- **SeIncreaseQuotaPrivilege** — Adjust process working set sizes
- **SeProfileSingleProcessPrivilege** — Call NtSetSystemInformation

## Safety

The following processes are always skipped in Smart Mode:

```
system, smss, csrss, wininit, services, lsass, lsaiso,
svchost, fontdrvhost, dwm, winlogon, logonui,
memory compression, registry, secure system,
ntoskrnl, audiodg, spoolsv, searchindexer,
msmpsvc, msmpeng, nissrv
```

Additionally, all Session 0 services and PID ≤ 4 are skipped.

## Notes

- **Performance tradeoff**: Cleaning RAM forces apps to reload from disk on
  next access. Frequent cleaning can actually *reduce* performance. Use the
  auto-clean threshold wisely (80%+ is reasonable).
- **No icon included**: Drop your own `icon.ico` into the `Assets/` folder,
  or remove the `<ApplicationIcon>` line from the .csproj.
- **Tested on**: Windows 10 22H2, Windows 11 23H2

## License

MIT — do whatever you want with it.
