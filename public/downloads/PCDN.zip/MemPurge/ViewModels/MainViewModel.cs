using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using MemPurge.Services;

namespace MemPurge.ViewModels
{
    public class LogEntry
    {
        public string Time { get; set; } = "";
        public string Message { get; set; } = "";
        public string Level { get; set; } = "Info";
    }

    /// <summary>
    /// Observable wrapper around CleanupCategory so the UI can bind to IsSelected.
    /// </summary>
    public class CleanupCategoryVM : ViewModelBase
    {
        private readonly CleanupCategory _model;

        public CleanupCategoryVM(CleanupCategory model) { _model = model; }

        public string Id => _model.Id;
        public string Name => _model.Name;
        public string Description => _model.Description;
        public long SizeBytes => _model.SizeBytes;
        public int FileCount => _model.FileCount;
        public string SizeText => _model.SizeText;
        public bool IsScanned => _model.IsScanned;

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (SetProperty(ref _isSelected, value))
                    _model.IsSelected = value;
            }
        }

        public CleanupCategory Model => _model;
    }

    public class MainViewModel : ViewModelBase
    {
        private DispatcherTimer? _memoryTimer;
        private DispatcherTimer? _autoCleanTimer;
        private DispatcherTimer? _processTimer;
        private bool _privilegesEnabled;
        private CancellationTokenSource? _scanCts;

        // ═══════════════════════════════════════════════════════════════
        // MEMORY TAB
        // ═══════════════════════════════════════════════════════════════
        private double _totalRamGB;
        private double _usedRamGB;
        private double _availableRamGB;
        private uint _memoryLoadPercent;
        private double _usedPercent;

        public double TotalRamGB { get => _totalRamGB; set => SetProperty(ref _totalRamGB, value); }
        public double UsedRamGB { get => _usedRamGB; set => SetProperty(ref _usedRamGB, value); }
        public double AvailableRamGB { get => _availableRamGB; set => SetProperty(ref _availableRamGB, value); }
        public uint MemoryLoadPercent { get => _memoryLoadPercent; set => SetProperty(ref _memoryLoadPercent, value); }
        public double UsedPercent { get => _usedPercent; set => SetProperty(ref _usedPercent, value); }

        private string _gaugeColor = "#00FFC8";
        public string GaugeColor { get => _gaugeColor; set => SetProperty(ref _gaugeColor, value); }

        private bool _isCleaning;
        private string _cleanButtonText = "CLEAN MEMORY";
        private string _statusText = "Ready";
        private string _lastCleanedText = "Never";

        public bool IsCleaning { get => _isCleaning; set { SetProperty(ref _isCleaning, value); CleanCommand?.RaiseCanExecuteChanged(); } }
        public string CleanButtonText { get => _cleanButtonText; set => SetProperty(ref _cleanButtonText, value); }
        public string StatusText { get => _statusText; set => SetProperty(ref _statusText, value); }
        public string LastCleanedText { get => _lastCleanedText; set => SetProperty(ref _lastCleanedText, value); }

        // Settings
        private bool _autoCleanEnabled;
        private int _autoCleanThreshold = 80;
        private bool _smartModeEnabled = true;
        private bool _purgeStandby = true;
        private bool _flushModified = true;
        private int _autoCleanIntervalSeconds = 30;

        public bool AutoCleanEnabled
        {
            get => _autoCleanEnabled;
            set
            {
                if (SetProperty(ref _autoCleanEnabled, value))
                {
                    try
                    {
                        if (value && _autoCleanTimer != null)
                        {
                            _autoCleanTimer.Interval = TimeSpan.FromSeconds(AutoCleanIntervalSeconds);
                            _autoCleanTimer.Start();
                            AddLog("Auto-clean enabled", "Info");
                        }
                        else
                        {
                            _autoCleanTimer?.Stop();
                            AddLog("Auto-clean disabled", "Info");
                        }
                    }
                    catch { }
                }
            }
        }

        public int AutoCleanThreshold { get => _autoCleanThreshold; set => SetProperty(ref _autoCleanThreshold, Math.Clamp(value, 50, 95)); }
        public bool SmartModeEnabled { get => _smartModeEnabled; set => SetProperty(ref _smartModeEnabled, value); }
        public bool PurgeStandby { get => _purgeStandby; set => SetProperty(ref _purgeStandby, value); }
        public bool FlushModified { get => _flushModified; set => SetProperty(ref _flushModified, value); }

        public int AutoCleanIntervalSeconds
        {
            get => _autoCleanIntervalSeconds;
            set
            {
                if (SetProperty(ref _autoCleanIntervalSeconds, Math.Clamp(value, 10, 300)))
                {
                    try
                    {
                        if (_autoCleanTimer != null && _autoCleanTimer.IsEnabled)
                            _autoCleanTimer.Interval = TimeSpan.FromSeconds(value);
                    }
                    catch { }
                }
            }
        }

        // Process list
        private ObservableCollection<ProcessInfo> _processes = new();
        public ObservableCollection<ProcessInfo> Processes { get => _processes; set => SetProperty(ref _processes, value); }

        // ═══════════════════════════════════════════════════════════════
        // DISK CLEANUP TAB
        // ═══════════════════════════════════════════════════════════════
        private bool _isScanning;
        private bool _isDiskCleaning;
        private bool _scanComplete;
        private string _diskStatusText = "Click Scan to analyze junk files";
        private string _diskTotalSizeText = "";
        private int _diskTotalFileCount;
        private long _diskTotalBytes;

        public bool IsScanning { get => _isScanning; set { SetProperty(ref _isScanning, value); ScanDiskCommand?.RaiseCanExecuteChanged(); CleanDiskCommand?.RaiseCanExecuteChanged(); } }
        public bool IsDiskCleaning { get => _isDiskCleaning; set { SetProperty(ref _isDiskCleaning, value); ScanDiskCommand?.RaiseCanExecuteChanged(); CleanDiskCommand?.RaiseCanExecuteChanged(); } }
        public bool ScanComplete { get => _scanComplete; set => SetProperty(ref _scanComplete, value); }
        public string DiskStatusText { get => _diskStatusText; set => SetProperty(ref _diskStatusText, value); }
        public string DiskTotalSizeText { get => _diskTotalSizeText; set => SetProperty(ref _diskTotalSizeText, value); }
        public int DiskTotalFileCount { get => _diskTotalFileCount; set => SetProperty(ref _diskTotalFileCount, value); }
        public long DiskTotalBytes { get => _diskTotalBytes; set => SetProperty(ref _diskTotalBytes, value); }

        public ObservableCollection<CleanupCategoryVM> CleanupCategories { get; } = new();

        // ═══════════════════════════════════════════════════════════════
        // SECURITY SCANNER TAB
        // ═══════════════════════════════════════════════════════════════
        private bool _isSecScanning;
        private bool _secScanComplete;
        private string _secStatusText = "Run a scan to check for threats";
        private bool _secDeepScan;
        private int _secFilesScanned;
        private int _secThreatsFound;
        private int _secSuspiciousProcesses;
        private int _secSuspiciousStartup;
        private string _secDurationText = "";

        public bool IsSecScanning { get => _isSecScanning; set { SetProperty(ref _isSecScanning, value); QuickScanCommand?.RaiseCanExecuteChanged(); FullScanCommand?.RaiseCanExecuteChanged(); } }
        public bool SecScanComplete { get => _secScanComplete; set => SetProperty(ref _secScanComplete, value); }
        public string SecStatusText { get => _secStatusText; set => SetProperty(ref _secStatusText, value); }
        public bool SecDeepScan { get => _secDeepScan; set => SetProperty(ref _secDeepScan, value); }
        public int SecFilesScanned { get => _secFilesScanned; set => SetProperty(ref _secFilesScanned, value); }
        public int SecThreatsFound { get => _secThreatsFound; set => SetProperty(ref _secThreatsFound, value); }
        public int SecSuspiciousProcesses { get => _secSuspiciousProcesses; set => SetProperty(ref _secSuspiciousProcesses, value); }
        public int SecSuspiciousStartup { get => _secSuspiciousStartup; set => SetProperty(ref _secSuspiciousStartup, value); }
        public string SecDurationText { get => _secDurationText; set => SetProperty(ref _secDurationText, value); }

        public ObservableCollection<FileScanResult> SecFileResults { get; } = new();
        public ObservableCollection<ProcessScanResult> SecProcessResults { get; } = new();
        public ObservableCollection<StartupEntry> SecStartupResults { get; } = new();

        // ═══════════════════════════════════════════════════════════════
        // LOG
        // ═══════════════════════════════════════════════════════════════
        public ObservableCollection<LogEntry> LogEntries { get; } = new();

        // ═══════════════════════════════════════════════════════════════
        // COMMANDS
        // ═══════════════════════════════════════════════════════════════
        public RelayCommand CleanCommand { get; }
        public RelayCommand CleanProcessCommand { get; }
        public RelayCommand RefreshProcessesCommand { get; }
        public RelayCommand ScanDiskCommand { get; }
        public RelayCommand CleanDiskCommand { get; }
        public RelayCommand SelectAllCategoriesCommand { get; }
        public RelayCommand DeselectAllCategoriesCommand { get; }
        public RelayCommand QuickScanCommand { get; }
        public RelayCommand FullScanCommand { get; }

        // ═══════════════════════════════════════════════════════════════
        // CONSTRUCTOR
        // ═══════════════════════════════════════════════════════════════
        public MainViewModel()
        {
            // Memory commands
            CleanCommand = new RelayCommand(async () => await RunFullClean(), () => !IsCleaning);
            CleanProcessCommand = new RelayCommand(param => CleanSingleProcess(param));
            RefreshProcessesCommand = new RelayCommand(() => RefreshProcessList());

            // Disk cleanup commands
            ScanDiskCommand = new RelayCommand(async () => await RunDiskScan(), () => !IsScanning && !IsDiskCleaning);
            CleanDiskCommand = new RelayCommand(async () => await RunDiskClean(), () => !IsScanning && !IsDiskCleaning && ScanComplete);
            SelectAllCategoriesCommand = new RelayCommand(() => { foreach (var c in CleanupCategories) c.IsSelected = true; });
            DeselectAllCategoriesCommand = new RelayCommand(() => { foreach (var c in CleanupCategories) c.IsSelected = false; });

            // Security scanner commands
            QuickScanCommand = new RelayCommand(async () => await RunSecurityScan(false), () => !IsSecScanning);
            FullScanCommand = new RelayCommand(async () => await RunSecurityScan(true), () => !IsSecScanning);

            // Privileges
            try
            {
                _privilegesEnabled = MemoryService.EnablePrivileges();
                AddLog(_privilegesEnabled
                    ? "Privileges enabled (Debug + Quota + Profile)"
                    : "Some privileges could not be enabled - run as Administrator",
                    _privilegesEnabled ? "Success" : "Warning");
            }
            catch (Exception ex)
            {
                _privilegesEnabled = false;
                AddLog($"Privilege setup failed: {ex.Message}", "Warning");
            }

            try { UpdateMemoryInfo(); } catch { }
            try { RefreshProcessList(); } catch { }
            AddLog("PCDN initialized", "Info");

            // Timers
            _memoryTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _memoryTimer.Tick += (_, _) => { try { UpdateMemoryInfo(); } catch { } };
            _memoryTimer.Start();

            _autoCleanTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(30) };
            _autoCleanTimer.Tick += async (_, _) => { try { await AutoCleanCheck(); } catch { } };

            _processTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            _processTimer.Tick += (_, _) => { try { RefreshProcessList(); } catch { } };
            _processTimer.Start();
        }

        // ═══════════════════════════════════════════════════════════════
        // MEMORY METHODS
        // ═══════════════════════════════════════════════════════════════
        private void UpdateMemoryInfo()
        {
            var info = MemoryService.GetMemoryInfo();
            TotalRamGB = Math.Round(info.TotalGB, 2);
            UsedRamGB = Math.Round(info.UsedGB, 2);
            AvailableRamGB = Math.Round(info.AvailableGB, 2);
            MemoryLoadPercent = info.MemoryLoadPercent;
            UsedPercent = info.MemoryLoadPercent;

            GaugeColor = info.MemoryLoadPercent switch
            {
                > 85 => "#FF3B5C",
                > 65 => "#FFAA2C",
                _ => "#00FFC8"
            };
        }

        private async Task RunFullClean()
        {
            if (IsCleaning) return;
            IsCleaning = true;
            CleanButtonText = "CLEANING...";
            StatusText = "Cleaning memory...";
            AddLog("Starting full memory cleanup...", "Info");

            try
            {
                var result = await Task.Run(() => MemoryService.FullClean(SmartModeEnabled));

                AddLog($"Working sets: {result.WorkingSetResult.CleanedCount} cleaned, " +
                       $"{result.WorkingSetResult.SkippedCount} skipped, " +
                       $"{result.WorkingSetResult.FailedCount} failed", "Info");

                if (result.StandbyResult.Success)
                    AddLog("Standby list purged successfully", "Success");
                else if (result.StandbyResult.ErrorMessage != null)
                    AddLog($"Standby purge: {result.StandbyResult.ErrorMessage}", "Warning");

                double freedMB = result.TotalMBFreed;
                string freedText = freedMB >= 1024 ? $"{freedMB / 1024:F1} GB" : $"{freedMB:F0} MB";

                AddLog($"Freed {freedText} of memory", "Success");
                StatusText = $"Freed {freedText}";
                LastCleanedText = DateTime.Now.ToString("HH:mm:ss");
            }
            catch (Exception ex)
            {
                AddLog($"Clean failed: {ex.Message}", "Error");
                StatusText = "Clean failed";
            }
            finally
            {
                IsCleaning = false;
                CleanButtonText = "CLEAN MEMORY";
                try { UpdateMemoryInfo(); } catch { }
            }
        }

        private async Task AutoCleanCheck()
        {
            if (IsCleaning) return;
            try
            {
                var info = MemoryService.GetMemoryInfo();
                if (info.MemoryLoadPercent >= AutoCleanThreshold)
                {
                    AddLog($"Auto-clean triggered (RAM at {info.MemoryLoadPercent}% >= {AutoCleanThreshold}%)", "Warning");
                    await RunFullClean();
                }
            }
            catch { }
        }

        private void CleanSingleProcess(object? param)
        {
            try
            {
                if (param is int pid)
                {
                    bool ok = MemoryService.CleanProcess(pid);
                    AddLog(ok ? $"Cleaned process PID {pid}" : $"Failed to clean PID {pid}", ok ? "Success" : "Warning");
                    RefreshProcessList();
                }
            }
            catch (Exception ex) { AddLog($"Process clean error: {ex.Message}", "Error"); }
        }

        private void RefreshProcessList()
        {
            try
            {
                var procList = MemoryService.GetProcessList().Where(p => p.MemoryMB > 1).Take(50).ToList();
                Processes.Clear();
                foreach (var p in procList) Processes.Add(p);
            }
            catch { }
        }

        // ═══════════════════════════════════════════════════════════════
        // DISK CLEANUP METHODS
        // ═══════════════════════════════════════════════════════════════
        private async Task RunDiskScan()
        {
            if (IsScanning) return;

            IsScanning = true;
            ScanComplete = false;
            DiskStatusText = "Scanning...";
            CleanupCategories.Clear();
            AddLog("Disk cleanup scan started...", "Info");

            _scanCts?.Cancel();
            _scanCts = new CancellationTokenSource();

            try
            {
                var progress = new Progress<string>(msg => DiskStatusText = msg);
                var categories = await DiskCleanupService.ScanAsync(progress, _scanCts.Token);

                long totalBytes = 0;
                int totalFiles = 0;

                foreach (var cat in categories)
                {
                    CleanupCategories.Add(new CleanupCategoryVM(cat));
                    totalBytes += cat.SizeBytes;
                    totalFiles += cat.FileCount;
                }

                DiskTotalBytes = totalBytes;
                DiskTotalFileCount = totalFiles;

                if (totalBytes >= 1024L * 1024 * 1024)
                    DiskTotalSizeText = $"{totalBytes / (1024.0 * 1024 * 1024):F2} GB";
                else if (totalBytes >= 1024 * 1024)
                    DiskTotalSizeText = $"{totalBytes / (1024.0 * 1024):F1} MB";
                else
                    DiskTotalSizeText = $"{totalBytes / 1024.0:F0} KB";

                ScanComplete = true;
                DiskStatusText = $"Scan complete: {DiskTotalSizeText} in {totalFiles:N0} files can be cleaned";
                AddLog($"Disk scan found {DiskTotalSizeText} across {totalFiles:N0} files in {categories.Count} categories", "Success");
            }
            catch (OperationCanceledException)
            {
                DiskStatusText = "Scan cancelled";
                AddLog("Disk scan cancelled", "Warning");
            }
            catch (Exception ex)
            {
                DiskStatusText = $"Scan error: {ex.Message}";
                AddLog($"Disk scan error: {ex.Message}", "Error");
            }
            finally
            {
                IsScanning = false;
                CleanDiskCommand?.RaiseCanExecuteChanged();
            }
        }

        private async Task RunDiskClean()
        {
            var selected = CleanupCategories.Where(c => c.IsSelected).ToList();
            if (selected.Count == 0)
            {
                DiskStatusText = "No categories selected. Check the boxes next to items to clean.";
                return;
            }

            IsDiskCleaning = true;
            DiskStatusText = "Cleaning selected files...";
            AddLog($"Disk cleanup started for {selected.Count} categories...", "Info");

            try
            {
                var models = selected.Select(c => c.Model).ToList();
                var progress = new Progress<string>(msg => DiskStatusText = msg);
                var result = await DiskCleanupService.CleanAsync(models, progress, CancellationToken.None);

                DiskStatusText = $"Cleaned {result.SizeText} ({result.FilesCleaned:N0} files deleted, {result.FilesSkipped:N0} skipped)";
                AddLog($"Disk cleanup complete: {result.SizeText} freed, {result.FilesCleaned:N0} files deleted", "Success");

                // Re-scan to update numbers
                ScanComplete = false;
                CleanupCategories.Clear();
            }
            catch (Exception ex)
            {
                DiskStatusText = $"Cleanup error: {ex.Message}";
                AddLog($"Disk cleanup error: {ex.Message}", "Error");
            }
            finally
            {
                IsDiskCleaning = false;
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // SECURITY SCANNER METHODS
        // ═══════════════════════════════════════════════════════════════
        private CancellationTokenSource? _secScanCts;

        private async Task RunSecurityScan(bool deep)
        {
            if (IsSecScanning) return;

            IsSecScanning = true;
            SecScanComplete = false;
            SecStatusText = deep ? "Running deep scan..." : "Running quick scan...";
            SecFileResults.Clear();
            SecProcessResults.Clear();
            SecStartupResults.Clear();
            AddLog($"Security {(deep ? "deep" : "quick")} scan started...", "Info");

            _secScanCts?.Cancel();
            _secScanCts = new CancellationTokenSource();

            try
            {
                string[] scanDirs;
                if (deep)
                {
                    scanDirs = new string[]
                    {
                        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                        Path.GetTempPath(),
                        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                        @"C:\Windows\Temp",
                    };
                }
                else
                {
                    scanDirs = new string[]
                    {
                        Path.GetTempPath(),
                        Environment.GetFolderPath(Environment.SpecialFolder.Startup),
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"),
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Desktop"),
                    };
                }

                var progress = new Progress<(string message, int count)>(update =>
                {
                    SecStatusText = update.message;
                    SecFilesScanned = update.count;
                });

                var result = await SecurityScannerService.RunFullScanAsync(scanDirs, deep, progress, _secScanCts.Token);

                // Populate results
                foreach (var f in result.FileResults.Where(f => f.ThreatScore >= 5).Take(100))
                    SecFileResults.Add(f);
                foreach (var p in result.ProcessResults.Where(p => p.ThreatScore >= 5).Take(50))
                    SecProcessResults.Add(p);
                foreach (var s in result.StartupResults)
                    SecStartupResults.Add(s);

                SecFilesScanned = result.FilesScanned;
                SecThreatsFound = result.ThreatsFound;
                SecSuspiciousProcesses = result.SuspiciousProcesses;
                SecSuspiciousStartup = result.SuspiciousStartupItems;
                SecDurationText = $"{result.Duration.TotalSeconds:F1}s";
                SecScanComplete = true;

                int totalIssues = result.ThreatsFound + result.SuspiciousProcesses + result.SuspiciousStartupItems;
                SecStatusText = totalIssues > 0
                    ? $"Scan complete: {totalIssues} potential issue(s) found in {SecDurationText}"
                    : $"Scan complete: No threats detected ({SecDurationText})";

                AddLog($"Security scan complete: {result.FilesScanned} files, {totalIssues} issues, {SecDurationText}", 
                       totalIssues > 0 ? "Warning" : "Success");
            }
            catch (OperationCanceledException)
            {
                SecStatusText = "Scan cancelled";
                AddLog("Security scan cancelled", "Warning");
            }
            catch (Exception ex)
            {
                SecStatusText = $"Scan error: {ex.Message}";
                AddLog($"Security scan error: {ex.Message}", "Error");
            }
            finally
            {
                IsSecScanning = false;
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // LOGGING
        // ═══════════════════════════════════════════════════════════════
        private void AddLog(string message, string level = "Info")
        {
            try
            {
                LogEntries.Insert(0, new LogEntry
                {
                    Time = DateTime.Now.ToString("HH:mm:ss"),
                    Message = message,
                    Level = level,
                });
                while (LogEntries.Count > 200)
                    LogEntries.RemoveAt(LogEntries.Count - 1);
            }
            catch { }
        }

        public void Dispose()
        {
            try { _memoryTimer?.Stop(); } catch { }
            try { _autoCleanTimer?.Stop(); } catch { }
            try { _processTimer?.Stop(); } catch { }
            try { _scanCts?.Cancel(); } catch { }
            try { _secScanCts?.Cancel(); } catch { }
        }
    }
}
