using System;
using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace MemPurge
{
    public partial class App : Application
    {
        private bool _hasShownError = false;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            DispatcherUnhandledException += OnDispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;
        }

        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            // Always swallow so timers don't cascade errors
            e.Handled = true;

            // Write to crash log
            WriteCrashLog(e.Exception);

            // Only show ONE dialog to the user
            if (!_hasShownError)
            {
                _hasShownError = true;
                MessageBox.Show(
                    $"An error occurred (details written to crash.log):\n\n{e.Exception.GetType().Name}: {e.Exception.Message}",
                    "MemPurge Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                // Reset after 3 seconds so new *different* errors can still show
                var resetTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3) };
                resetTimer.Tick += (_, _) => { _hasShownError = false; resetTimer.Stop(); };
                resetTimer.Start();
            }
        }

        private void OnDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
            {
                WriteCrashLog(ex);

                if (!_hasShownError)
                {
                    _hasShownError = true;
                    MessageBox.Show(
                        $"A fatal error occurred (details written to crash.log):\n\n{ex.GetType().Name}: {ex.Message}",
                        "MemPurge Fatal Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
            }
        }

        private static void WriteCrashLog(Exception ex)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash.log");
                string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}\n\n";
                File.AppendAllText(logPath, entry);
            }
            catch { }
        }
    }
}
