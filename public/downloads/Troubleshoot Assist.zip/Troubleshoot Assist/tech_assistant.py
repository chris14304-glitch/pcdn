#!/usr/bin/env python3
"""
Technician Troubleshooting Assistant
====================================

A single-file desktop application for IT technicians and help desk staff.

Features
--------
  * Dashboard: New Ticket / Open Saved Ticket / Recent Tickets / Settings
  * Guided troubleshooting checklists (Basic, Internet, Browser, Printer,
    Email, Active Directory, Disk/Storage, Hardware)
  * Symptom-aware suggestions that read the problem description and propose
    the next steps -- with one click to tick them and insert the commands
  * Time tracking with automatic duration calculation
  * One-click formatted report to the clipboard
  * Export to TXT, JSON, CSV, PDF and DOCX (no third-party libraries needed)
  * Searchable ticket history stored as JSON on disk

Requirements
------------
  Python 3.8+ with tkinter (bundled with the standard python.org installer).
  On Debian/Ubuntu: sudo apt install python3-tk

Usage
-----
  python tech_assistant.py

Tickets are stored in:  ~/TechAssistant/tickets/
"""

from __future__ import annotations

import csv
import json
import re
import textwrap
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_NAME = "Technician Troubleshooting Assistant"
APP_VERSION = "1.0"

DATA_DIR = Path.home() / "TechAssistant"
TICKET_DIR = DATA_DIR / "tickets"
SETTINGS_FILE = DATA_DIR / "settings.json"


# ---------------------------------------------------------------------------
# Static form definitions
# ---------------------------------------------------------------------------

CUSTOMER_FIELDS = [
    ("customer_name", "Customer Name"),
    ("company", "Company"),
    ("phone", "Phone"),
    ("email", "Email"),
    ("location", "Location"),
    ("technician", "Technician Name"),
]

ASSET_FIELDS = [
    ("asset_tag", "Asset Tag"),
    ("computer_name", "Computer Name"),
    ("serial_number", "Serial Number"),
    ("ip_address", "IP Address"),
]

PRIORITIES = ["Low", "Medium", "High", "Critical"]

OPERATING_SYSTEMS = [
    "Windows 11", "Windows 10", "Windows Server", "macOS", "Ubuntu",
    "Linux", "Android", "iPhone", "Chromebook", "Other",
]

DEVICE_TYPES = ["Desktop", "Laptop", "Server", "VM", "Phone", "Tablet", "Printer", "Other"]

MANUFACTURERS = [
    "Dell", "HP", "Lenovo", "ASUS", "Acer", "Microsoft", "Apple",
    "Toshiba", "Western Digital", "Seagate", "Other",
]

BROWSERS = ["", "Chrome", "Edge", "Firefox", "Safari", "Brave", "Other"]

STATUSES = [
    "Open", "Resolved", "Pending", "Escalated", "Needs Replacement",
    "Waiting on Customer", "Unable to Reproduce",
]

PROBLEM_EXAMPLES = [
    "Cannot connect to VPN",
    "Printer offline",
    "Blue screen on startup",
    "Outlook won't open",
    "Internet slow",
    "External hard drive not detected",
    "Account locked out",
]

# Section name -> list of checklist items
CHECKLISTS = {
    "Basic": [
        "Device powered on",
        "Power cable checked",
        "Battery charged",
        "Restarted device",
        "Shut down completely",
        "Windows Updates checked",
        "Driver updates checked",
        "BIOS updated",
        "Enough disk space",
        "Time/Date correct",
        "Logged in with correct account",
        "Password reset attempted",
    ],
    "Internet": [
        "Ethernet connected",
        "Wi-Fi connected",
        "Internet works on another device",
        "Rebooted modem",
        "Rebooted router",
        "Flushed DNS",
        "Renewed IP",
        "Changed DNS server",
        "Ping gateway",
        "Ping Google",
        "Ping DNS",
        "Speed test",
        "VPN client reinstalled",
        "Proxy settings checked",
    ],
    "Browser": [
        "Cleared cache",
        "Cleared cookies",
        "Disabled extensions",
        "Incognito tested",
        "Different browser tested",
        "Certificate warnings checked",
    ],
    "Printer": [
        "Printer online",
        "Restarted printer",
        "Cleared queue",
        "Restarted Print Spooler",
        "Reinstalled driver",
        "Test page printed",
        "IP address verified",
        "Toner / paper checked",
    ],
    "Email (Outlook)": [
        "Outlook safe mode",
        "New profile created",
        "OST rebuilt",
        "Mailbox full",
        "Exchange Online status checked",
        "Credentials updated",
        "Webmail tested",
    ],
    "Active Directory": [
        "User exists",
        "Account locked",
        "Password reset",
        "MFA checked",
        "Group membership verified",
        "Replication / DC reachable",
    ],
    "Disk / Storage": [
        "CrystalDiskInfo",
        "SMART checked",
        "DiskPart",
        "chkdsk",
        "Event Viewer",
        "TestDisk",
        "DMDE",
        "Windows Disk Management",
        "USB different port",
        "USB different cable",
        "Different computer",
        "Enclosure bypassed / direct SATA",
    ],
    "Hardware": [
        "RAM reseated",
        "Memory diagnostic run",
        "Cables reseated",
        "Fans / temps checked",
        "Peripherals disconnected",
        "Known-good part swapped",
    ],
}


def key_of(section: str, item: str) -> str:
    return f"{section}|{item}"


# ---------------------------------------------------------------------------
# Suggestion engine -- symptom keywords map to recommended next steps
# ---------------------------------------------------------------------------
# Each suggestion: (display text, (section, checklist item) or None, command or None)

SUGGESTION_RULES = [
    (
        ["internet", "network", "no connection", "cannot connect", "can't connect",
         "offline", "dns", "wifi", "wi-fi", "ethernet", "dhcp", "no ip"],
        [
            ("Confirm another device on the same network works", ("Internet", "Internet works on another device"), None),
            ("Review the full IP configuration", None, "ipconfig /all"),
            ("Flush the DNS resolver cache", ("Internet", "Flushed DNS"), "ipconfig /flushdns"),
            ("Release and renew the DHCP lease", ("Internet", "Renewed IP"), "ipconfig /release\nipconfig /renew"),
            ("Ping the default gateway", ("Internet", "Ping gateway"), "ping 192.168.1.1"),
            ("Ping a public host to test routing", ("Internet", "Ping Google"), "ping 8.8.8.8"),
            ("Test name resolution directly", ("Internet", "Ping DNS"), "nslookup google.com"),
            ("Reset the TCP/IP stack if all else fails", None, "netsh winsock reset\nnetsh int ip reset"),
        ],
    ),
    (
        ["vpn", "remote access", "tunnel", "always on vpn"],
        [
            ("Confirm the underlying internet connection works first", ("Internet", "Internet works on another device"), None),
            ("Verify credentials / MFA prompt is being received", ("Active Directory", "MFA checked"), None),
            ("Check the VPN client version and reinstall if mismatched", ("Internet", "VPN client reinstalled"), None),
            ("Check for a split-tunnel or route conflict", None, "route print"),
            ("Confirm the client can reach the VPN endpoint", None, "ping vpn.company.com\ntracert vpn.company.com"),
        ],
    ),
    (
        ["printer", "print", "spooler", "scan", "toner", "paper jam"],
        [
            ("Confirm the printer shows online and has no error state", ("Printer", "Printer online"), None),
            ("Power cycle the printer", ("Printer", "Restarted printer"), None),
            ("Clear the stuck print queue", ("Printer", "Cleared queue"), None),
            ("Restart the Print Spooler service", ("Printer", "Restarted Print Spooler"), "net stop spooler\nnet start spooler"),
            ("Verify the printer's IP has not changed", ("Printer", "IP address verified"), "ping <printer-ip>"),
            ("Reinstall the print driver", ("Printer", "Reinstalled driver"), None),
            ("Print a test page to confirm the fix", ("Printer", "Test page printed"), None),
        ],
    ),
    (
        ["outlook", "email", "mailbox", "exchange", "smtp", "owa", "calendar"],
        [
            ("Start Outlook in safe mode to rule out add-ins", ("Email (Outlook)", "Outlook safe mode"), "outlook.exe /safe"),
            ("Test the same account in webmail", ("Email (Outlook)", "Webmail tested"), None),
            ("Check mailbox size against the quota", ("Email (Outlook)", "Mailbox full"), None),
            ("Rebuild the OST / recreate the profile", ("Email (Outlook)", "New profile created"), None),
            ("Clear cached credentials in Credential Manager", ("Email (Outlook)", "Credentials updated"), None),
            ("Check the Microsoft 365 service health dashboard", ("Email (Outlook)", "Exchange Online status checked"), None),
        ],
    ),
    (
        ["password", "locked", "lock out", "lockout", "login", "log in", "sign in",
         "account", "active directory", "mfa", "credential", "kerberos"],
        [
            ("Confirm the account exists and is enabled", ("Active Directory", "User exists"), None),
            ("Check for a lockout and find the source DC", ("Active Directory", "Account locked"), None),
            ("Reset the password and require a change at next logon", ("Active Directory", "Password reset"), None),
            ("Verify MFA registration and device enrollment", ("Active Directory", "MFA checked"), None),
            ("Confirm group membership grants the needed access", ("Active Directory", "Group membership verified"), None),
            ("Verify the machine's trust relationship with the domain", None, "Test-ComputerSecureChannel -Verbose"),
        ],
    ),
    (
        ["hard drive", "external drive", "usb", "disk", "not detected", "not showing",
         "raw", "smart", "partition", "my book", "seagate", "wd ", "ssd", "hdd",
         "unallocated", "read only", "corrupt"],
        [
            ("Check whether the disk appears at all in Disk Management", ("Disk / Storage", "Windows Disk Management"), "diskmgmt.msc"),
            ("Pull SMART attributes with CrystalDiskInfo", ("Disk / Storage", "CrystalDiskInfo"), None),
            ("List disks and check for a read-only flag", ("Disk / Storage", "DiskPart"), "diskpart\nlist disk\nselect disk 1\ndetail disk"),
            ("Check the file system for errors (read-only first)", ("Disk / Storage", "chkdsk"), "chkdsk X: /f"),
            ("Look for disk / controller errors in the event log", ("Disk / Storage", "Event Viewer"), "eventvwr.msc"),
            ("Scan for lost partitions with TestDisk", ("Disk / Storage", "TestDisk"), None),
            ("Inspect the raw structures with DMDE if partitions are missing", ("Disk / Storage", "DMDE"), None),
            ("Rule out the cable, the port and the enclosure", ("Disk / Storage", "USB different cable"), None),
            ("Test the drive on a second machine", ("Disk / Storage", "Different computer"), None),
        ],
    ),
    (
        ["blue screen", "bsod", "crash", "reboot loop", "stop code", "freeze", "hang"],
        [
            ("Record the exact stop code and failing module", None, None),
            ("Check for pending driver and firmware updates", ("Basic", "Driver updates checked"), None),
            ("Verify system file integrity", None, "sfc /scannow"),
            ("Repair the component store", None, "DISM /Online /Cleanup-Image /RestoreHealth"),
            ("Run a memory diagnostic", ("Hardware", "Memory diagnostic run"), "mdsched.exe"),
            ("Review the minidump and system log", ("Disk / Storage", "Event Viewer"), None),
        ],
    ),
    (
        ["slow", "performance", "lag", "freezing", "high cpu", "high memory", "100%"],
        [
            ("Identify the top CPU / disk / memory consumers", None, "Get-Process | Sort-Object CPU -Descending | Select-Object -First 10"),
            ("Confirm free space on the system volume", ("Basic", "Enough disk space"), None),
            ("Check startup impact and disable unneeded entries", None, "msconfig"),
            ("Verify the disk is healthy and not throttling", ("Disk / Storage", "SMART checked"), None),
            ("Confirm Windows Update is not running in the background", ("Basic", "Windows Updates checked"), None),
            ("Run a full malware scan", None, None),
        ],
    ),
    (
        ["update", "windows update", "patch", "0x8", "wsus"],
        [
            ("Note the exact update KB and error code", None, None),
            ("Confirm free space for the update", ("Basic", "Enough disk space"), None),
            ("Repair the component store", None, "DISM /Online /Cleanup-Image /RestoreHealth\nsfc /scannow"),
            ("Reset the Windows Update components", None,
             "net stop wuauserv\nnet stop bits\nren %windir%\\SoftwareDistribution SoftwareDistribution.old\n"
             "net start wuauserv\nnet start bits"),
        ],
    ),
    (
        ["browser", "website", "page won't load", "chrome", "edge", "firefox", "certificate", "https"],
        [
            ("Test the same site in a private window", ("Browser", "Incognito tested"), None),
            ("Clear cache and cookies for the site", ("Browser", "Cleared cache"), None),
            ("Disable extensions to rule out interference", ("Browser", "Disabled extensions"), None),
            ("Test in a second browser to isolate the profile", ("Browser", "Different browser tested"), None),
            ("Check the system clock -- a skewed clock breaks TLS", ("Basic", "Time/Date correct"), None),
        ],
    ),
    (
        ["boot", "won't turn on", "no power", "no display", "post", "bios", "uefi"],
        [
            ("Confirm power at the outlet, brick and cable", ("Basic", "Power cable checked"), None),
            ("Drain residual power and retry", ("Basic", "Shut down completely"), None),
            ("Reseat RAM and internal cables", ("Hardware", "RAM reseated"), None),
            ("Disconnect all peripherals and retry", ("Hardware", "Peripherals disconnected"), None),
            ("Check for POST beep codes or diagnostic LEDs", None, None),
            ("Check for a BIOS/firmware update", ("Basic", "BIOS updated"), None),
        ],
    ),
]

GENERIC_SUGGESTIONS = [
    ("Confirm the exact error message, word for word", None, None),
    ("Establish when it last worked and what changed", None, None),
    ("Determine whether it affects one user or many", None, None),
    ("Restart the device and retest", ("Basic", "Restarted device"), None),
    ("Check pending Windows Updates", ("Basic", "Windows Updates checked"), None),
]


def suggest_for(text: str):
    """Return a list of (heading, [suggestions]) for the given problem text."""
    low = (text or "").lower()
    out = []
    for keywords, items in SUGGESTION_RULES:
        hit = next((k for k in keywords if k in low), None)
        if hit:
            out.append((keywords[0].strip().title(), items))
    if not out:
        out.append(("General Intake", GENERIC_SUGGESTIONS))
    return out


# ---------------------------------------------------------------------------
# Ticket model
# ---------------------------------------------------------------------------

def new_ticket_id() -> str:
    return "TKT-" + datetime.now().strftime("%Y%m%d-%H%M%S")


def blank_ticket() -> dict:
    return {
        "id": new_ticket_id(),
        "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "updated": "",
        "fields": {},
        "texts": {},
        "checks": {},
    }


def safe_slug(text: str, fallback: str = "ticket") -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", (text or "").strip())
    return slug.strip("_") or fallback


def parse_time(value: str):
    """Accept 'HH:MM', 'H:MM AM', or 'YYYY-MM-DD HH:MM'. Return datetime or None."""
    value = (value or "").strip()
    if not value:
        return None
    fmts = ["%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%H:%M", "%I:%M %p", "%I:%M%p"]
    for fmt in fmts:
        try:
            dt = datetime.strptime(value.upper() if "%p" in fmt.lower() else value, fmt)
            if fmt in ("%H:%M", "%I:%M %p", "%I:%M%p"):
                today = datetime.now()
                dt = dt.replace(year=today.year, month=today.month, day=today.day)
            return dt
        except ValueError:
            continue
    return None


def duration_text(start: str, end: str) -> str:
    a, b = parse_time(start), parse_time(end)
    if not a or not b:
        return ""
    if b < a:
        b += timedelta(days=1)
    mins = int((b - a).total_seconds() // 60)
    if mins < 60:
        return f"{mins} minutes"
    return f"{mins // 60}h {mins % 60}m ({mins} minutes)"


# ---------------------------------------------------------------------------
# Report builder
# ---------------------------------------------------------------------------

RULE = "=" * 60
THIN = "-" * 60


def build_report(data: dict, ascii_only: bool = False) -> str:
    tick = "[x]" if ascii_only else "\u2714"
    f = data.get("fields", {})
    t = data.get("texts", {})
    checks = {k: v for k, v in data.get("checks", {}).items() if v}

    lines = [RULE, "TECHNICIAN REPORT", RULE, ""]
    lines.append(f"Ticket ID   : {data.get('id', '')}")
    lines.append(f"Opened      : {data.get('created', '')}")
    if f.get("technician"):
        lines.append(f"Technician  : {f['technician']}")
    lines.append("")

    def block(title, pairs):
        rows = [(lbl, f.get(k, "").strip()) for k, lbl in pairs if f.get(k, "").strip()]
        if not rows:
            return
        lines.extend([THIN, title, THIN])
        width = max(len(r[0]) for r in rows)
        for lbl, val in rows:
            lines.append(f"{lbl.ljust(width)} : {val}")
        lines.append("")

    block("CUSTOMER", CUSTOMER_FIELDS)
    block("ASSET", ASSET_FIELDS)
    block("DEVICE", [("os", "Operating System"), ("device_type", "Device Type"),
                     ("manufacturer", "Manufacturer"), ("model", "Model"),
                     ("browser", "Browser")])

    problem = t.get("problem", "").strip()
    if problem or f.get("priority"):
        lines.extend([THIN, "PROBLEM DESCRIPTION", THIN])
        if f.get("priority"):
            lines.append(f"Priority : {f['priority']}")
            lines.append("")
        if problem:
            lines.append(problem)
        lines.append("")

    if checks:
        lines.extend([THIN, "TROUBLESHOOTING PERFORMED", THIN])
        for section in CHECKLISTS:
            done = [item for item in CHECKLISTS[section] if checks.get(key_of(section, item))]
            if done:
                lines.append(f"[{section}]")
                for item in done:
                    lines.append(f"  {tick} {item}")
                lines.append("")

    for label, key in [("COMMANDS USED", "commands"), ("FINDINGS", "findings"),
                       ("RESOLUTION", "resolution"), ("NOTES", "notes")]:
        body = t.get(key, "").strip()
        if body:
            lines.extend([THIN, label, THIN, body, ""])

    lines.extend([THIN, "STATUS & TIME", THIN])
    lines.append(f"Status     : {f.get('status', 'Open')}")
    if f.get("start_time"):
        lines.append(f"Start      : {f['start_time']}")
    if f.get("end_time"):
        lines.append(f"End        : {f['end_time']}")
    total = f.get("total_time") or duration_text(f.get("start_time", ""), f.get("end_time", ""))
    if total:
        lines.append(f"Total Time : {total}")
    lines.extend(["", RULE])
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Exporters (no third-party dependencies)
# ---------------------------------------------------------------------------

def export_txt(path: Path, data: dict) -> None:
    path.write_text(build_report(data), encoding="utf-8")


def export_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def flatten(data: dict) -> dict:
    f = data.get("fields", {})
    t = data.get("texts", {})
    checked = [k.split("|", 1)[1] for k, v in data.get("checks", {}).items() if v]
    row = {"ticket_id": data.get("id", ""), "created": data.get("created", "")}
    for key, label in CUSTOMER_FIELDS + ASSET_FIELDS:
        row[label] = f.get(key, "")
    for key in ("os", "device_type", "manufacturer", "model", "browser",
                "priority", "status", "start_time", "end_time", "total_time"):
        row[key] = f.get(key, "")
    for key in ("problem", "commands", "findings", "resolution", "notes"):
        row[key] = t.get(key, "")
    row["steps_performed"] = "; ".join(checked)
    return row


def export_csv(path: Path, data: dict) -> None:
    row = flatten(data)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(row))
        writer.writeheader()
        writer.writerow(row)


def export_csv_many(path: Path, tickets: list) -> None:
    rows = [flatten(t) for t in tickets]
    if not rows:
        return
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _pdf_escape(s: str) -> str:
    s = s.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
    return "".join(ch if 32 <= ord(ch) < 127 else "?" for ch in s)


def export_pdf(path: Path, data: dict) -> None:
    """Minimal PDF writer -- Courier text pages, no external libraries."""
    text = build_report(data, ascii_only=True)
    lines: list = []
    for raw in text.splitlines():
        raw = raw.rstrip()
        if not raw:
            lines.append("")
        else:
            lines.extend(textwrap.wrap(raw, 88, subsequent_indent="    ") or [""])

    per_page = 56
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[""]]
    n = len(pages)
    page_nums = [4 + 2 * i for i in range(n)]
    content_nums = [5 + 2 * i for i in range(n)]

    body: dict = {
        1: b"<< /Type /Catalog /Pages 2 0 R >>",
        2: ("<< /Type /Pages /Kids [%s] /Count %d >>"
            % (" ".join(f"{p} 0 R" for p in page_nums), n)).encode(),
        3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>",
    }
    for i, page in enumerate(pages):
        body[page_nums[i]] = (
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            "/Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % content_nums[i]
        ).encode()
        stream = "BT\n/F1 9 Tf\n12 TL\n50 745 Td\n"
        for ln in page:
            stream += f"({_pdf_escape(ln)}) Tj T*\n"
        stream += "ET"
        raw = stream.encode("latin-1", "replace")
        body[content_nums[i]] = (b"<< /Length %d >>\nstream\n" % len(raw)) + raw + b"\nendstream"

    out = bytearray(b"%PDF-1.4\n")
    offsets = {}
    for num in sorted(body):
        offsets[num] = len(out)
        out += f"{num} 0 obj\n".encode() + body[num] + b"\nendobj\n"
    xref_at = len(out)
    last = max(body)
    out += f"xref\n0 {last + 1}\n".encode() + b"0000000000 65535 f \n"
    for num in range(1, last + 1):
        out += f"{offsets[num]:010d} 00000 n \n".encode()
    out += (f"trailer\n<< /Size {last + 1} /Root 1 0 R >>\nstartxref\n{xref_at}\n%%EOF\n").encode()
    path.write_bytes(bytes(out))


def _xml_escape(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def export_docx(path: Path, data: dict) -> None:
    """Minimal Office Open XML writer -- opens in Word, LibreOffice, Google Docs."""
    text = build_report(data)
    paras = []
    for line in text.splitlines():
        run_props = '<w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/><w:sz w:val="18"/></w:rPr>'
        paras.append(
            "<w:p><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/>"
            f"{run_props}</w:pPr><w:r>{run_props}"
            f'<w:t xml:space="preserve">{_xml_escape(line)}</w:t></w:r></w:p>'
        )
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        "<w:body>" + "".join(paras) +
        '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>'
        '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr>'
        "</w:body></w:document>"
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-'
        'officedocument.wordprocessingml.document.main+xml"/></Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
        'relationships/officeDocument" Target="word/document.xml"/></Relationships>'
    )
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document)


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

DEFAULT_SETTINGS = {
    "technician": "",
    "company": "",
    "auto_start_timer": True,
    "export_dir": str(Path.home()),
}


def load_settings() -> dict:
    settings = dict(DEFAULT_SETTINGS)
    try:
        if SETTINGS_FILE.exists():
            settings.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except Exception:
        pass
    return settings


def save_settings(settings: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Reusable widgets
# ---------------------------------------------------------------------------

class ScrollFrame(ttk.Frame):
    """A vertically scrollable frame. Put children inside `.inner`."""

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")

        self.inner.bind("<Configure>",
                        lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        self.canvas.configure(yscrollcommand=vsb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _bind_wheel(self, _=None):
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)
        self.canvas.bind_all("<Button-4>", self._on_wheel)
        self.canvas.bind_all("<Button-5>", self._on_wheel)

    def _unbind_wheel(self, _=None):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _on_wheel(self, event):
        if getattr(event, "num", None) == 4:
            delta = -1
        elif getattr(event, "num", None) == 5:
            delta = 1
        else:
            delta = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(delta, "units")


def labeled_text(master, height=6):
    frame = ttk.Frame(master)
    text = tk.Text(frame, height=height, wrap="word", undo=True,
                   font=("Consolas", 10), relief="solid", borderwidth=1)
    vsb = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
    text.configure(yscrollcommand=vsb.set)
    text.pack(side="left", fill="both", expand=True)
    vsb.pack(side="right", fill="y")
    return frame, text


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------

class TechAssistant(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1080x760")
        self.minsize(880, 620)

        TICKET_DIR.mkdir(parents=True, exist_ok=True)
        self.settings = load_settings()

        self.current_path: Path | None = None
        self.ticket = blank_ticket()
        self.dirty = False

        self.fields: dict = {}     # name -> StringVar
        self.texts: dict = {}      # name -> tk.Text
        self.checks: dict = {}     # "Section|Item" -> BooleanVar

        self._style()
        self._build_menu()

        self.container = ttk.Frame(self)
        self.container.pack(fill="both", expand=True)

        self.status_var = tk.StringVar(value="Ready")
        status = ttk.Label(self, textvariable=self.status_var, anchor="w",
                           relief="sunken", padding=(8, 3))
        status.pack(fill="x", side="bottom")

        self.dashboard = None
        self.editor = None
        self.show_dashboard()

        self.bind_all("<Control-n>", lambda e: self.new_ticket())
        self.bind_all("<Control-s>", lambda e: self.save_ticket())
        self.bind_all("<Control-o>", lambda e: self.open_ticket_dialog())
        self.bind_all("<Control-Shift-C>", lambda e: self.copy_report())
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # -- chrome ------------------------------------------------------------
    def _style(self):
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Header.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#555555")
        style.configure("Section.TLabelframe.Label", font=("Segoe UI", 10, "bold"))
        style.configure("Big.TButton", padding=(16, 12), font=("Segoe UI", 11))

    def _build_menu(self):
        menubar = tk.Menu(self)

        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="New Ticket\tCtrl+N", command=self.new_ticket)
        filemenu.add_command(label="Open Saved Ticket...\tCtrl+O", command=self.open_ticket_dialog)
        filemenu.add_command(label="Save\tCtrl+S", command=self.save_ticket)
        filemenu.add_separator()
        exportmenu = tk.Menu(filemenu, tearoff=0)
        for label, ext in [("Text (.txt)", "txt"), ("PDF (.pdf)", "pdf"),
                           ("Word (.docx)", "docx"), ("JSON (.json)", "json"),
                           ("CSV (.csv)", "csv")]:
            exportmenu.add_command(label=label, command=lambda e=ext: self.export(e))
        filemenu.add_cascade(label="Export", menu=exportmenu)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.on_close)
        menubar.add_cascade(label="File", menu=filemenu)

        toolsmenu = tk.Menu(menubar, tearoff=0)
        toolsmenu.add_command(label="Copy Report to Clipboard\tCtrl+Shift+C",
                              command=self.copy_report)
        toolsmenu.add_command(label="Preview Report...", command=self.preview_report)
        toolsmenu.add_separator()
        toolsmenu.add_command(label="Dashboard", command=self.show_dashboard)
        toolsmenu.add_command(label="Settings...", command=self.open_settings)
        menubar.add_cascade(label="Tools", menu=toolsmenu)

        helpmenu = tk.Menu(menubar, tearoff=0)
        helpmenu.add_command(label="About", command=self.about)
        menubar.add_cascade(label="Help", menu=helpmenu)

        self.config(menu=menubar)

    def clear_container(self):
        for child in self.container.winfo_children():
            child.destroy()

    # -- dashboard ---------------------------------------------------------
    def show_dashboard(self):
        self.clear_container()
        self.editor = None
        wrap = ttk.Frame(self.container, padding=40)
        wrap.pack(fill="both", expand=True)

        ttk.Label(wrap, text=APP_NAME, style="Header.TLabel").pack(anchor="w")
        ttk.Label(wrap, text="Guided troubleshooting, automatic documentation, searchable history.",
                  style="Sub.TLabel").pack(anchor="w", pady=(2, 24))

        buttons = ttk.Frame(wrap)
        buttons.pack(anchor="w")
        for text, cmd in [("New Ticket", self.new_ticket),
                          ("Open Saved Ticket", self.open_ticket_dialog),
                          ("Recent Tickets", lambda: self.open_editor(tab="History")),
                          ("Settings", self.open_settings)]:
            ttk.Button(buttons, text=text, style="Big.TButton", width=20,
                       command=cmd).pack(side="left", padx=(0, 12))

        ttk.Separator(wrap).pack(fill="x", pady=24)
        ttk.Label(wrap, text="Recent tickets", font=("Segoe UI", 11, "bold")).pack(anchor="w")

        cols = ("date", "customer", "issue", "status")
        tree = ttk.Treeview(wrap, columns=cols, show="headings", height=12)
        for col, width in zip(cols, (150, 200, 420, 150)):
            tree.heading(col, text=col.title())
            tree.column(col, width=width, anchor="w")
        tree.pack(fill="both", expand=True, pady=(8, 0))

        recents = self.load_all_tickets()[:25]
        for path, data in recents:
            tree.insert("", "end", iid=str(path), values=(
                data.get("created", ""),
                data.get("fields", {}).get("customer_name", ""),
                (data.get("texts", {}).get("problem", "") or "").splitlines()[0][:80]
                if data.get("texts", {}).get("problem") else "",
                data.get("fields", {}).get("status", "Open"),
            ))
        tree.bind("<Double-1>", lambda e: self._open_from_tree(tree))

        ttk.Label(wrap, text=f"Tickets are stored in {TICKET_DIR}",
                  style="Sub.TLabel").pack(anchor="w", pady=(10, 0))
        self.status_var.set(f"{len(recents)} recent ticket(s) loaded")

    def _open_from_tree(self, tree):
        sel = tree.selection()
        if sel:
            self.load_ticket(Path(sel[0]))

    # -- editor ------------------------------------------------------------
    def open_editor(self, tab: str | None = None):
        self.clear_container()
        self.fields, self.texts, self.checks = {}, {}, {}

        toolbar = ttk.Frame(self.container, padding=(10, 8))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="\u2190 Dashboard", command=self.back_to_dashboard).pack(side="left")
        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(toolbar, text="New", command=self.new_ticket).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Open", command=self.open_ticket_dialog).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Save", command=self.save_ticket).pack(side="left", padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(toolbar, text="Copy Report", command=self.copy_report).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Preview", command=self.preview_report).pack(side="left", padx=2)

        export_box = ttk.Frame(toolbar)
        export_box.pack(side="right")
        self.export_choice = tk.StringVar(value="pdf")
        ttk.Label(export_box, text="Export as").pack(side="left", padx=(0, 4))
        ttk.Combobox(export_box, textvariable=self.export_choice, width=7, state="readonly",
                     values=["txt", "pdf", "docx", "json", "csv"]).pack(side="left")
        ttk.Button(export_box, text="Export",
                   command=lambda: self.export(self.export_choice.get())).pack(side="left", padx=(6, 0))

        self.nb = ttk.Notebook(self.container)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self._tab_intake()
        self._tab_checklists()
        self._tab_worklog()
        self._tab_history()

        self.editor = self.nb
        self.apply_ticket_to_form(self.ticket)
        if tab:
            for i in range(self.nb.index("end")):
                if self.nb.tab(i, "text") == tab:
                    self.nb.select(i)
                    break

    def back_to_dashboard(self):
        if self.editor is not None:
            self.harvest_form()
        self.show_dashboard()

    def _add_field(self, parent, row, key, label, values=None, width=32):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=3, padx=(0, 8))
        var = tk.StringVar()
        self.fields[key] = var
        if values is None:
            widget = ttk.Entry(parent, textvariable=var, width=width)
        else:
            widget = ttk.Combobox(parent, textvariable=var, values=values, width=width - 2)
        widget.grid(row=row, column=1, sticky="we", pady=3)
        parent.columnconfigure(1, weight=1)
        return widget

    # Tab 1: intake --------------------------------------------------------
    def _tab_intake(self):
        scroll = ScrollFrame(self.nb)
        self.nb.add(scroll, text="Intake")
        page = ttk.Frame(scroll.inner, padding=14)
        page.pack(fill="both", expand=True)
        page.columnconfigure(0, weight=1)
        page.columnconfigure(1, weight=1)

        cust = ttk.Labelframe(page, text="Customer Information", padding=12,
                              style="Section.TLabelframe")
        cust.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        for i, (key, label) in enumerate(CUSTOMER_FIELDS):
            self._add_field(cust, i, key, label)

        asset = ttk.Labelframe(page, text="Asset / Device", padding=12,
                               style="Section.TLabelframe")
        asset.grid(row=0, column=1, sticky="nsew")
        row = 0
        for key, label in ASSET_FIELDS:
            self._add_field(asset, row, key, label)
            row += 1
        self._add_field(asset, row, "os", "Operating System", OPERATING_SYSTEMS); row += 1
        self._add_field(asset, row, "device_type", "Device Type", DEVICE_TYPES); row += 1
        self._add_field(asset, row, "manufacturer", "Manufacturer", MANUFACTURERS); row += 1
        self._add_field(asset, row, "model", "Model"); row += 1
        self._add_field(asset, row, "browser", "Browser", BROWSERS)

        prob = ttk.Labelframe(page, text="Problem Description", padding=12,
                              style="Section.TLabelframe")
        prob.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(14, 0))
        prob.columnconfigure(0, weight=1)

        head = ttk.Frame(prob)
        head.grid(row=0, column=0, sticky="we")
        ttk.Label(head, text="What problem is the customer experiencing?").pack(side="left")
        ttk.Label(head, text="   Priority").pack(side="left", padx=(20, 4))
        self.fields["priority"] = tk.StringVar(value="Medium")
        ttk.Combobox(head, textvariable=self.fields["priority"], values=PRIORITIES,
                     width=10, state="readonly").pack(side="left")
        ttk.Label(head, text="   Example").pack(side="left", padx=(20, 4))
        example = tk.StringVar()
        combo = ttk.Combobox(head, textvariable=example, values=PROBLEM_EXAMPLES,
                             width=30, state="readonly")
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda e: self._insert_example(example.get()))

        frame, text = labeled_text(prob, height=7)
        frame.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        self.texts["problem"] = text
        text.bind("<KeyRelease>", self._schedule_suggest)

        sugg = ttk.Labelframe(page, text="Suggested Next Steps (based on the description)",
                              padding=12, style="Section.TLabelframe")
        sugg.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=(14, 0))
        sugg.columnconfigure(0, weight=1)

        bar = ttk.Frame(sugg)
        bar.grid(row=0, column=0, sticky="we")
        ttk.Button(bar, text="Refresh", command=self.refresh_suggestions).pack(side="left")
        ttk.Button(bar, text="Tick matching checklist items",
                   command=self.apply_suggested_checks).pack(side="left", padx=6)
        ttk.Button(bar, text="Insert suggested commands",
                   command=self.insert_suggested_commands).pack(side="left")

        self.sugg_text = tk.Text(sugg, height=12, wrap="word", font=("Segoe UI", 10),
                                 relief="solid", borderwidth=1, background="#fbfbf7")
        self.sugg_text.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        self.sugg_text.configure(state="disabled")
        self._sugg_job = None
        self.refresh_suggestions()

    def _insert_example(self, value):
        if not value:
            return
        widget = self.texts["problem"]
        if not widget.get("1.0", "end").strip():
            widget.insert("1.0", value)
        else:
            widget.insert("end", "\n" + value)
        self.refresh_suggestions()

    def _schedule_suggest(self, _event=None):
        self.dirty = True
        if self._sugg_job:
            self.after_cancel(self._sugg_job)
        self._sugg_job = self.after(450, self.refresh_suggestions)

    def current_suggestions(self):
        problem = self.texts["problem"].get("1.0", "end").strip() if "problem" in self.texts else ""
        return suggest_for(problem)

    def refresh_suggestions(self):
        groups = self.current_suggestions()
        self.sugg_text.configure(state="normal")
        self.sugg_text.delete("1.0", "end")
        for heading, items in groups:
            self.sugg_text.insert("end", f"{heading}\n", "head")
            for label, check, cmd in items:
                self.sugg_text.insert("end", f"   \u2022 {label}\n")
                if cmd:
                    for line in cmd.splitlines():
                        self.sugg_text.insert("end", f"        {line}\n", "cmd")
            self.sugg_text.insert("end", "\n")
        self.sugg_text.tag_configure("head", font=("Segoe UI", 10, "bold"))
        self.sugg_text.tag_configure("cmd", font=("Consolas", 9), foreground="#0b5")
        self.sugg_text.configure(state="disabled")

    def apply_suggested_checks(self):
        count = 0
        for _heading, items in self.current_suggestions():
            for _label, check, _cmd in items:
                if check:
                    var = self.checks.get(key_of(*check))
                    if var is not None and not var.get():
                        var.set(True)
                        count += 1
        self.status_var.set(f"Ticked {count} suggested checklist item(s)")

    def insert_suggested_commands(self):
        cmds = []
        for _heading, items in self.current_suggestions():
            for _label, _check, cmd in items:
                if cmd:
                    for line in cmd.splitlines():
                        if line and line not in cmds:
                            cmds.append(line)
        if not cmds:
            self.status_var.set("No commands suggested for this description")
            return
        widget = self.texts["commands"]
        existing = widget.get("1.0", "end").strip()
        block = "\n".join(cmds)
        widget.insert("end", ("\n" if existing else "") + block + "\n")
        self.status_var.set(f"Inserted {len(cmds)} suggested command line(s)")

    # Tab 2: checklists ----------------------------------------------------
    def _tab_checklists(self):
        scroll = ScrollFrame(self.nb)
        self.nb.add(scroll, text="Checklists")
        page = ttk.Frame(scroll.inner, padding=14)
        page.pack(fill="both", expand=True)
        page.columnconfigure(0, weight=1)
        page.columnconfigure(1, weight=1)

        bar = ttk.Frame(page)
        bar.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        ttk.Button(bar, text="Clear all", command=self.clear_checks).pack(side="left")
        ttk.Label(bar, text="   Tick every step you actually performed -- "
                           "the report is generated from these.",
                  style="Sub.TLabel").pack(side="left")

        for idx, (section, items) in enumerate(CHECKLISTS.items()):
            box = ttk.Labelframe(page, text=section, padding=10, style="Section.TLabelframe")
            box.grid(row=1 + idx // 2, column=idx % 2, sticky="nsew", padx=6, pady=6)
            for item in items:
                var = tk.BooleanVar(value=False)
                self.checks[key_of(section, item)] = var
                cb = ttk.Checkbutton(box, text=item, variable=var,
                                     command=lambda: setattr(self, "dirty", True))
                cb.pack(anchor="w")

    def clear_checks(self):
        for var in self.checks.values():
            var.set(False)
        self.status_var.set("Checklists cleared")

    # Tab 3: work log ------------------------------------------------------
    def _tab_worklog(self):
        scroll = ScrollFrame(self.nb)
        self.nb.add(scroll, text="Work Log")
        page = ttk.Frame(scroll.inner, padding=14)
        page.pack(fill="both", expand=True)
        page.columnconfigure(0, weight=1)

        row = 0
        for key, title, height, hint in [
            ("commands", "Commands Used", 8,
             "e.g. ipconfig /all, sfc /scannow, DISM /Online /Cleanup-Image /RestoreHealth"),
            ("findings", "Findings", 7,
             "e.g. SMART healthy, disk not visible in Explorer, reports read-only state"),
            ("resolution", "Resolution", 7,
             "e.g. Print driver corrupted. Driver reinstalled. Issue resolved."),
            ("notes", "Internal Notes", 5, "Anything not going to the customer."),
        ]:
            box = ttk.Labelframe(page, text=title, padding=10, style="Section.TLabelframe")
            box.grid(row=row, column=0, sticky="nsew", pady=(0, 12))
            box.columnconfigure(0, weight=1)
            ttk.Label(box, text=hint, style="Sub.TLabel").grid(row=0, column=0, sticky="w")
            frame, text = labeled_text(box, height=height)
            frame.grid(row=1, column=0, sticky="nsew", pady=(6, 0))
            text.bind("<KeyRelease>", lambda e: setattr(self, "dirty", True))
            self.texts[key] = text
            row += 1

        timing = ttk.Labelframe(page, text="Time Tracking & Status", padding=12,
                                style="Section.TLabelframe")
        timing.grid(row=row, column=0, sticky="nsew")

        ttk.Label(timing, text="Start Time").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.fields["start_time"] = tk.StringVar()
        ttk.Entry(timing, textvariable=self.fields["start_time"], width=22).grid(row=0, column=1, sticky="w")
        ttk.Button(timing, text="Now", width=6,
                   command=lambda: self._stamp("start_time")).grid(row=0, column=2, padx=6)

        ttk.Label(timing, text="End Time").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=(6, 0))
        self.fields["end_time"] = tk.StringVar()
        ttk.Entry(timing, textvariable=self.fields["end_time"], width=22).grid(row=1, column=1, sticky="w", pady=(6, 0))
        ttk.Button(timing, text="Now", width=6,
                   command=lambda: self._stamp("end_time")).grid(row=1, column=2, padx=6, pady=(6, 0))

        ttk.Label(timing, text="Total Time").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=(6, 0))
        self.fields["total_time"] = tk.StringVar()
        ttk.Label(timing, textvariable=self.fields["total_time"],
                  font=("Segoe UI", 10, "bold")).grid(row=2, column=1, sticky="w", pady=(6, 0))
        ttk.Button(timing, text="Recalculate",
                   command=self.recalc_time).grid(row=2, column=2, padx=6, pady=(6, 0))

        ttk.Label(timing, text="Final Status").grid(row=3, column=0, sticky="w", padx=(0, 8), pady=(12, 0))
        self.fields["status"] = tk.StringVar(value="Open")
        ttk.Combobox(timing, textvariable=self.fields["status"], values=STATUSES,
                     state="readonly", width=24).grid(row=3, column=1, sticky="w", pady=(12, 0))

    def _stamp(self, key):
        self.fields[key].set(datetime.now().strftime("%Y-%m-%d %H:%M"))
        self.recalc_time()

    def recalc_time(self):
        total = duration_text(self.fields["start_time"].get(), self.fields["end_time"].get())
        self.fields["total_time"].set(total or "--")

    # Tab 4: history -------------------------------------------------------
    def _tab_history(self):
        page = ttk.Frame(self.nb, padding=14)
        self.nb.add(page, text="History")
        page.columnconfigure(0, weight=1)
        page.rowconfigure(2, weight=1)

        bar = ttk.Frame(page)
        bar.grid(row=0, column=0, sticky="we")
        ttk.Label(bar, text="Search").pack(side="left", padx=(0, 6))
        self.search_var = tk.StringVar()
        entry = ttk.Entry(bar, textvariable=self.search_var, width=40)
        entry.pack(side="left")
        entry.bind("<KeyRelease>", lambda e: self.refresh_history())
        ttk.Button(bar, text="Search", command=self.refresh_history).pack(side="left", padx=6)
        ttk.Button(bar, text="Open Selected", command=self.open_selected_history).pack(side="left")
        ttk.Button(bar, text="Delete Selected", command=self.delete_selected_history).pack(side="left", padx=6)
        ttk.Button(bar, text="Export List to CSV", command=self.export_history_csv).pack(side="left")

        ttk.Label(page, text="Searches the whole ticket: problem text, commands, findings, "
                             "resolution and every ticked step. Try: printer, vpn, outlook, "
                             "diskpart, SMART, USB",
                  style="Sub.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 8))

        cols = ("date", "customer", "issue", "status", "tech")
        self.hist_tree = ttk.Treeview(page, columns=cols, show="headings")
        for col, width in zip(cols, (140, 170, 380, 140, 130)):
            self.hist_tree.heading(col, text=col.title())
            self.hist_tree.column(col, width=width, anchor="w")
        self.hist_tree.grid(row=2, column=0, sticky="nsew")
        vsb = ttk.Scrollbar(page, orient="vertical", command=self.hist_tree.yview)
        self.hist_tree.configure(yscrollcommand=vsb.set)
        vsb.grid(row=2, column=1, sticky="ns")
        self.hist_tree.bind("<Double-1>", lambda e: self.open_selected_history())

        self.refresh_history()

    def load_all_tickets(self):
        out = []
        for path in sorted(TICKET_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                out.append((path, json.loads(path.read_text(encoding="utf-8"))))
            except Exception:
                continue
        return out

    def refresh_history(self):
        query = (self.search_var.get() or "").strip().lower()
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)
        count = 0
        for path, data in self.load_all_tickets():
            haystack = json.dumps(data).lower()
            if query and query not in haystack:
                continue
            problem = (data.get("texts", {}).get("problem", "") or "").strip().splitlines()
            self.hist_tree.insert("", "end", iid=str(path), values=(
                data.get("created", ""),
                data.get("fields", {}).get("customer_name", ""),
                problem[0][:80] if problem else "",
                data.get("fields", {}).get("status", "Open"),
                data.get("fields", {}).get("technician", ""),
            ))
            count += 1
        self.status_var.set(f"{count} ticket(s) matched" if query else f"{count} ticket(s) on file")

    def open_selected_history(self):
        sel = self.hist_tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Select a ticket first.")
            return
        self.load_ticket(Path(sel[0]))

    def delete_selected_history(self):
        sel = self.hist_tree.selection()
        if not sel:
            return
        if not messagebox.askyesno(APP_NAME, f"Delete {len(sel)} ticket file(s)? This cannot be undone."):
            return
        for iid in sel:
            try:
                Path(iid).unlink()
            except OSError as exc:
                messagebox.showerror(APP_NAME, f"Could not delete:\n{exc}")
        self.refresh_history()

    def export_history_csv(self):
        rows = [data for _p, data in self.load_all_tickets()]
        if not rows:
            messagebox.showinfo(APP_NAME, "No tickets to export yet.")
            return
        path = filedialog.asksaveasfilename(
            title="Export ticket history", defaultextension=".csv",
            initialdir=self.settings.get("export_dir", str(Path.home())),
            initialfile="ticket_history.csv", filetypes=[("CSV", "*.csv")])
        if not path:
            return
        export_csv_many(Path(path), rows)
        self.status_var.set(f"Exported {len(rows)} ticket(s) to {path}")

    # -- form <-> data -----------------------------------------------------
    def harvest_form(self) -> dict:
        if self.editor is None:
            return self.ticket
        self.recalc_time()
        self.ticket["fields"] = {k: v.get().strip() for k, v in self.fields.items()}
        self.ticket["texts"] = {k: w.get("1.0", "end").rstrip() for k, w in self.texts.items()}
        self.ticket["checks"] = {k: bool(v.get()) for k, v in self.checks.items() if v.get()}
        self.ticket["updated"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        return self.ticket

    def apply_ticket_to_form(self, data: dict):
        fields = data.get("fields", {})
        for key, var in self.fields.items():
            var.set(fields.get(key, ""))
        if not self.fields["status"].get():
            self.fields["status"].set("Open")
        if not self.fields["priority"].get():
            self.fields["priority"].set("Medium")
        if not self.fields["technician"].get():
            self.fields["technician"].set(self.settings.get("technician", ""))
        if not self.fields["company"].get():
            self.fields["company"].set(self.settings.get("company", ""))

        texts = data.get("texts", {})
        for key, widget in self.texts.items():
            widget.delete("1.0", "end")
            widget.insert("1.0", texts.get(key, ""))

        checks = data.get("checks", {})
        for key, var in self.checks.items():
            var.set(bool(checks.get(key)))

        self.recalc_time()
        self.refresh_suggestions()
        self.title(f"{APP_NAME} - {data.get('id', '')}")
        self.dirty = False

    # -- ticket actions ----------------------------------------------------
    def new_ticket(self):
        if not self.confirm_discard():
            return
        self.ticket = blank_ticket()
        self.current_path = None
        if self.settings.get("auto_start_timer", True):
            self.ticket["fields"]["start_time"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        if self.editor is None:
            self.open_editor()
        else:
            self.apply_ticket_to_form(self.ticket)
            self.nb.select(0)
        self.status_var.set(f"New ticket {self.ticket['id']}")

    def open_ticket_dialog(self):
        path = filedialog.askopenfilename(
            title="Open saved ticket", initialdir=str(TICKET_DIR),
            filetypes=[("Ticket files", "*.json"), ("All files", "*.*")])
        if path:
            self.load_ticket(Path(path))

    def load_ticket(self, path: Path):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Could not open ticket:\n{exc}")
            return
        if not self.confirm_discard():
            return
        self.ticket = data
        self.current_path = path
        if self.editor is None:
            self.open_editor()
        else:
            self.apply_ticket_to_form(data)
            self.nb.select(0)
        self.status_var.set(f"Opened {path.name}")

    def save_ticket(self):
        if self.editor is None:
            return
        data = self.harvest_form()
        TICKET_DIR.mkdir(parents=True, exist_ok=True)
        if self.current_path is None:
            name = safe_slug(data["fields"].get("customer_name", ""), "customer")
            self.current_path = TICKET_DIR / f"{data['id']}_{name}.json"
        self.current_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        self.dirty = False
        self.status_var.set(f"Saved to {self.current_path}")
        if hasattr(self, "hist_tree"):
            self.refresh_history()

    def confirm_discard(self) -> bool:
        if self.editor is None or not self.dirty:
            return True
        answer = messagebox.askyesnocancel(APP_NAME, "Save changes to the current ticket first?")
        if answer is None:
            return False
        if answer:
            self.save_ticket()
        return True

    # -- report / export ---------------------------------------------------
    def copy_report(self):
        if self.editor is None:
            self.status_var.set("Open a ticket first")
            return
        report = build_report(self.harvest_form())
        self.clipboard_clear()
        self.clipboard_append(report)
        self.update()
        self.status_var.set("Formatted report copied to clipboard")

    def preview_report(self):
        if self.editor is None:
            return
        report = build_report(self.harvest_form())
        win = tk.Toplevel(self)
        win.title("Report Preview")
        win.geometry("760x680")
        text = tk.Text(win, wrap="none", font=("Consolas", 10))
        vsb = ttk.Scrollbar(win, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=vsb.set)
        text.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        text.insert("1.0", report)
        text.configure(state="disabled")

    def export(self, fmt: str):
        if self.editor is None:
            self.status_var.set("Open a ticket first")
            return
        data = self.harvest_form()
        name = safe_slug(data["fields"].get("customer_name", ""), "ticket")
        path = filedialog.asksaveasfilename(
            title=f"Export as {fmt.upper()}",
            defaultextension=f".{fmt}",
            initialdir=self.settings.get("export_dir", str(Path.home())),
            initialfile=f"{data['id']}_{name}.{fmt}",
            filetypes=[(fmt.upper(), f"*.{fmt}"), ("All files", "*.*")])
        if not path:
            return
        target = Path(path)
        writers = {"txt": export_txt, "json": export_json, "csv": export_csv,
                   "pdf": export_pdf, "docx": export_docx}
        try:
            writers[fmt](target, data)
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Export failed:\n{exc}")
            return
        self.settings["export_dir"] = str(target.parent)
        save_settings(self.settings)
        self.status_var.set(f"Exported to {target}")

    # -- settings / about --------------------------------------------------
    def open_settings(self):
        win = tk.Toplevel(self)
        win.title("Settings")
        win.transient(self)
        win.resizable(False, False)
        body = ttk.Frame(win, padding=16)
        body.pack(fill="both", expand=True)

        tech = tk.StringVar(value=self.settings.get("technician", ""))
        comp = tk.StringVar(value=self.settings.get("company", ""))
        auto = tk.BooleanVar(value=self.settings.get("auto_start_timer", True))
        outdir = tk.StringVar(value=self.settings.get("export_dir", str(Path.home())))

        ttk.Label(body, text="Default technician name").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(body, textvariable=tech, width=36).grid(row=0, column=1, pady=4)
        ttk.Label(body, text="Default company").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(body, textvariable=comp, width=36).grid(row=1, column=1, pady=4)
        ttk.Label(body, text="Default export folder").grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(body, textvariable=outdir, width=36).grid(row=2, column=1, pady=4)
        ttk.Checkbutton(body, text="Start the timer automatically on a new ticket",
                        variable=auto).grid(row=3, column=0, columnspan=2, sticky="w", pady=(10, 4))
        ttk.Label(body, text=f"Ticket folder: {TICKET_DIR}",
                  style="Sub.TLabel").grid(row=4, column=0, columnspan=2, sticky="w", pady=(8, 0))

        def commit():
            self.settings.update({"technician": tech.get().strip(),
                                  "company": comp.get().strip(),
                                  "auto_start_timer": bool(auto.get()),
                                  "export_dir": outdir.get().strip() or str(Path.home())})
            save_settings(self.settings)
            win.destroy()
            self.status_var.set("Settings saved")

        buttons = ttk.Frame(body)
        buttons.grid(row=5, column=0, columnspan=2, sticky="e", pady=(16, 0))
        ttk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(buttons, text="Save", command=commit).pack(side="right")

    def about(self):
        messagebox.showinfo(
            f"About {APP_NAME}",
            f"{APP_NAME} v{APP_VERSION}\n\n"
            "Guided troubleshooting, automatic report generation and searchable\n"
            "ticket history for IT technicians and help desk staff.\n\n"
            f"Data folder: {DATA_DIR}\n"
            "Pure standard library -- no third-party packages required.")

    def on_close(self):
        if self.editor is not None:
            self.harvest_form()
            if self.dirty and not self.confirm_discard():
                return
        self.destroy()


def main():
    app = TechAssistant()
    app.mainloop()


if __name__ == "__main__":
    main()
