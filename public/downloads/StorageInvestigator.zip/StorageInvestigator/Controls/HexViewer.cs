using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using StorageInvestigator.Services;

namespace StorageInvestigator.Controls;

/// <summary>
/// A lightweight hex viewer built on a RichTextBox surface. Renders an offset gutter, hex
/// columns and an ASCII pane, auto-highlights known filesystem signatures, and shows a
/// tooltip explaining whatever byte field the mouse is hovering over.
/// </summary>
public sealed class HexViewer : UserControl
{
    private readonly TextBox _lbaBox;
    private readonly RichTextBox _surface;
    private readonly TextBlock _detected;
    private readonly ToolTip _tip = new();
    private readonly FilesystemDetector _fs = new();

    private byte[] _data = Array.Empty<byte>();
    private long _baseOffset;
    private IReadOnlyList<FilesystemDetector.FieldNote> _notes = Array.Empty<FilesystemDetector.FieldNote>();

    public Func<long, int, byte[]>? ReadCallback { get; set; }
    public uint SectorSize { get; set; } = 512;

    private static readonly Brush AsciiBrush = new SolidColorBrush(Color.FromRgb(0x8A, 0xD0, 0x8A));
    private static readonly Brush OffsetBrush = new SolidColorBrush(Color.FromRgb(0x6A, 0x9E, 0xD0));
    private static readonly Brush HexBrush = new SolidColorBrush(Color.FromRgb(0xE0, 0xE0, 0xE5));
    private static readonly Brush SigBrush = new SolidColorBrush(Color.FromRgb(0xF0, 0xC0, 0x40));
    private static readonly Brush FieldBrush = new SolidColorBrush(Color.FromRgb(0x40, 0x90, 0xE0));

    public HexViewer()
    {
        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        // --- LBA navigation bar ---
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 8) };
        bar.Children.Add(new TextBlock
        {
            Text = "Jump to LBA:", VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 8, 0), Foreground = HexBrush
        });
        _lbaBox = new TextBox
        {
            Width = 120, Text = "2048",
            Background = new SolidColorBrush(Color.FromRgb(0x25, 0x25, 0x2E)),
            Foreground = HexBrush, BorderBrush = OffsetBrush,
            Padding = new Thickness(6, 3, 6, 3),
            FontFamily = new FontFamily("Consolas")
        };
        _lbaBox.KeyDown += (s, e) => { if (e.Key == Key.Enter) GoToLbaFromBox(); };
        bar.Children.Add(_lbaBox);

        var goBtn = new Button
        {
            Content = "Go", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(14, 3, 14, 3),
            Cursor = Cursors.Hand
        };
        goBtn.Click += (s, e) => GoToLbaFromBox();
        bar.Children.Add(goBtn);

        foreach (var (label, lba) in new[] { ("MBR (0)", 0L), ("GPT (1)", 1L), ("NTFS (2048)", 2048L) })
        {
            var q = new Button { Content = label, Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(10, 3, 10, 3), Cursor = Cursors.Hand };
            long target = lba;
            q.Click += (s, e) => { _lbaBox.Text = target.ToString(); GoToLbaFromBox(); };
            bar.Children.Add(q);
        }
        Grid.SetRow(bar, 0);
        grid.Children.Add(bar);

        // --- detected banner ---
        _detected = new TextBlock
        {
            Margin = new Thickness(0, 0, 0, 8), FontWeight = FontWeights.SemiBold,
            Foreground = SigBrush, FontSize = 14
        };
        Grid.SetRow(_detected, 1);
        grid.Children.Add(_detected);

        // --- hex surface ---
        _surface = new RichTextBox
        {
            IsReadOnly = true,
            Background = new SolidColorBrush(Color.FromRgb(0x1A, 0x1A, 0x20)),
            Foreground = HexBrush,
            BorderBrush = new SolidColorBrush(Color.FromRgb(0x3A, 0x3A, 0x46)),
            FontFamily = new FontFamily("Consolas"),
            FontSize = 13,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        _surface.Document.PageWidth = 1400;
        _surface.MouseMove += SurfaceMouseMove;
        _tip.Placement = System.Windows.Controls.Primitives.PlacementMode.Mouse;
        _surface.ToolTip = _tip;
        _tip.IsOpen = false;
        Grid.SetRow(_surface, 2);
        grid.Children.Add(_surface);

        Content = grid;
    }

    private void GoToLbaFromBox()
    {
        if (long.TryParse(_lbaBox.Text.Trim(), out long lba))
            GoToLba(lba);
    }

    public void GoToLba(long lba)
    {
        if (ReadCallback == null) return;
        _baseOffset = lba * SectorSize;
        _data = ReadCallback(lba, 1); // one sector
        if (_data.Length == 0)
        {
            _detected.Text = "Could not read sector (need admin / drive not selected).";
            _surface.Document.Blocks.Clear();
            return;
        }
        string detected = _fs.Detect(_data);
        _notes = _fs.Annotate(_data);
        _detected.Text = detected != "Unknown"
            ? $"Detected: {detected}   (fields highlighted — hover to explain)"
            : "No known signature at this sector.";
        Render(detected);
    }

    private void Render(string detected)
    {
        var doc = new FlowDocument { PageWidth = 1400 };
        var para = new Paragraph { LineHeight = 18, Margin = new Thickness(0) };

        for (int row = 0; row < _data.Length; row += 16)
        {
            // offset gutter
            para.Inlines.Add(new Run($"{(_baseOffset + row):X8}  ") { Foreground = OffsetBrush });

            // hex columns
            for (int col = 0; col < 16; col++)
            {
                int idx = row + col;
                if (idx < _data.Length)
                {
                    var run = new Run($"{_data[idx]:X2} ")
                    {
                        Foreground = BrushForByte(idx)
                    };
                    para.Inlines.Add(run);
                }
                else para.Inlines.Add(new Run("   "));
                if (col == 7) para.Inlines.Add(new Run(" "));
            }

            para.Inlines.Add(new Run("  ") );

            // ascii
            var sb = new StringBuilder();
            for (int col = 0; col < 16; col++)
            {
                int idx = row + col;
                if (idx < _data.Length)
                {
                    byte b = _data[idx];
                    sb.Append(b >= 0x20 && b < 0x7F ? (char)b : '.');
                }
            }
            para.Inlines.Add(new Run(sb.ToString()) { Foreground = AsciiBrush });
            para.Inlines.Add(new LineBreak());
        }

        doc.Blocks.Add(para);
        _surface.Document = doc;
    }

    private Brush BrushForByte(int index)
    {
        // Signature bytes at the very start of a recognized structure glow.
        foreach (var note in _notes)
            if (index >= note.Offset && index < note.Offset + note.Length)
                return note.Name.Contains("OEM") || note.Name.Contains("Signature") || note.Name.Contains("Jump")
                    ? SigBrush : FieldBrush;
        return HexBrush;
    }

    private void SurfaceMouseMove(object sender, MouseEventArgs e)
    {
        var pos = _surface.GetPositionFromPoint(e.GetPosition(_surface), true);
        if (pos == null) { _tip.IsOpen = false; return; }

        // Approximate the byte index from the caret position within the document text.
        int textOffset = new TextRange(_surface.Document.ContentStart, pos).Text.Length;
        // Each rendered row is "OFFSET  " (10) + 16*3 hex (+1 mid gap) + gap + 16 ascii.
        // Rather than reverse-engineer exact columns, map via line + column heuristics.
        int byteIndex = EstimateByteIndex(textOffset);
        if (byteIndex < 0 || byteIndex >= _data.Length) { _tip.IsOpen = false; return; }

        foreach (var note in _notes)
        {
            if (byteIndex >= note.Offset && byteIndex < note.Offset + note.Length)
            {
                _tip.Content = BuildTip(note);
                _tip.IsOpen = true;
                return;
            }
        }
        _tip.IsOpen = false;
    }

    private object BuildTip(FilesystemDetector.FieldNote note)
    {
        var panel = new StackPanel { MaxWidth = 320 };
        panel.Children.Add(new TextBlock
        {
            Text = note.Name, FontWeight = FontWeights.Bold, FontSize = 13,
            Foreground = Brushes.White
        });
        panel.Children.Add(new TextBlock
        {
            Text = $"Offset 0x{note.Offset:X} · {note.Length} byte(s)",
            Foreground = new SolidColorBrush(Color.FromRgb(0x9A, 0x9A, 0xA6)),
            FontSize = 11, Margin = new Thickness(0, 2, 0, 4)
        });
        panel.Children.Add(new TextBlock
        {
            Text = note.Meaning, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.White
        });
        // show the actual value
        if (note.Offset + note.Length <= _data.Length && note.Length <= 8)
        {
            long val = 0;
            for (int i = 0; i < note.Length; i++) val |= (long)_data[note.Offset + i] << (8 * i);
            panel.Children.Add(new TextBlock
            {
                Text = $"Value: {val} (0x{val:X})",
                Foreground = new SolidColorBrush(Color.FromRgb(0xF0, 0xC0, 0x40)),
                FontFamily = new FontFamily("Consolas"), Margin = new Thickness(0, 4, 0, 0)
            });
        }
        return panel;
    }

    private int EstimateByteIndex(int textOffset)
    {
        // Row layout width in characters (approx): offset(8)+2 spaces = 10, then
        // 16 hex groups * 3 = 48, +1 mid gap, + 2 gap = 61, + 16 ascii = 77, +1 newline.
        const int rowChars = 78;
        int row = textOffset / rowChars;
        int within = textOffset % rowChars;
        if (within < 10) return row * 16;                 // in gutter
        int hexZone = within - 10;
        if (hexZone <= 49)                                 // hex columns
        {
            int col = hexZone / 3;
            if (col > 7) col = (hexZone - 1) / 3;          // account for mid gap
            return Math.Min(row * 16 + col, _data.Length - 1);
        }
        int asciiCol = within - 61;                        // ascii pane
        if (asciiCol is >= 0 and < 16) return row * 16 + asciiCol;
        return -1;
    }
}
