# Storage Investigator

A unified, investigator-focused disk forensics tool for Windows — SMART, partitions,
filesystem validation, a hex viewer, raw signature carving, USB descriptors, and event-log
correlation behind a single **Investigate** button that produces a case report.

Built with **C# / .NET 8 / WPF**. Requires **Windows 10/11** and must be run **as
Administrator** (raw disk access, SMART IOCTLs, and event-log reads require elevation — the
bundled `app.manifest` requests it automatically).

## Build & Run

```powershell
# from the project folder
dotnet build

# run (elevated — right-click the produced exe → Run as administrator,
# or launch an elevated terminal first)
dotnet run
```

### Produce a single distributable EXE

```powershell
dotnet publish -c Release -r win-x64 -p:PublishSingleFile=true --self-contained false
# output: bin\Release\net8.0-windows\win-x64\publish\StorageInvestigator.exe
```

Add `--self-contained true` if you want it to run on machines without the .NET 8 runtime
installed (larger file).

## What each tab does

| Tab          | Backed by | Notes |
|--------------|-----------|-------|
| **Disks**    | `DiskService` (WMI `Win32_DiskDrive` + `MSFT_Disk` + `DeviceIoControl`) | Model, serial, sector size, GPT/MBR, read-only, USB/removable, volumes |
| **SMART**    | `SmartService` (`SMART_RCV_DRIVE_DATA` IOCTL) | Temp, reallocated/pending sectors, power-on hours, cycles, per-attribute grid |
| **Filesystem** | `FilesystemDetector` | Reads boot sector at each partition start, validates NTFS/FAT32/exFAT/GPT/MBR signatures |
| **Partitions** | `MSFT_Partition` + visual map | Proportional colored partition map (Reserved/Recovery/Data/Unused) + table |
| **Hex Viewer** | `HexViewer` + `RawDiskReader` | Jump to any LBA, auto-highlight known fields, **hover any field for a plain-English explanation** |
| **Recovery** | `SignatureScanner` | DMDE-style raw carving for JPEG/PNG/ZIP/PDF/DOCX/MP4/SQLite/VHD/NTFS/FAT signatures |
| **USB**      | `UsbService` (WMI PnP) | VID/PID, manufacturer, controller, USB version, speed |
| **Timeline** | populated by Investigate | Forensic sequence of what the tool did and found |
| **Logs**     | `EventLogService` | Pulls `disk`, `Ntfs`, `Kernel-PnP`, `partmgr`, `storahci`, `volmgr` events — no Event Viewer needed |
| **Reports**  | `ReportGenerator` | Export the case report as HTML, Markdown, or print-to-PDF |

## The Investigate pipeline (`InvestigationService`)

Clicking **Investigate** runs, against the selected disk:

1. Read SMART → hardware health grade
2. Detect partition style + layout
3. Raw-read and validate the boot sector; sanity-check the NTFS `$MFT` FILE record pointer
4. Run a capped (first 2 GiB) raw signature scan
5. Correlate everything into a **recovery-likelihood** grade with concrete recommendations

Example case summary it produces:

```
Hardware health:     Good
Partition table:     Corrupted
NTFS boot sector:    Found @ LBA 2048
MFT:                 Missing (FILE signature not found)
Raw file signatures: Present (137 hits in first 2 GiB)
Recovery likelihood: High (metadata reconstruction likely required)
```

## Architecture

```
StorageInvestigator/
├─ Native/NativeMethods.cs      P/Invoke: CreateFile, DeviceIoControl, SMART, geometry
├─ Models/Models.cs             Domain models (PhysicalDisk, SmartData, PartitionInfo, …)
├─ Services/
│  ├─ DiskService.cs            Enumeration + geometry + volumes + partitions
│  ├─ SmartService.cs           ATA SMART attribute read & health scoring
│  ├─ RawDiskReader.cs          Sector-aligned raw reads
│  ├─ FilesystemDetector.cs     Signature detection + hex field annotations
│  ├─ SignatureScanner.cs       Streaming magic-byte carver
│  ├─ EventLogService.cs        Storage-provider event collection
│  ├─ UsbService.cs             USB descriptor enumeration
│  ├─ InvestigationService.cs   Orchestrates the full pipeline → CaseReport
│  └─ ReportGenerator.cs        HTML / Markdown rendering
├─ Controls/HexViewer.cs        LBA-navigable hex control with hover tooltips
├─ App.xaml(.cs)                Dark forensic theme
└─ MainWindow.xaml(.cs)         Shell, sidebar nav, all tab wiring
```

## Notes & limitations

- **NVMe SMART**: the legacy `SMART_RCV_DRIVE_DATA` IOCTL targets ATA/SATA. NVMe drives use a
  different query path; on those the SMART tab falls back to reporting unavailable rather than
  guessing. Extending `SmartService` with an NVMe protocol-command path is the natural next step.
- **PDF export** currently writes the HTML report and points you to browser *Print → Save as
  PDF*. Swapping in a direct XPS→PDF or a library (e.g. QuestPDF) is a drop-in upgrade in
  `ReportGenerator` / `MainWindow.ExportPdf`.
- **USB descriptors** come from WMI PnP data (enough for VID/PID/speed). Full binary descriptor
  parsing would use SetupAPI + WinUSB IOCTLs.
- The signature scan is intentionally capped at the first 2 GiB inside the Investigate pipeline
  for speed; the Recovery tab uses the same cap but the scanner supports full-disk scans
  (`maxBytes: 0`).

Run everything against a drive you can afford to experiment with, and always image a failing
drive **before** doing recovery work on it.
