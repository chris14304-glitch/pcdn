using System.Collections.ObjectModel;

namespace StorageInvestigator.Models;

public enum HealthStatus { Unknown, Healthy, Caution, Critical }

public sealed class PhysicalDisk
{
    public int DeviceNumber { get; init; }
    public string DevicePath => $@"\\.\PhysicalDrive{DeviceNumber}";
    public string Model { get; set; } = "Unknown";
    public string Serial { get; set; } = "";
    public string FirmwareRevision { get; set; } = "";
    public long SizeBytes { get; set; }
    public uint BytesPerSector { get; set; } = 512;
    public string BusType { get; set; } = "Unknown";
    public bool IsRemovable { get; set; }
    public bool IsUsb { get; set; }
    public bool IsReadOnly { get; set; }
    public string PartitionStyle { get; set; } = "Unknown"; // GPT / MBR / RAW
    public HealthStatus Health { get; set; } = HealthStatus.Unknown;
    public SmartData? Smart { get; set; }
    public ObservableCollection<VolumeInfo> Volumes { get; } = new();
    public ObservableCollection<PartitionInfo> Partitions { get; } = new();

    public string SizeDisplay => FormatBytes(SizeBytes);
    public string StatusLabel => Health switch
    {
        HealthStatus.Healthy => "Healthy",
        HealthStatus.Caution => "Caution",
        HealthStatus.Critical => "Critical",
        _ => IsReadOnly ? "Read Only" : "Unknown"
    };

    public string Glyph => Health switch
    {
        HealthStatus.Healthy => "🟢",
        HealthStatus.Caution => "🟡",
        HealthStatus.Critical => "🔴",
        _ => "⚪"
    };

    public static string FormatBytes(long b)
    {
        string[] u = { "B", "KB", "MB", "GB", "TB", "PB" };
        double v = b; int i = 0;
        while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
        return $"{v:0.##} {u[i]}";
    }
}

public sealed class SmartData
{
    public int? TemperatureC { get; set; }
    public long? PowerOnHours { get; set; }
    public long? PowerCycles { get; set; }
    public long? ReallocatedSectors { get; set; }
    public long? PendingSectors { get; set; }
    public long? UncorrectableSectors { get; set; }
    public bool? OverallStatusOk { get; set; }
    public ObservableCollection<SmartAttribute> Attributes { get; } = new();
}

public sealed class SmartAttribute
{
    public byte Id { get; set; }
    public string Name { get; set; } = "";
    public byte Current { get; set; }
    public byte Worst { get; set; }
    public byte Threshold { get; set; }
    public long RawValue { get; set; }
    public string IdHex => $"0x{Id:X2}";
    public string Status => Threshold != 0 && Current <= Threshold ? "FAIL" : "OK";
}

public sealed class VolumeInfo
{
    public string DriveLetter { get; set; } = "";
    public string Label { get; set; } = "";
    public string FileSystem { get; set; } = "";
    public long SizeBytes { get; set; }
    public long FreeBytes { get; set; }
    public string SizeDisplay => PhysicalDisk.FormatBytes(SizeBytes);
    public string Display => $"{DriveLetter}  {Label}  [{FileSystem}]  {SizeDisplay}";
}

public sealed class PartitionInfo
{
    public int Index { get; set; }
    public long StartingOffset { get; set; }
    public long LengthBytes { get; set; }
    public string TypeLabel { get; set; } = "";
    public string FileSystem { get; set; } = "";
    public string Kind { get; set; } = "Data"; // Reserved / Recovery / Data / Unused
    public long StartLba => StartingOffset / 512;
    public string LengthDisplay => PhysicalDisk.FormatBytes(LengthBytes);
}

public sealed class UsbDeviceInfo
{
    public string Vid { get; set; } = "";
    public string Pid { get; set; } = "";
    public string Manufacturer { get; set; } = "";
    public string Product { get; set; } = "";
    public string SerialNumber { get; set; } = "";
    public string Controller { get; set; } = "";
    public string Speed { get; set; } = "";
    public string UsbVersion { get; set; } = "";
}

public sealed class TimelineEvent
{
    public DateTime Time { get; set; }
    public string Category { get; set; } = "";
    public string Description { get; set; } = "";
    public string TimeDisplay => Time.ToString("HH:mm:ss");
}

public sealed class EventLogEntry
{
    public DateTime Time { get; set; }
    public string Provider { get; set; } = "";
    public string Level { get; set; } = "";
    public int EventId { get; set; }
    public string Message { get; set; } = "";
    public string TimeDisplay => Time.ToString("yyyy-MM-dd HH:mm:ss");
}

public sealed class SignatureHit
{
    public string Type { get; set; } = "";
    public long Offset { get; set; }
    public long Lba => Offset / 512;
    public string OffsetHex => $"0x{Offset:X}";
}
