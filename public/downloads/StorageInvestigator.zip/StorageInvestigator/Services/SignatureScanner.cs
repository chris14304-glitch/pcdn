using StorageInvestigator.Models;

namespace StorageInvestigator.Services;

/// <summary>
/// Streaming raw signature scanner. Reads the disk in large aligned chunks and looks for
/// magic-byte headers of common file and filesystem types — the same carving approach DMDE
/// and PhotoRec use to find data when metadata is gone.
/// </summary>
public sealed class SignatureScanner
{
    public sealed record Signature(string Type, byte[] Magic, int MagicOffset = 0);

    public static readonly IReadOnlyList<Signature> DefaultSignatures = new List<Signature>
    {
        new("JPEG",   new byte[] { 0xFF, 0xD8, 0xFF }),
        new("PNG",    new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A }),
        new("GIF",    new byte[] { 0x47, 0x49, 0x46, 0x38 }),
        new("PDF",    new byte[] { 0x25, 0x50, 0x44, 0x46 }),
        new("ZIP",    new byte[] { 0x50, 0x4B, 0x03, 0x04 }),
        new("DOCX",   new byte[] { 0x50, 0x4B, 0x03, 0x04 }), // container-based; refine by inspection
        new("MP4",    new byte[] { 0x66, 0x74, 0x79, 0x70 }, 4), // "ftyp" at +4
        new("SQLite", new byte[] { 0x53, 0x51, 0x4C, 0x69, 0x74, 0x65, 0x20, 0x66 }),
        new("VHD",    new byte[] { 0x63, 0x6F, 0x6E, 0x65, 0x63, 0x74, 0x69, 0x78 }), // "conectix"
        new("NTFS",   new byte[] { 0xEB, 0x52, 0x90, 0x4E, 0x54, 0x46, 0x53 }),
        new("FAT",    new byte[] { 0x46, 0x41, 0x54, 0x33, 0x32 }, 82),
    };

    /// <summary>
    /// Scan the drive for the selected signature types.
    /// </summary>
    /// <param name="progress">0..1 fraction complete.</param>
    /// <param name="maxBytes">Cap the scan (0 = whole disk).</param>
    public List<SignatureHit> Scan(
        int driveNumber, uint sectorSize, long diskSize,
        IEnumerable<string> selectedTypes,
        IProgress<double>? progress = null,
        CancellationToken ct = default,
        long maxBytes = 0)
    {
        var hits = new List<SignatureHit>();
        var sigs = DefaultSignatures
            .Where(s => selectedTypes.Contains(s.Type, StringComparer.OrdinalIgnoreCase))
            .ToList();
        if (sigs.Count == 0) return hits;

        using var reader = new RawDiskReader(driveNumber, sectorSize);
        if (!reader.IsValid) return hits;

        long limit = maxBytes > 0 ? Math.Min(maxBytes, diskSize) : diskSize;
        const int chunk = 1 << 20; // 1 MiB aligned chunks
        int maxMagic = sigs.Max(s => s.MagicOffset + s.Magic.Length);

        for (long pos = 0; pos < limit; pos += chunk)
        {
            ct.ThrowIfCancellationRequested();
            int want = (int)Math.Min(chunk + maxMagic, limit - pos);
            byte[] buf = reader.Read(pos, want);
            if (buf.Length == 0) break;

            foreach (var sig in sigs)
            {
                int idx = 0;
                while (idx <= buf.Length - (sig.MagicOffset + sig.Magic.Length))
                {
                    int found = IndexOf(buf, sig.Magic, idx + sig.MagicOffset);
                    if (found < 0) break;
                    int headerStart = found - sig.MagicOffset;
                    hits.Add(new SignatureHit
                    {
                        Type = sig.Type,
                        Offset = pos + headerStart
                    });
                    idx = found + 1;
                }
            }

            progress?.Report(Math.Min(1.0, (double)(pos + chunk) / limit));
        }

        progress?.Report(1.0);
        return hits;
    }

    private static int IndexOf(byte[] haystack, byte[] needle, int start)
    {
        int end = haystack.Length - needle.Length;
        for (int i = Math.Max(0, start); i <= end; i++)
        {
            bool ok = true;
            for (int j = 0; j < needle.Length; j++)
                if (haystack[i + j] != needle[j]) { ok = false; break; }
            if (ok) return i;
        }
        return -1;
    }
}
