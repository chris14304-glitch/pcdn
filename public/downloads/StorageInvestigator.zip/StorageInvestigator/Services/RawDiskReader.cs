using Microsoft.Win32.SafeHandles;
using static StorageInvestigator.Native.NativeMethods;

namespace StorageInvestigator.Services;

/// <summary>
/// Sector-aligned raw reader for the hex viewer and signature scanner. Raw physical reads
/// require alignment to sector size when FILE_FLAG_NO_BUFFERING is used, so all reads are
/// snapped to sector boundaries.
/// </summary>
public sealed class RawDiskReader : IDisposable
{
    private readonly SafeFileHandle _handle;
    private readonly uint _sectorSize;
    public bool IsValid => !_handle.IsInvalid;
    public uint SectorSize => _sectorSize;

    public RawDiskReader(int driveNumber, uint sectorSize = 512)
    {
        _sectorSize = sectorSize == 0 ? 512 : sectorSize;
        // Note: intentionally NOT using FILE_FLAG_NO_BUFFERING. That flag requires the
        // destination buffer to be aligned to the volume sector size, which managed byte[]
        // cannot guarantee. Normal buffered reads still allow raw sector access on
        // \\.\PhysicalDriveN and avoid ERROR_INVALID_PARAMETER.
        _handle = CreateFile($@"\\.\PhysicalDrive{driveNumber}",
            GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero,
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, IntPtr.Zero);
    }

    /// <summary>Read <paramref name="count"/> bytes starting at an arbitrary byte offset.</summary>
    public byte[] Read(long byteOffset, int count)
    {
        if (_handle.IsInvalid) return Array.Empty<byte>();

        long alignedStart = byteOffset - (byteOffset % _sectorSize);
        long delta = byteOffset - alignedStart;
        long totalNeeded = delta + count;
        int alignedCount = (int)(((totalNeeded + _sectorSize - 1) / _sectorSize) * _sectorSize);

        if (!SetFilePointerEx(_handle, alignedStart, out _, 0 /*FILE_BEGIN*/))
            return Array.Empty<byte>();

        byte[] buffer = new byte[alignedCount];
        if (!ReadFile(_handle, buffer, (uint)alignedCount, out uint read, IntPtr.Zero))
            return Array.Empty<byte>();

        int available = (int)Math.Min(count, Math.Max(0, (long)read - delta));
        byte[] result = new byte[available];
        Array.Copy(buffer, delta, result, 0, available);
        return result;
    }

    public byte[] ReadLba(long lba, int sectorCount = 1)
        => Read(lba * _sectorSize, (int)(_sectorSize * sectorCount));

    public void Dispose() => _handle.Dispose();
}
