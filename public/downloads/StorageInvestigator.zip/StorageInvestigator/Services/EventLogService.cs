using System.Diagnostics.Eventing.Reader;
using StorageInvestigator.Models;

namespace StorageInvestigator.Services;

/// <summary>
/// Pulls storage-relevant events straight from the System channel so the user never has to
/// open Event Viewer. Filters to the providers that actually matter for disk forensics.
/// </summary>
public sealed class EventLogService
{
    private static readonly string[] Providers =
    {
        "disk", "Ntfs", "Microsoft-Windows-Ntfs",
        "Microsoft-Windows-Kernel-PnP", "partmgr", "storahci",
        "volmgr", "volsnap", "Microsoft-Windows-DiskDiagnostic"
    };

    public List<EventLogEntry> Collect(int maxEntries = 500, TimeSpan? window = null)
    {
        var results = new List<EventLogEntry>();
        window ??= TimeSpan.FromDays(7);
        DateTime since = DateTime.Now - window.Value;

        // Build an XPath filter for the relevant providers.
        string providerClause = string.Join(" or ",
            Providers.Select(p => $"@Name='{p}'"));
        string query =
            $"*[System[Provider[{providerClause}] and " +
            $"TimeCreated[@SystemTime>='{since.ToUniversalTime():o}']]]";

        try
        {
            var elQuery = new EventLogQuery("System", PathType.LogName, query)
            {
                ReverseDirection = true
            };
            using var reader = new EventLogReader(elQuery);
            EventRecord? rec;
            while ((rec = reader.ReadEvent()) != null && results.Count < maxEntries)
            {
                using (rec)
                {
                    results.Add(new EventLogEntry
                    {
                        Time = rec.TimeCreated ?? DateTime.MinValue,
                        Provider = rec.ProviderName ?? "",
                        Level = rec.LevelDisplayName ?? LevelName(rec.Level),
                        EventId = rec.Id,
                        Message = SafeMessage(rec)
                    });
                }
            }
        }
        catch
        {
            // Query syntax varies across builds; fall back to a broad read + filter.
            results.AddRange(FallbackCollect(maxEntries, since));
        }

        return results.OrderByDescending(e => e.Time).ToList();
    }

    private static IEnumerable<EventLogEntry> FallbackCollect(int max, DateTime since)
    {
        var list = new List<EventLogEntry>();
        try
        {
            var q = new EventLogQuery("System", PathType.LogName)
            { ReverseDirection = true };
            using var reader = new EventLogReader(q);
            EventRecord? rec;
            while ((rec = reader.ReadEvent()) != null && list.Count < max)
            {
                using (rec)
                {
                    if ((rec.TimeCreated ?? DateTime.MinValue) < since) break;
                    if (!Providers.Any(p =>
                            string.Equals(p, rec.ProviderName, StringComparison.OrdinalIgnoreCase)))
                        continue;
                    list.Add(new EventLogEntry
                    {
                        Time = rec.TimeCreated ?? DateTime.MinValue,
                        Provider = rec.ProviderName ?? "",
                        Level = rec.LevelDisplayName ?? LevelName(rec.Level),
                        EventId = rec.Id,
                        Message = SafeMessage(rec)
                    });
                }
            }
        }
        catch { /* channel access denied — return what we have */ }
        return list;
    }

    private static string SafeMessage(EventRecord rec)
    {
        try { return (rec.FormatDescription() ?? "").Replace("\r\n", " ").Trim(); }
        catch { return $"Event {rec.Id}"; }
    }

    private static string LevelName(byte? level) => level switch
    {
        1 => "Critical", 2 => "Error", 3 => "Warning",
        4 => "Information", 5 => "Verbose", _ => "Info"
    };
}
