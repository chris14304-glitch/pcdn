using System.Text;
using StorageInvestigator.Models;

namespace StorageInvestigator.Services;

/// <summary>
/// Renders a <see cref="CaseReport"/> to Markdown or a self-contained HTML file. PDF export
/// is produced by printing the HTML through the system print-to-PDF path from the UI layer.
/// </summary>
public sealed class ReportGenerator
{
    public string ToMarkdown(CaseReport r)
    {
        var d = r.Disk;
        var sb = new StringBuilder();
        sb.AppendLine($"# Storage Investigator — Case Report");
        sb.AppendLine();
        sb.AppendLine($"**Generated:** {r.GeneratedAt:yyyy-MM-dd HH:mm:ss}  ");
        sb.AppendLine($"**Disk:** {d.DeviceNumber} — {d.Model}  ");
        sb.AppendLine($"**Serial:** {d.Serial}  ");
        sb.AppendLine($"**Size:** {d.SizeDisplay}  ");
        sb.AppendLine($"**Bus:** {d.BusType}{(d.IsUsb ? " (USB)" : "")}  ");
        sb.AppendLine($"**Sector Size:** {d.BytesPerSector} bytes  ");
        sb.AppendLine($"**Read-Only:** {(d.IsReadOnly ? "Yes" : "No")}  ");
        sb.AppendLine();
        sb.AppendLine("## Case Summary");
        sb.AppendLine();
        sb.AppendLine("| Item | Result |");
        sb.AppendLine("|------|--------|");
        sb.AppendLine($"| Hardware health | {r.HardwareHealth} |");
        sb.AppendLine($"| Partition table | {r.PartitionTable} |");
        sb.AppendLine($"| Boot sector | {r.BootSector} |");
        sb.AppendLine($"| MFT | {r.MftStatus} |");
        sb.AppendLine($"| Raw file signatures | {r.RawSignatures} |");
        sb.AppendLine($"| **Recovery likelihood** | **{r.RecoveryLikelihood}** |");
        sb.AppendLine();

        if (d.Smart != null)
        {
            sb.AppendLine("## SMART");
            sb.AppendLine();
            sb.AppendLine($"- Temperature: {d.Smart.TemperatureC?.ToString() ?? "n/a"} °C");
            sb.AppendLine($"- Power-on hours: {d.Smart.PowerOnHours?.ToString() ?? "n/a"}");
            sb.AppendLine($"- Power cycles: {d.Smart.PowerCycles?.ToString() ?? "n/a"}");
            sb.AppendLine($"- Reallocated sectors: {d.Smart.ReallocatedSectors?.ToString() ?? "n/a"}");
            sb.AppendLine($"- Pending sectors: {d.Smart.PendingSectors?.ToString() ?? "n/a"}");
            sb.AppendLine($"- Overall status: {(d.Smart.OverallStatusOk == true ? "OK" : "Check")}");
            sb.AppendLine();
        }

        if (d.Partitions.Count > 0)
        {
            sb.AppendLine("## Partitions");
            sb.AppendLine();
            sb.AppendLine("| # | Start LBA | Size | Type | Kind |");
            sb.AppendLine("|---|-----------|------|------|------|");
            foreach (var p in d.Partitions)
                sb.AppendLine($"| {p.Index} | {p.StartLba} | {p.LengthDisplay} | {p.TypeLabel} | {p.Kind} |");
            sb.AppendLine();
        }

        if (r.Findings.Count > 0)
        {
            sb.AppendLine("## Findings");
            sb.AppendLine();
            foreach (var f in r.Findings) sb.AppendLine($"- {f}");
            sb.AppendLine();
        }

        sb.AppendLine("## Recommendations");
        sb.AppendLine();
        foreach (var rec in r.Recommendations) sb.AppendLine($"- {rec}");
        sb.AppendLine();

        return sb.ToString();
    }

    public string ToHtml(CaseReport r)
    {
        var d = r.Disk;
        string Row(string k, string v) => $"<tr><td>{Esc(k)}</td><td>{Esc(v)}</td></tr>";
        var sb = new StringBuilder();
        sb.Append("""
        <!DOCTYPE html><html><head><meta charset="utf-8">
        <title>Storage Investigator — Case Report</title>
        <style>
          body{font-family:Segoe UI,Arial,sans-serif;margin:40px;color:#1a1a1a;background:#fff}
          h1{color:#0a5c8a} h2{color:#0a5c8a;border-bottom:2px solid #e0e0e0;padding-bottom:4px}
          table{border-collapse:collapse;width:100%;margin:12px 0}
          td,th{border:1px solid #ccc;padding:8px 12px;text-align:left;font-size:14px}
          th{background:#f0f4f8}
          .summary td:first-child{font-weight:600;width:220px}
          .likelihood{font-size:18px;font-weight:700;color:#0a5c8a}
          .badge{display:inline-block;padding:2px 10px;border-radius:12px;color:#fff;font-size:12px}
        </style></head><body>
        """);
        sb.Append($"<h1>Storage Investigator — Case Report</h1>");
        sb.Append($"<p><b>Generated:</b> {Esc(r.GeneratedAt.ToString("yyyy-MM-dd HH:mm:ss"))}</p>");
        sb.Append("<h2>Device</h2><table class='summary'>");
        sb.Append(Row("Disk", $"{d.DeviceNumber} — {d.Model}"));
        sb.Append(Row("Serial", d.Serial));
        sb.Append(Row("Size", d.SizeDisplay));
        sb.Append(Row("Bus", d.BusType + (d.IsUsb ? " (USB)" : "")));
        sb.Append(Row("Sector Size", $"{d.BytesPerSector} bytes"));
        sb.Append(Row("Read-Only", d.IsReadOnly ? "Yes" : "No"));
        sb.Append("</table>");

        sb.Append("<h2>Case Summary</h2><table class='summary'>");
        sb.Append(Row("Hardware health", r.HardwareHealth));
        sb.Append(Row("Partition table", r.PartitionTable));
        sb.Append(Row("Boot sector", r.BootSector));
        sb.Append(Row("MFT", r.MftStatus));
        sb.Append(Row("Raw file signatures", r.RawSignatures));
        sb.Append($"<tr><td>Recovery likelihood</td><td class='likelihood'>{Esc(r.RecoveryLikelihood)}</td></tr>");
        sb.Append("</table>");

        if (d.Smart != null)
        {
            sb.Append("<h2>SMART</h2><table class='summary'>");
            sb.Append(Row("Temperature (°C)", d.Smart.TemperatureC?.ToString() ?? "n/a"));
            sb.Append(Row("Power-on hours", d.Smart.PowerOnHours?.ToString() ?? "n/a"));
            sb.Append(Row("Power cycles", d.Smart.PowerCycles?.ToString() ?? "n/a"));
            sb.Append(Row("Reallocated sectors", d.Smart.ReallocatedSectors?.ToString() ?? "n/a"));
            sb.Append(Row("Pending sectors", d.Smart.PendingSectors?.ToString() ?? "n/a"));
            sb.Append("</table>");
        }

        if (d.Partitions.Count > 0)
        {
            sb.Append("<h2>Partitions</h2><table><tr><th>#</th><th>Start LBA</th><th>Size</th><th>Type</th><th>Kind</th></tr>");
            foreach (var p in d.Partitions)
                sb.Append($"<tr><td>{p.Index}</td><td>{p.StartLba}</td><td>{Esc(p.LengthDisplay)}</td><td>{Esc(p.TypeLabel)}</td><td>{Esc(p.Kind)}</td></tr>");
            sb.Append("</table>");
        }

        if (r.Findings.Count > 0)
        {
            sb.Append("<h2>Findings</h2><ul>");
            foreach (var f in r.Findings) sb.Append($"<li>{Esc(f)}</li>");
            sb.Append("</ul>");
        }

        sb.Append("<h2>Recommendations</h2><ul>");
        foreach (var rec in r.Recommendations) sb.Append($"<li>{Esc(rec)}</li>");
        sb.Append("</ul>");

        sb.Append("</body></html>");
        return sb.ToString();
    }

    private static string Esc(string s) => System.Net.WebUtility.HtmlEncode(s ?? "");
}
