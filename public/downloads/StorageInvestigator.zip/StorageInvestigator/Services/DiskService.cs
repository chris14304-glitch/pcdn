using System.IO;
using System.Management;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using StorageInvestigator.Models;
using StorageInvestigator.Native;
using static StorageInvestigator.Native.NativeMethods;

namespace StorageInvestigator.Services;

/// <summary>
/// Enumerates physical disks and hydrates geometry, descriptor, read-only and volume data.
/// Uses WMI (MSFT_Disk / Win32_DiskDrive) for friendly metadata and DeviceIoControl for the
/// authoritative low-level facts.
/// </summary>
public sealed class DiskService
{
    public List<PhysicalDisk> EnumerateDisks()
    {
        var disks = new Dictionary<int, PhysicalDisk>();

        // --- Win32_DiskDrive gives model/serial/size and device index ---
        try
        {
            using var searcher = new ManagementObjectSearcher(
                "SELECT * FROM Win32_DiskDrive");
            foreach (ManagementObject mo in searcher.Get())
            {
                int index = Convert.ToInt32(mo["Index"]);
                var disk = new PhysicalDisk
                {
                    DeviceNumber = index,
                    Model = (mo["Model"] as string)?.Trim() ?? "Unknown",
                    Serial = (mo["SerialNumber"] as string)?.Trim() ?? "",
                    FirmwareRevision = (mo["FirmwareRevision"] as string)?.Trim() ?? "",
                    SizeBytes = mo["Size"] != null ? Convert.ToInt64(mo["Size"]) : 0,
                    IsRemovable = (mo["MediaType"] as string)?.Contains(
                                      "Removable", StringComparison.OrdinalIgnoreCase) ?? false,
                    BusType = (mo["InterfaceType"] as string) ?? "Unknown",
                    BytesPerSector = mo["BytesPerSector"] != null
                        ? Convert.ToUInt32(mo["BytesPerSector"]) : 512u,
                    PartitionStyle = "Unknown"
                };
                disk.IsUsb = disk.BusType.Contains("USB", StringComparison.OrdinalIgnoreCase);
                disks[index] = disk;
            }
        }
        catch { /* WMI unavailable — fall back to raw probing below */ }

        // --- MSFT_Disk (Storage namespace) refines partition style + read-only + bus ---
        try
        {
            var scope = new ManagementScope(@"\\.\root\Microsoft\Windows\Storage");
            scope.Connect();
            using var s = new ManagementObjectSearcher(scope,
                new ObjectQuery("SELECT * FROM MSFT_Disk"));
            foreach (ManagementObject mo in s.Get())
            {
                int num = Convert.ToInt32(mo["Number"]);
                if (!disks.TryGetValue(num, out var disk))
                {
                    disk = new PhysicalDisk { DeviceNumber = num };
                    disks[num] = disk;
                }
                disk.PartitionStyle = Convert.ToInt32(mo["PartitionStyle"]) switch
                {
                    1 => "MBR",
                    2 => "GPT",
                    _ => "RAW"
                };
                disk.IsReadOnly = mo["IsReadOnly"] != null && Convert.ToBoolean(mo["IsReadOnly"]);
                if (mo["BusType"] != null)
                    disk.BusType = BusTypeName(Convert.ToInt32(mo["BusType"]));
                disk.IsUsb = disk.BusType.Contains("USB", StringComparison.OrdinalIgnoreCase);
            }
        }
        catch { /* Storage namespace may be missing on older systems */ }

        var list = disks.Values.OrderBy(d => d.DeviceNumber).ToList();

        foreach (var disk in list)
        {
            EnrichWithDeviceIoControl(disk);
            LoadVolumes(disk);
            LoadPartitions(disk);
            // Health default until SMART populates it.
            if (disk.Health == HealthStatus.Unknown && !disk.IsReadOnly)
                disk.Health = HealthStatus.Healthy;
        }

        return list;
    }

    private static string BusTypeName(int bus) => bus switch
    {
        1 => "SCSI", 2 => "ATAPI", 3 => "ATA", 4 => "1394", 5 => "SSA",
        6 => "Fibre", 7 => "USB", 8 => "RAID", 9 => "iSCSI", 10 => "SAS",
        11 => "SATA", 12 => "SD", 13 => "MMC", 17 => "NVMe", _ => "Unknown"
    };

    private void EnrichWithDeviceIoControl(PhysicalDisk disk)
    {
        SafeFileHandle? h = null;
        try
        {
            h = CreateFile(disk.DevicePath, GENERIC_READ,
                FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero,
                OPEN_EXISTING, 0, IntPtr.Zero);
            if (h.IsInvalid) return;

            // Geometry — authoritative sector size and disk size
            int geoSize = Marshal.SizeOf<DISK_GEOMETRY_EX>();
            IntPtr geoBuf = Marshal.AllocHGlobal(geoSize + 512);
            try
            {
                if (DeviceIoControl(h, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX,
                        IntPtr.Zero, 0, geoBuf, (uint)(geoSize + 512),
                        out _, IntPtr.Zero))
                {
                    var geo = Marshal.PtrToStructure<DISK_GEOMETRY_EX>(geoBuf);
                    if (geo.Geometry.BytesPerSector > 0)
                        disk.BytesPerSector = geo.Geometry.BytesPerSector;
                    if (geo.DiskSize > 0)
                        disk.SizeBytes = geo.DiskSize;
                }
            }
            finally { Marshal.FreeHGlobal(geoBuf); }

            // Read-only check via IOCTL_DISK_IS_WRITABLE
            bool writable = DeviceIoControl(h, IOCTL_DISK_IS_WRITABLE,
                IntPtr.Zero, 0, IntPtr.Zero, 0, out _, IntPtr.Zero);
            if (!writable)
            {
                int err = Marshal.GetLastWin32Error();
                // ERROR_WRITE_PROTECT = 19
                if (err == 19) disk.IsReadOnly = true;
            }
        }
        catch { /* leave WMI-derived values */ }
        finally { h?.Dispose(); }
    }

    private void LoadVolumes(PhysicalDisk disk)
    {
        try
        {
            // Map partitions -> logical disks for this physical drive.
            // WQL needs the DeviceID exactly as: \\.\PHYSICALDRIVE0
            // In WQL each backslash is written doubled, giving \\\\.\\PHYSICALDRIVE0.
            string deviceId = $@"\\\\.\\PHYSICALDRIVE{disk.DeviceNumber}";
            using var partSearcher = new ManagementObjectSearcher(
                $"ASSOCIATORS OF {{Win32_DiskDrive.DeviceID='{deviceId}'}} " +
                "WHERE AssocClass=Win32_DiskDriveToDiskPartition");
            foreach (ManagementObject part in partSearcher.Get())
            {
                using var logSearcher = new ManagementObjectSearcher(
                    $"ASSOCIATORS OF {{Win32_DiskPartition.DeviceID='{part["DeviceID"]}'}} " +
                    "WHERE AssocClass=Win32_LogicalDiskToPartition");
                foreach (ManagementObject log in logSearcher.Get())
                {
                    disk.Volumes.Add(new VolumeInfo
                    {
                        DriveLetter = (log["DeviceID"] as string) ?? "",
                        Label = (log["VolumeName"] as string) ?? "",
                        FileSystem = (log["FileSystem"] as string) ?? "",
                        SizeBytes = log["Size"] != null ? Convert.ToInt64(log["Size"]) : 0,
                        FreeBytes = log["FreeSpace"] != null ? Convert.ToInt64(log["FreeSpace"]) : 0
                    });
                }
            }
        }
        catch { /* best effort */ }
    }

    private void LoadPartitions(PhysicalDisk disk)
    {
        try
        {
            var scope = new ManagementScope(@"\\.\root\Microsoft\Windows\Storage");
            scope.Connect();
            using var s = new ManagementObjectSearcher(scope, new ObjectQuery(
                $"SELECT * FROM MSFT_Partition WHERE DiskNumber={disk.DeviceNumber}"));
            int i = 0;
            foreach (ManagementObject mo in s.Get())
            {
                long offset = mo["Offset"] != null ? Convert.ToInt64(mo["Offset"]) : 0;
                long size = mo["Size"] != null ? Convert.ToInt64(mo["Size"]) : 0;
                string type = (mo["GptType"] as string) ?? (mo["MbrType"]?.ToString() ?? "");
                bool isSystem = mo["IsSystem"] != null && Convert.ToBoolean(mo["IsSystem"]);
                bool isRecovery = mo["GptType"] is string g &&
                    g.Contains("de94bba4", StringComparison.OrdinalIgnoreCase);

                disk.Partitions.Add(new PartitionInfo
                {
                    Index = i++,
                    StartingOffset = offset,
                    LengthBytes = size,
                    TypeLabel = MapGptType(type),
                    Kind = isRecovery ? "Recovery" : isSystem ? "Reserved" : "Data"
                });
            }
        }
        catch { /* Storage namespace absent */ }
    }

    private static string MapGptType(string gpt)
    {
        if (string.IsNullOrEmpty(gpt)) return "Unknown";
        gpt = gpt.Trim('{', '}').ToLowerInvariant();
        return gpt switch
        {
            "c12a7328-f81f-11d2-ba4b-00a0c93ec93b" => "EFI System",
            "e3c9e316-0b5c-4db8-817d-f92df00215ae" => "Microsoft Reserved",
            "ebd0a0a2-b9e5-4433-87c0-68b6b72699c7" => "Basic Data",
            "de94bba4-06d1-4d40-a16a-bfd50179d6ac" => "Windows Recovery",
            _ => gpt.Length > 8 ? gpt[..8] + "…" : gpt
        };
    }
}
