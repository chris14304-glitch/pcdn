using StorageInvestigator.Models;

namespace StorageInvestigator.Services;

public sealed class CaseReport
{
    public PhysicalDisk Disk { get; init; } = null!;
    public DateTime GeneratedAt { get; } = DateTime.Now;
    public string HardwareHealth { get; set; } = "Unknown";
    public string PartitionTable { get; set; } = "Unknown";
    public string BootSector { get; set; } = "Not checked";
    public string MftStatus { get; set; } = "Not checked";
    public string RawSignatures { get; set; } = "Not scanned";
    public string RecoveryLikelihood { get; set; } = "Unknown";
    public List<string> Findings { get; } = new();
    public List<string> Recommendations { get; } = new();
    public List<SignatureHit> Hits { get; } = new();
}

/// <summary>
/// The "Investigate" button's brain. Runs the full pipeline against one disk and correlates
/// results into a single case report with a confidence-graded recovery outlook.
/// </summary>
public sealed class InvestigationService
{
    private readonly SmartService _smart = new();
    private readonly FilesystemDetector _fs = new();

    public CaseReport Investigate(
        PhysicalDisk disk,
        IEnumerable<string> scanTypes,
        Action<TimelineEvent>? onEvent = null,
        IProgress<double>? progress = null,
        CancellationToken ct = default)
    {
        var report = new CaseReport { Disk = disk };
        void Emit(string cat, string desc) =>
            onEvent?.Invoke(new TimelineEvent { Time = DateTime.Now, Category = cat, Description = desc });

        // 1. SMART
        Emit("SMART", $"Reading SMART for Disk {disk.DeviceNumber}");
        disk.Smart = _smart.ReadSmart(disk);
        report.HardwareHealth = disk.Health switch
        {
            HealthStatus.Healthy => "Good",
            HealthStatus.Caution => "Degraded",
            HealthStatus.Critical => "Failing",
            _ => "Unknown"
        };
        if (disk.Smart?.ReallocatedSectors is > 0)
            report.Findings.Add($"Reallocated sectors: {disk.Smart.ReallocatedSectors}");
        if (disk.Smart?.PendingSectors is > 0)
            report.Findings.Add($"Pending sectors: {disk.Smart.PendingSectors} (unstable media)");
        progress?.Report(0.2);

        // 2. Partition table
        Emit("Partitions", "Detecting partition style and layout");
        report.PartitionTable = disk.PartitionStyle;
        bool tableCorrupt = disk.PartitionStyle == "RAW" || disk.Partitions.Count == 0;
        progress?.Report(0.4);

        // 3. Boot sector + MFT via raw read
        Emit("Boot", "Validating boot sector");
        using (var reader = new RawDiskReader(disk.DeviceNumber, disk.BytesPerSector))
        {
            if (reader.IsValid)
            {
                // Common NTFS partition start on modern GPT layouts.
                foreach (var part in disk.Partitions.DefaultIfEmpty(new PartitionInfo { StartingOffset = 1048576 }))
                {
                    ct.ThrowIfCancellationRequested();
                    byte[] boot = reader.Read(part.StartingOffset, 512);
                    string kind = _fs.Detect(boot);
                    if (kind == "NTFS")
                    {
                        report.BootSector = $"NTFS boot sector found @ LBA {part.StartLba}";
                        report.Findings.Add(report.BootSector);
                        // MFT pointer sanity: bytes 0x30..0x37 give MFT cluster.
                        long mftCluster = BitConverter.ToInt64(boot, 0x30);
                        byte spc = boot[0x0D];
                        long mftByte = mftCluster * spc * disk.BytesPerSector + part.StartingOffset;
                        byte[] mft = reader.Read(mftByte, 512);
                        bool mftOk = mft.Length >= 4 && mft[0] == (byte)'F'
                                     && mft[1] == (byte)'I' && mft[2] == (byte)'L' && mft[3] == (byte)'E';
                        report.MftStatus = mftOk ? "MFT present (FILE record valid)" : "MFT missing / unreadable";
                        Emit("MFT", report.MftStatus);
                        if (!mftOk) report.Findings.Add("MFT FILE signature not found at expected offset");
                        break;
                    }
                    if (kind is "FAT32" or "exFAT")
                    {
                        report.BootSector = $"{kind} boot sector found @ LBA {part.StartLba}";
                        report.MftStatus = "N/A (non-NTFS)";
                        break;
                    }
                }
                if (report.BootSector == "Not checked")
                    report.Findings.Add("No recognizable boot sector at partition starts");
            }
        }
        progress?.Report(0.6);

        // 4. Raw signature scan (capped for speed in the pipeline)
        var typeList = scanTypes.ToList();
        if (typeList.Count > 0)
        {
            Emit("Scan", $"Raw signature scan: {string.Join(", ", typeList)}");
            var scanner = new SignatureScanner();
            long cap = Math.Min(disk.SizeBytes, 2L * 1024 * 1024 * 1024); // first 2 GiB in pipeline
            report.Hits.AddRange(scanner.Scan(disk.DeviceNumber, disk.BytesPerSector,
                disk.SizeBytes, typeList, progress: null, ct: ct, maxBytes: cap));
            report.RawSignatures = report.Hits.Count > 0
                ? $"Present ({report.Hits.Count} hits in first {PhysicalDisk.FormatBytes(cap)})"
                : "None found in sampled region";
        }
        progress?.Report(0.9);

        // 5. Correlate → recovery likelihood
        Emit("Report", "Correlating findings");
        report.RecoveryLikelihood = ScoreRecovery(disk, report, tableCorrupt);
        BuildRecommendations(disk, report, tableCorrupt);
        progress?.Report(1.0);

        return report;
    }

    private static string ScoreRecovery(PhysicalDisk disk, CaseReport r, bool tableCorrupt)
    {
        bool hwFailing = disk.Health == HealthStatus.Critical;
        bool bootFound = r.BootSector.Contains("found", StringComparison.OrdinalIgnoreCase);
        bool mftMissing = r.MftStatus.Contains("missing", StringComparison.OrdinalIgnoreCase);
        bool sigsPresent = r.Hits.Count > 0;

        if (hwFailing)
            return "Low–Moderate (hardware failing — image the drive first)";
        if (bootFound && !mftMissing && !tableCorrupt)
            return "Very High (structures intact)";
        if (bootFound && mftMissing)
            return "High (metadata reconstruction likely required)";
        if (tableCorrupt && sigsPresent)
            return "Moderate (raw carving viable, no metadata)";
        if (sigsPresent)
            return "Moderate (file signatures present)";
        return "Uncertain (insufficient signal)";
    }

    private static void BuildRecommendations(PhysicalDisk disk, CaseReport r, bool tableCorrupt)
    {
        if (disk.Health == HealthStatus.Critical)
            r.Recommendations.Add("Create a full sector-by-sector image immediately (ddrescue / image tool) before further work — drive is failing.");
        if (tableCorrupt)
            r.Recommendations.Add("Partition table is damaged; attempt GPT backup header restore (backup lives at last LBA) or partition rebuild.");
        if (r.MftStatus.Contains("missing", StringComparison.OrdinalIgnoreCase))
            r.Recommendations.Add("Reconstruct the MFT from $MFTMirr or via record carving.");
        if (r.Hits.Count > 0)
            r.Recommendations.Add("Raw file signatures detected — signature-based carving can recover files even without metadata.");
        if (r.Recommendations.Count == 0)
            r.Recommendations.Add("No corruption detected. If data appears missing, run a full-disk signature scan for deleted-but-not-overwritten content.");
        if (disk.IsReadOnly)
            r.Recommendations.Add("Disk is read-only — good for forensics. Keep it that way while imaging.");
    }
}
