using System.Management;
using System.Text.RegularExpressions;
using StorageInvestigator.Models;

namespace StorageInvestigator.Services;

/// <summary>
/// Reads USB device descriptors (VID/PID/manufacturer/speed) via WMI PnP data. Full binary
/// descriptor parsing would use SetupAPI + WinUSB IOCTLs; WMI covers the fields the UI shows
/// without unmanaged plumbing.
/// </summary>
public sealed partial class UsbService
{
    [GeneratedRegex(@"VID_([0-9A-Fa-f]{4})")] private static partial Regex VidRegex();
    [GeneratedRegex(@"PID_([0-9A-Fa-f]{4})")] private static partial Regex PidRegex();

    public List<UsbDeviceInfo> Enumerate()
    {
        var list = new List<UsbDeviceInfo>();
        try
        {
            using var searcher = new ManagementObjectSearcher(
                "SELECT * FROM Win32_PnPEntity WHERE DeviceID LIKE 'USB%'");
            foreach (ManagementObject mo in searcher.Get())
            {
                string id = (mo["DeviceID"] as string) ?? "";
                var vid = VidRegex().Match(id);
                var pid = PidRegex().Match(id);
                if (!vid.Success && !pid.Success) continue;

                list.Add(new UsbDeviceInfo
                {
                    Vid = vid.Success ? vid.Groups[1].Value.ToUpperInvariant() : "----",
                    Pid = pid.Success ? pid.Groups[1].Value.ToUpperInvariant() : "----",
                    Manufacturer = (mo["Manufacturer"] as string) ?? "",
                    Product = (mo["Name"] as string) ?? "",
                    Controller = (mo["Service"] as string) ?? "",
                    SerialNumber = ExtractSerial(id),
                });
            }

            // Speed / USB version from Win32_USBHub + associated controller data.
            EnrichSpeeds(list);
        }
        catch { /* WMI unavailable */ }

        return list
            .GroupBy(d => (d.Vid, d.Pid, d.SerialNumber))
            .Select(g => g.First())
            .ToList();
    }

    private static string ExtractSerial(string deviceId)
    {
        // Last path segment is often the serial when the device reports one.
        var parts = deviceId.Split('\\');
        if (parts.Length >= 3)
        {
            string last = parts[^1];
            if (!last.Contains('&')) return last; // '&' => Windows-generated, not a real serial
        }
        return "";
    }

    private static void EnrichSpeeds(List<UsbDeviceInfo> list)
    {
        try
        {
            using var s = new ManagementObjectSearcher(
                "SELECT * FROM Win32_USBController");
            foreach (ManagementObject mo in s.Get())
            {
                string name = (mo["Name"] as string) ?? "";
                string ver = name.Contains("3.1") ? "USB 3.1"
                           : name.Contains("3.0") || name.Contains("xHCI") ? "USB 3.x"
                           : name.Contains("2.0") || name.Contains("EHCI") ? "USB 2.0"
                           : "USB";
                foreach (var d in list.Where(d => string.IsNullOrEmpty(d.UsbVersion)))
                {
                    d.UsbVersion = ver;
                    d.Speed = ver switch
                    {
                        "USB 3.1" => "10 Gbps",
                        "USB 3.x" => "5 Gbps",
                        "USB 2.0" => "480 Mbps",
                        _ => "Unknown"
                    };
                }
            }
        }
        catch { /* best effort */ }
    }
}
