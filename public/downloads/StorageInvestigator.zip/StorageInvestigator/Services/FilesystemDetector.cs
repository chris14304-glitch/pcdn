namespace StorageInvestigator.Services;

/// <summary>
/// Signature-based boot-sector / filesystem detection plus the field annotations that
/// power the hex viewer's hover tooltips. Kept deliberately declarative so new signatures
/// and field maps are easy to add.
/// </summary>
public sealed class FilesystemDetector
{
    public sealed record FieldNote(int Offset, int Length, string Name, string Meaning);

    /// <summary>Identify a filesystem/table type from a 512+ byte sector buffer.</summary>
    public string Detect(byte[] sector)
    {
        if (sector.Length < 512) return "Unknown";

        // GPT protective / primary header at LBA1 begins "EFI PART".
        if (Match(sector, 0, "EFI PART")) return "GPT Header";

        // NTFS: "NTFS    " OEM id at offset 3.
        if (Match(sector, 3, "NTFS")) return "NTFS";

        // exFAT: "EXFAT   " at offset 3.
        if (Match(sector, 3, "EXFAT")) return "exFAT";

        // FAT32: "FAT32   " at offset 82.
        if (sector.Length > 90 && Match(sector, 82, "FAT32")) return "FAT32";

        // FAT12/16: "FAT" at offset 54.
        if (Match(sector, 54, "FAT")) return "FAT16/12";

        // MBR: boot signature 0x55AA at 510 with partition table entries.
        if (sector[510] == 0x55 && sector[511] == 0xAA)
        {
            // If first partition entry type byte 0xEE -> protective MBR (GPT disk).
            if (sector[450] == 0xEE) return "Protective MBR (GPT)";
            return "MBR";
        }

        return "Unknown";
    }

    /// <summary>Return byte-field annotations for the detected structure at this sector.</summary>
    public IReadOnlyList<FieldNote> Annotate(byte[] sector)
    {
        string kind = Detect(sector);
        return kind switch
        {
            "NTFS" => NtfsBootFields,
            "FAT32" => Fat32BootFields,
            "GPT Header" => GptHeaderFields,
            var m when m.StartsWith("MBR") || m.Contains("MBR") => MbrFields,
            _ => Array.Empty<FieldNote>()
        };
    }

    private static bool Match(byte[] buf, int offset, string ascii)
    {
        if (offset + ascii.Length > buf.Length) return false;
        for (int i = 0; i < ascii.Length; i++)
            if (buf[offset + i] != (byte)ascii[i]) return false;
        return true;
    }

    private static readonly FieldNote[] NtfsBootFields =
    {
        new(0x00, 3, "Jump Instruction", "JMP to bootstrap code (EB 52 90)"),
        new(0x03, 8, "OEM ID", "\"NTFS    \" — identifies the filesystem"),
        new(0x0B, 2, "Bytes Per Sector", "Usually 512"),
        new(0x0D, 1, "Sectors Per Cluster", "Cluster size in sectors"),
        new(0x28, 8, "Total Sectors", "Volume size in sectors"),
        new(0x30, 8, "MFT Cluster Number", "Logical cluster of the $MFT"),
        new(0x38, 8, "MFT Mirror Cluster", "Logical cluster of $MFTMirr"),
        new(0x1FE, 2, "Boot Signature", "0x55AA end-of-sector marker"),
    };

    private static readonly FieldNote[] Fat32BootFields =
    {
        new(0x00, 3, "Jump Instruction", "JMP to bootstrap code"),
        new(0x03, 8, "OEM Name", "Formatting utility identifier"),
        new(0x0B, 2, "Bytes Per Sector", "Usually 512"),
        new(0x0D, 1, "Sectors Per Cluster", "Cluster size in sectors"),
        new(0x10, 1, "Number of FATs", "Usually 2"),
        new(0x24, 4, "Sectors Per FAT", "FAT32 large FAT size"),
        new(0x2C, 4, "Root Cluster", "First cluster of root directory"),
        new(0x52, 8, "FS Type Label", "\"FAT32   \""),
        new(0x1FE, 2, "Boot Signature", "0x55AA end-of-sector marker"),
    };

    private static readonly FieldNote[] GptHeaderFields =
    {
        new(0x00, 8, "Signature", "\"EFI PART\""),
        new(0x08, 4, "Revision", "GPT revision (00 00 01 00)"),
        new(0x10, 4, "Header Size", "Usually 92 bytes"),
        new(0x18, 8, "Current LBA", "Location of this header"),
        new(0x20, 8, "Backup LBA", "Location of backup header"),
        new(0x28, 8, "First Usable LBA", "First partition-usable sector"),
        new(0x48, 8, "Partition Entries LBA", "Start of partition array"),
        new(0x50, 4, "Number of Entries", "Partition array size"),
    };

    private static readonly FieldNote[] MbrFields =
    {
        new(0x000, 446, "Bootstrap Code", "Master boot code"),
        new(0x1BE, 16, "Partition Entry 1", "Type, CHS, LBA start, size"),
        new(0x1CE, 16, "Partition Entry 2", "Second partition entry"),
        new(0x1DE, 16, "Partition Entry 3", "Third partition entry"),
        new(0x1EE, 16, "Partition Entry 4", "Fourth partition entry"),
        new(0x1FE, 2, "Boot Signature", "0x55AA"),
    };
}
