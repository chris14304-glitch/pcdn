using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
using StorageInvestigator.Models;
using static StorageInvestigator.Native.NativeMethods;

namespace StorageInvestigator.Services;

/// <summary>
/// Reads SMART attributes through the legacy SMART_RCV_DRIVE_DATA IOCTL. This is the same
/// mechanism CrystalDiskInfo uses for ATA/SATA drives. NVMe requires a different query and
/// is handled by falling back to WMI thermal/health data.
/// </summary>
public sealed class SmartService
{
    // Canonical SMART attribute names (subset that matters for health triage).
    private static readonly Dictionary<byte, string> AttrNames = new()
    {
        [0x01] = "Read Error Rate",
        [0x05] = "Reallocated Sectors Count",
        [0x09] = "Power-On Hours",
        [0x0A] = "Spin Retry Count",
        [0x0C] = "Power Cycle Count",
        [0xB1] = "Wear Leveling Count",
        [0xB5] = "Program Fail Count Total",
        [0xB7] = "SATA Downshift Error Count",
        [0xBB] = "Reported Uncorrectable Errors",
        [0xBC] = "Command Timeout",
        [0xC2] = "Temperature",
        [0xC3] = "Hardware ECC Recovered",
        [0xC5] = "Current Pending Sector Count",
        [0xC6] = "Uncorrectable Sector Count",
        [0xC7] = "UltraDMA CRC Error Count",
        [0xE7] = "SSD Life Left",
        [0xF1] = "Total LBAs Written",
        [0xF2] = "Total LBAs Read",
    };

    public SmartData? ReadSmart(PhysicalDisk disk)
    {
        var data = TryReadAtaSmart(disk.DeviceNumber);
        if (data != null)
        {
            ApplyHealth(disk, data);
            return data;
        }
        return null;
    }

    private SmartData? TryReadAtaSmart(int driveNumber)
    {
        SafeFileHandle? h = null;
        try
        {
            h = CreateFile($@"\\.\PhysicalDrive{driveNumber}",
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero,
                OPEN_EXISTING, 0, IntPtr.Zero);
            if (h.IsInvalid) return null;

            // Confirm SMART support.
            int verSize = Marshal.SizeOf<GETVERSIONINPARAMS>();
            IntPtr verBuf = Marshal.AllocHGlobal(verSize);
            try
            {
                if (!DeviceIoControl(h, SMART_GET_VERSION, IntPtr.Zero, 0,
                        verBuf, (uint)verSize, out _, IntPtr.Zero))
                    return null;
            }
            finally { Marshal.FreeHGlobal(verBuf); }

            // Build SENDCMDINPARAMS for READ_ATTRIBUTES.
            const int READ_BUFFER = 512;
            int inSize = Marshal.SizeOf<SENDCMDINPARAMS>() - 1 + READ_BUFFER;
            int outSize = inSize; // out buffer mirrors in + data
            IntPtr inBuf = Marshal.AllocHGlobal(inSize);
            IntPtr outBuf = Marshal.AllocHGlobal(outSize);
            try
            {
                var p = new SENDCMDINPARAMS
                {
                    cBufferSize = READ_BUFFER,
                    bDriveNumber = (byte)driveNumber,
                    irDriveRegs = new IDEREGS
                    {
                        bFeaturesReg = READ_ATTRIBUTES,
                        bSectorCountReg = 1,
                        bSectorNumberReg = 1,
                        bCylLowReg = SMART_CYL_LOW,
                        bCylHighReg = SMART_CYL_HI,
                        bDriveHeadReg = 0xA0,
                        bCommandReg = SMART_CMD
                    }
                };
                Marshal.StructureToPtr(p, inBuf, false);

                if (!DeviceIoControl(h, SMART_RCV_DRIVE_DATA, inBuf,
                        (uint)inSize, outBuf, (uint)outSize, out _, IntPtr.Zero))
                    return null;

                // Attribute data begins 16 bytes into the output buffer's bBuffer
                // (SENDCMDOUTPARAMS header) + 2 byte version prefix.
                int dataStart = Marshal.SizeOf<SENDCMDINPARAMS>() - 1 + 2;
                byte[] raw = new byte[outSize];
                Marshal.Copy(outBuf, raw, 0, outSize);
                return ParseAttributes(raw, dataStart);
            }
            finally
            {
                Marshal.FreeHGlobal(inBuf);
                Marshal.FreeHGlobal(outBuf);
            }
        }
        catch { return null; }
        finally { h?.Dispose(); }
    }

    private SmartData ParseAttributes(byte[] raw, int start)
    {
        var d = new SmartData();
        // Each attribute record is 12 bytes; up to 30 records.
        for (int i = 0; i < MAX_DRIVE_ATTRIBUTES; i++)
        {
            int off = start + i * 12;
            if (off + 12 > raw.Length) break;
            byte id = raw[off];
            if (id == 0) continue;

            byte current = raw[off + 3];
            byte worst = raw[off + 4];
            long rawVal = raw[off + 5]
                | ((long)raw[off + 6] << 8)
                | ((long)raw[off + 7] << 16)
                | ((long)raw[off + 8] << 24)
                | ((long)raw[off + 9] << 32)
                | ((long)raw[off + 10] << 40);

            var attr = new SmartAttribute
            {
                Id = id,
                Name = AttrNames.TryGetValue(id, out var n) ? n : $"Vendor 0x{id:X2}",
                Current = current,
                Worst = worst,
                RawValue = rawVal
            };
            d.Attributes.Add(attr);

            switch (id)
            {
                case 0x05: d.ReallocatedSectors = rawVal; break;
                case 0x09: d.PowerOnHours = rawVal & 0xFFFFFFFF; break;
                case 0x0C: d.PowerCycles = rawVal & 0xFFFFFFFF; break;
                case 0xC2: d.TemperatureC = (int)(rawVal & 0xFF); break;
                case 0xC5: d.PendingSectors = rawVal; break;
                case 0xC6: d.UncorrectableSectors = rawVal; break;
            }
        }
        return d;
    }

    private void ApplyHealth(PhysicalDisk disk, SmartData d)
    {
        bool critical = (d.ReallocatedSectors ?? 0) > 50
                        || (d.PendingSectors ?? 0) > 0
                        || (d.UncorrectableSectors ?? 0) > 0
                        || d.OverallStatusOk == false;
        bool caution = (d.ReallocatedSectors ?? 0) > 0
                       || (d.TemperatureC ?? 0) >= 60;

        disk.Health = critical ? HealthStatus.Critical
                    : caution ? HealthStatus.Caution
                    : HealthStatus.Healthy;
        d.OverallStatusOk = !critical;
    }
}
