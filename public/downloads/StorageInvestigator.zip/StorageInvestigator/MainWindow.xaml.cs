using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using StorageInvestigator.Models;
using StorageInvestigator.Services;

namespace StorageInvestigator;

public partial class MainWindow : Window
{
    private readonly DiskService _diskSvc = new();
    private readonly SmartService _smartSvc = new();
    private readonly EventLogService _logSvc = new();
    private readonly UsbService _usbSvc = new();
    private readonly SignatureScanner _scanner = new();
    private readonly FilesystemDetector _fs = new();
    private readonly InvestigationService _investigator = new();
    private readonly ReportGenerator _reporter = new();

    private List<PhysicalDisk> _disks = new();
    private PhysicalDisk? _active;
    private CaseReport? _lastReport;
    private readonly ObservableCollection<TimelineEvent> _timeline = new();

    private readonly string[] _sigTypes =
        { "JPEG", "PNG", "GIF", "PDF", "ZIP", "DOCX", "MP4", "SQLite", "VHD", "NTFS", "FAT" };

    public MainWindow()
    {
        InitializeComponent();
        TimelineList.ItemsSource = _timeline;
        BuildSignatureChecks();
        Loaded += (s, e) => LoadDisks();
    }

    // ---------- disk loading ----------
    private void LoadDisks()
    {
        Status("Enumerating physical disks…");
        try
        {
            _disks = _diskSvc.EnumerateDisks();
            DisksList.ItemsSource = _disks;
            DiskCombo.ItemsSource = _disks;
            DiskCombo.DisplayMemberPath = nameof(PhysicalDisk.Model);
            if (_disks.Count > 0) DiskCombo.SelectedIndex = 0;
            Status($"Found {_disks.Count} physical drive(s).");
        }
        catch (Exception ex)
        {
            Status("Enumeration failed: " + ex.Message);
        }
    }

    private void Refresh_Click(object sender, RoutedEventArgs e) => LoadDisks();

    private void DiskCombo_Changed(object sender, SelectionChangedEventArgs e)
    {
        _active = DiskCombo.SelectedItem as PhysicalDisk;
        if (_active == null) return;
        RenderDiskInfo();
        VolumesGrid.ItemsSource = _active.Volumes;
        PartitionsGrid.ItemsSource = _active.Partitions;
        RenderPartitionMap();
        HexView.SectorSize = _active.BytesPerSector;
        HexView.ReadCallback = (lba, sectors) =>
        {
            using var r = new RawDiskReader(_active.DeviceNumber, _active.BytesPerSector);
            return r.IsValid ? r.ReadLba(lba, sectors) : Array.Empty<byte>();
        };
    }

    private void RenderDiskInfo()
    {
        DiskInfoGrid.Children.Clear();
        DiskInfoGrid.RowDefinitions.Clear();
        if (_active == null) return;
        var rows = new (string, string)[]
        {
            ("Model", _active.Model),
            ("Serial", _active.Serial),
            ("Firmware", _active.FirmwareRevision),
            ("Size", _active.SizeDisplay),
            ("Sector Size", $"{_active.BytesPerSector} bytes"),
            ("Partition Style", _active.PartitionStyle),
            ("Bus Type", _active.BusType),
            ("USB", _active.IsUsb ? "Yes" : "No"),
            ("Removable", _active.IsRemovable ? "Yes" : "No"),
            ("Read Only", _active.IsReadOnly ? "Yes" : "No"),
        };
        for (int i = 0; i < rows.Length; i++)
        {
            DiskInfoGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var k = new TextBlock { Text = rows[i].Item1, Margin = new Thickness(0, 4, 0, 4), Foreground = (Brush)FindResource("MutedBrush") };
            var v = new TextBlock { Text = rows[i].Item2, Margin = new Thickness(0, 4, 0, 4), FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap };
            Grid.SetRow(k, i); Grid.SetColumn(k, 0);
            Grid.SetRow(v, i); Grid.SetColumn(v, 1);
            DiskInfoGrid.Children.Add(k);
            DiskInfoGrid.Children.Add(v);
        }
    }

    private void RenderPartitionMap()
    {
        PartitionMap.Children.Clear();
        PartitionMap.ColumnDefinitions.Clear();
        if (_active == null || _active.SizeBytes == 0) return;

        var colors = new Dictionary<string, Color>
        {
            ["Reserved"] = Color.FromRgb(0x5A, 0x6A, 0x8A),
            ["Recovery"] = Color.FromRgb(0xC0, 0x7A, 0x40),
            ["Data"] = Color.FromRgb(0x3B, 0x9E, 0xE0),
            ["Unused"] = Color.FromRgb(0x3A, 0x3A, 0x46),
        };

        long covered = 0; int col = 0;
        void AddCell(string label, long size, string kind)
        {
            double star = Math.Max(0.02, (double)size / _active!.SizeBytes);
            PartitionMap.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(star, GridUnitType.Star) });
            var c = colors.TryGetValue(kind, out var cc) ? cc : colors["Data"];
            var b = new Border
            {
                Background = new SolidColorBrush(c),
                BorderBrush = (Brush)FindResource("BgBrush"),
                BorderThickness = new Thickness(1),
                Child = new TextBlock
                {
                    Text = label, Foreground = Brushes.White, FontSize = 11,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    TextTrimming = TextTrimming.CharacterEllipsis
                }
            };
            Grid.SetColumn(b, col++);
            PartitionMap.Children.Add(b);
        }

        foreach (var p in _active.Partitions.OrderBy(p => p.StartingOffset))
        {
            if (p.StartingOffset > covered)
                AddCell("Unused", p.StartingOffset - covered, "Unused");
            AddCell($"{p.TypeLabel}", p.LengthBytes, p.Kind);
            covered = p.StartingOffset + p.LengthBytes;
        }
        if (covered < _active.SizeBytes)
            AddCell("Unused", _active.SizeBytes - covered, "Unused");
    }

    // ---------- navigation ----------
    private void Nav_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && b.Tag is string tag) ShowPage(tag);
    }

    private void ShowPage(string tag)
    {
        PageDisks.Visibility = tag == "Disks" ? Visibility.Visible : Visibility.Collapsed;
        PageSmart.Visibility = tag == "Smart" ? Visibility.Visible : Visibility.Collapsed;
        PageFilesystem.Visibility = tag == "Filesystem" ? Visibility.Visible : Visibility.Collapsed;
        PagePartitions.Visibility = tag == "Partitions" ? Visibility.Visible : Visibility.Collapsed;
        HexView.Visibility = tag == "Hex" ? Visibility.Visible : Visibility.Collapsed;
        PageRecovery.Visibility = tag == "Recovery" ? Visibility.Visible : Visibility.Collapsed;
        PageUsb.Visibility = tag == "Usb" ? Visibility.Visible : Visibility.Collapsed;
        PageTimeline.Visibility = tag == "Timeline" ? Visibility.Visible : Visibility.Collapsed;
        PageLogs.Visibility = tag == "Logs" ? Visibility.Visible : Visibility.Collapsed;
        PageReports.Visibility = tag == "Reports" ? Visibility.Visible : Visibility.Collapsed;

        if (tag == "Smart") LoadSmart();
        if (tag == "Usb") LoadUsb();
        if (tag == "Hex" && _active != null) HexView.GoToLba(2048);
    }

    // ---------- SMART ----------
    private void LoadSmart()
    {
        if (_active == null) return;
        Status("Reading SMART…");
        _active.Smart ??= _smartSvc.ReadSmart(_active);
        SmartCards.Children.Clear();
        var s = _active.Smart;
        if (s == null)
        {
            SmartCards.Children.Add(MakeCard("SMART", "Unavailable", "May be NVMe or virtualized"));
            SmartGrid.ItemsSource = null;
            Status("SMART unavailable for this device.");
            return;
        }
        SmartCards.Children.Add(MakeCard("Temperature", s.TemperatureC?.ToString() ?? "n/a", "°C"));
        SmartCards.Children.Add(MakeCard("Power-On Hours", s.PowerOnHours?.ToString() ?? "n/a", "hours"));
        SmartCards.Children.Add(MakeCard("Power Cycles", s.PowerCycles?.ToString() ?? "n/a", "count"));
        SmartCards.Children.Add(MakeCard("Reallocated", s.ReallocatedSectors?.ToString() ?? "0", "sectors"));
        SmartCards.Children.Add(MakeCard("Pending", s.PendingSectors?.ToString() ?? "0", "sectors"));
        SmartCards.Children.Add(MakeCard("Status", s.OverallStatusOk == true ? "OK" : "Check", ""));
        SmartGrid.ItemsSource = s.Attributes;
        Status("SMART loaded.");
    }

    private Border MakeCard(string title, string value, string unit)
    {
        return new Border
        {
            Width = 150, Margin = new Thickness(0, 0, 12, 12), Padding = new Thickness(14),
            Background = (Brush)FindResource("PanelBrush"), CornerRadius = new CornerRadius(8),
            BorderBrush = (Brush)FindResource("BorderBrush"), BorderThickness = new Thickness(1),
            Child = new StackPanel
            {
                Children =
                {
                    new TextBlock { Text = title, Foreground = (Brush)FindResource("MutedBrush"), FontSize = 12 },
                    new TextBlock { Text = value, FontSize = 24, FontWeight = FontWeights.Bold, Margin = new Thickness(0,4,0,0) },
                    new TextBlock { Text = unit, Foreground = (Brush)FindResource("MutedBrush"), FontSize = 11 }
                }
            }
        };
    }

    // ---------- Filesystem ----------
    private void AnalyzeFs_Click(object sender, RoutedEventArgs e)
    {
        if (_active == null) { Status("Select a disk first."); return; }
        FsResults.Children.Clear();
        using var reader = new RawDiskReader(_active.DeviceNumber, _active.BytesPerSector);
        if (!reader.IsValid) { Status("Raw read failed (run as admin)."); return; }

        // MBR / GPT header
        AddFsRow("Sector 0 (MBR)", _fs.Detect(reader.ReadLba(0)));
        AddFsRow("Sector 1 (GPT header)", _fs.Detect(reader.ReadLba(1)));

        foreach (var p in _active.Partitions)
        {
            byte[] boot = reader.Read(p.StartingOffset, 512);
            AddFsRow($"Partition {p.Index} @ LBA {p.StartLba}", _fs.Detect(boot));
        }
        Status("Filesystem analysis complete.");
    }

    private void AddFsRow(string where, string detected)
    {
        var border = new Border
        {
            Background = (Brush)FindResource("PanelBrush"), CornerRadius = new CornerRadius(6),
            Padding = new Thickness(14), Margin = new Thickness(0, 0, 0, 8),
            Child = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition { Width = new GridLength(300) },
                    new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }
                }
            }
        };
        var g = (Grid)border.Child;
        var k = new TextBlock { Text = where, Foreground = (Brush)FindResource("MutedBrush") };
        var v = new TextBlock
        {
            Text = detected, FontWeight = FontWeights.Bold,
            Foreground = detected == "Unknown" ? (Brush)FindResource("MutedBrush") : (Brush)FindResource("AccentBrush")
        };
        Grid.SetColumn(v, 1);
        g.Children.Add(k); g.Children.Add(v);
        FsResults.Children.Add(border);
    }

    // ---------- Recovery / signature scan ----------
    private void BuildSignatureChecks()
    {
        foreach (var t in _sigTypes)
            SigTypes.Children.Add(new CheckBox
            {
                Content = t, IsChecked = t is "JPEG" or "PNG" or "PDF" or "NTFS",
                Margin = new Thickness(0, 0, 18, 8), Foreground = (Brush)FindResource("TextBrush"),
                Width = 90
            });
    }

    private async void Scan_Click(object sender, RoutedEventArgs e)
    {
        if (_active == null) { Status("Select a disk first."); return; }
        var selected = SigTypes.Children.OfType<CheckBox>()
            .Where(c => c.IsChecked == true).Select(c => (string)c.Content).ToList();
        if (selected.Count == 0) { Status("Select at least one signature type."); return; }

        ScanBtn.IsEnabled = false;
        var progress = new Progress<double>(v => ScanProgress.Value = v);
        var disk = _active;
        Status("Scanning…");
        var hits = await Task.Run(() => _scanner.Scan(
            disk.DeviceNumber, disk.BytesPerSector, disk.SizeBytes,
            selected, progress, CancellationToken.None,
            maxBytes: 2L * 1024 * 1024 * 1024));
        HitsGrid.ItemsSource = hits;
        Status($"Scan complete — {hits.Count} signature hit(s).");
        ScanBtn.IsEnabled = true;
    }

    // ---------- USB ----------
    private void LoadUsb()
    {
        Status("Reading USB descriptors…");
        UsbGrid.ItemsSource = _usbSvc.Enumerate();
        Status("USB enumeration complete.");
    }

    // ---------- Logs ----------
    private async void CollectLogs_Click(object sender, RoutedEventArgs e)
    {
        Status("Collecting event logs…");
        var logs = await Task.Run(() => _logSvc.Collect());
        LogsGrid.ItemsSource = logs;
        Status($"Collected {logs.Count} storage event(s).");
    }

    // ---------- Investigate pipeline ----------
    private async void Investigate_Click(object sender, RoutedEventArgs e)
    {
        if (_active == null) { Status("Select a disk first."); return; }
        InvestigateBtn.IsEnabled = false;
        GlobalProgress.Visibility = Visibility.Visible;
        _timeline.Clear();

        var selected = SigTypes.Children.OfType<CheckBox>()
            .Where(c => c.IsChecked == true).Select(c => (string)c.Content).ToList();
        if (selected.Count == 0) selected = new List<string> { "JPEG", "PNG", "PDF" };

        var progress = new Progress<double>(v => GlobalProgress.Value = v);
        var onEvent = new Action<TimelineEvent>(ev =>
            Dispatcher.Invoke(() => _timeline.Add(ev)));
        var disk = _active;

        Status("Investigating…");
        _lastReport = await Task.Run(() =>
            _investigator.Investigate(disk, selected, onEvent, progress, CancellationToken.None));

        // Refresh dependent views
        DisksList.Items.Refresh();
        RenderDiskInfo();
        RenderPartitionMap();
        if (_lastReport != null)
        {
            ReportPreview.Text = _reporter.ToMarkdown(_lastReport);
            HitsGrid.ItemsSource = _lastReport.Hits;
        }
        Status("Investigation complete. See Reports tab.");
        ShowPage("Reports");
        GlobalProgress.Visibility = Visibility.Collapsed;
        InvestigateBtn.IsEnabled = true;
    }

    // ---------- Exports ----------
    private void ExportHtml_Click(object sender, RoutedEventArgs e) => Export("html");
    private void ExportMd_Click(object sender, RoutedEventArgs e) => Export("md");
    private void ExportPdf_Click(object sender, RoutedEventArgs e) => Export("pdf");

    private void Export(string kind)
    {
        if (_lastReport == null) { Status("Run Investigate first."); return; }
        var dlg = new SaveFileDialog
        {
            FileName = $"CaseReport_Disk{_lastReport.Disk.DeviceNumber}_{DateTime.Now:yyyyMMdd_HHmmss}",
            DefaultExt = kind switch { "html" => ".html", "md" => ".md", _ => ".pdf" },
            Filter = kind switch
            {
                "html" => "HTML (*.html)|*.html",
                "md" => "Markdown (*.md)|*.md",
                _ => "PDF (*.pdf)|*.pdf"
            }
        };
        if (dlg.ShowDialog() != true) return;

        try
        {
            if (kind == "md")
                File.WriteAllText(dlg.FileName, _reporter.ToMarkdown(_lastReport));
            else if (kind == "html")
                File.WriteAllText(dlg.FileName, _reporter.ToHtml(_lastReport));
            else
                ExportPdf(dlg.FileName);
            Status($"Exported: {dlg.FileName}");
        }
        catch (Exception ex) { Status("Export failed: " + ex.Message); }
    }

    private void ExportPdf(string path)
    {
        // Render the HTML report through a FlowDocument -> XPS -> PDF-friendly print path.
        // Simplest portable approach: write HTML alongside and instruct print-to-PDF.
        // Here we produce a basic PDF via the built-in XPS/print pipeline substitute:
        string html = _reporter.ToHtml(_lastReport!);
        string tmpHtml = Path.ChangeExtension(path, ".html");
        File.WriteAllText(tmpHtml, html);
        Status($"HTML written to {tmpHtml}. Use browser 'Print → Save as PDF' for {Path.GetFileName(path)}.");
    }

    private void Status(string msg) => StatusText.Text = msg;
}
