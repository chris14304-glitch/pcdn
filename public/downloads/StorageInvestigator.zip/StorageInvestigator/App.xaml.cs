using System.Windows;

namespace StorageInvestigator;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += (s, args) =>
        {
            MessageBox.Show($"Unexpected error:\n\n{args.Exception.Message}",
                "Storage Investigator", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };
    }
}
