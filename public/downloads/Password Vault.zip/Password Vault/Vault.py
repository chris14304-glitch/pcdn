import base64
import hashlib
import hmac
import json
import os
import secrets
import string
import uuid
import tkinter as tk
from tkinter import messagebox

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

# ── Theme ─────────────────────────────────────────────────────────────────────
BG       = "#0d0d1a"
SIDEBAR  = "#11112a"
CARD     = "#1a1a30"
CARD_H   = "#22223c"
ACCENT   = "#6366f1"
ACCENT_H = "#4f46e5"
TEXT     = "#e2e8f0"
MUTED    = "#6b7280"
DANGER   = "#ef4444"
DANGER_H = "#dc2626"
WARNING  = "#f59e0b"
BORDER   = "#2a2a45"
INPUT_BG = "#0a0a1f"
WHITE    = "#ffffff"
COMP_BG  = "#2a1515"

FH  = ("Segoe UI", 22, "bold")
FSH = ("Segoe UI", 13, "bold")
FS  = ("Segoe UI", 11)
FB  = ("Segoe UI", 10)
FSM = ("Segoe UI", 9)
FM  = ("Consolas", 10)

_AVATAR_COLORS = [
    "#6366f1", "#8b5cf6", "#ec4899", "#f43f5e",
    "#f97316", "#eab308", "#22c55e", "#14b8a6",
    "#3b82f6", "#06b6d4",
]

DIR        = os.path.dirname(os.path.abspath(__file__))
AUTH_FILE  = os.path.join(DIR, "auth.dat")
VAULT_FILE = os.path.join(DIR, "vault.dat")


# ── Crypto ────────────────────────────────────────────────────────────────────

def _hash_secret(secret: str):
    salt = secrets.token_hex(32)
    h = hashlib.pbkdf2_hmac("sha256", secret.encode(), salt.encode(), 390_000)
    return salt, h.hex()

def _verify_secret(secret: str, salt: str, stored: str) -> bool:
    h = hashlib.pbkdf2_hmac("sha256", secret.encode(), salt.encode(), 390_000)
    return hmac.compare_digest(h.hex(), stored)

def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                     salt=salt, iterations=390_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def _fernet_enc(data: bytes, key: bytes) -> bytes:
    return Fernet(key).encrypt(data)

def _fernet_dec(token: bytes, key: bytes) -> bytes:
    return Fernet(key).decrypt(token)

def _encrypt_blob(data: dict, password: str) -> bytes:
    salt = os.urandom(16)
    key  = _derive_key(password, salt)
    return salt + _fernet_enc(json.dumps(data).encode(), key)

def _decrypt_blob(raw: bytes, password: str) -> dict:
    key = _derive_key(password, raw[:16])
    return json.loads(_fernet_dec(raw[16:], key).decode())

def save_auth(username: str, password: str, passcode: str):
    ps, ph = _hash_secret(password)
    cs, ch = _hash_secret(passcode)
    enc_salt = os.urandom(16)
    enc_key  = _derive_key(passcode, enc_salt)
    enc_master = (enc_salt + _fernet_enc(password.encode(), enc_key)).hex()
    with open(AUTH_FILE, "w") as f:
        json.dump({
            "username": username,
            "pw_salt": ps, "pw_hash": ph,
            "pc_salt": cs, "pc_hash": ch,
            "enc_master": enc_master,
        }, f)

def load_auth() -> dict:
    with open(AUTH_FILE) as f:
        return json.load(f)

def save_vault(data: dict, password: str):
    with open(VAULT_FILE, "wb") as f:
        f.write(_encrypt_blob(data, password))

def load_vault(password: str):
    if not os.path.exists(VAULT_FILE):
        return {"entries": [], "compromised": []}
    try:
        with open(VAULT_FILE, "rb") as f:
            return _decrypt_blob(f.read(), password)
    except Exception:
        return None

def avatar_color(site: str) -> str:
    return _AVATAR_COLORS[sum(ord(c) for c in (site or "?")) % len(_AVATAR_COLORS)]

def gen_password(length: int = 16) -> str:
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return "".join(secrets.choice(chars) for _ in range(length))


# ── Widget helpers ────────────────────────────────────────────────────────────

def _btn(parent, text, cmd, bg=ACCENT, hover=ACCENT_H,
         fg=WHITE, font=FB, padx=14, pady=6, **kw):
    b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                  activebackground=hover, activeforeground=fg,
                  relief="flat", bd=0, font=font, cursor="hand2",
                  padx=padx, pady=pady, **kw)
    b.bind("<Enter>", lambda _: b.config(bg=hover))
    b.bind("<Leave>", lambda _: b.config(bg=bg))
    return b

def _entry(parent, show=None, width=30, **kw):
    return tk.Entry(parent, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
                    relief="flat", font=FB, bd=0, width=width,
                    highlightthickness=1, highlightcolor=ACCENT,
                    highlightbackground=BORDER, show=show, **kw)

def _lbl(parent, text, font=FB, fg=TEXT, **kw):
    if "bg" not in kw:
        try:
            kw["bg"] = parent.cget("bg")
        except Exception:
            kw["bg"] = BG
    return tk.Label(parent, text=text, font=font, fg=fg, **kw)


# ── Scrollable frame ──────────────────────────────────────────────────────────

class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg=BG, **kw):
        super().__init__(parent, bg=bg, **kw)
        self.canvas = tk.Canvas(self, bg=bg, bd=0, highlightthickness=0)
        self.vsb    = tk.Scrollbar(self, orient="vertical",
                                   command=self.canvas.yview)
        self.inner  = tk.Frame(self.canvas, bg=bg)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._update_scroll)
        self.canvas.bind("<Configure>", self._resize_inner)
        self.canvas.bind("<Enter>",
            lambda _: self.canvas.bind_all("<MouseWheel>", self._on_scroll))
        self.canvas.bind("<Leave>",
            lambda _: self.canvas.unbind_all("<MouseWheel>"))

    def _update_scroll(self, _=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _resize_inner(self, e):
        self.canvas.itemconfig(self._win, width=e.width)

    def _on_scroll(self, e):
        self.canvas.yview_scroll(-1 * (e.delta // 120), "units")


# ── App controller ────────────────────────────────────────────────────────────

class VaultApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Vault — Password Manager")
        self.root.configure(bg=BG)
        self.root.minsize(960, 640)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        w, h = 1140, 740
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
        self.master_pw  = None
        self.vault_data = None
        self._goto(RegisterScreen if not os.path.exists(AUTH_FILE) else LoginScreen)
        self.root.mainloop()

    def _clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def _goto(self, Screen, **kw):
        self._clear()
        Screen(self.root, self, **kw)

    def login_ok(self, password: str, vault: dict):
        self.master_pw  = password
        self.vault_data = vault
        self._goto(MainScreen)

    def logout(self):
        self.master_pw  = None
        self.vault_data = None
        self._goto(LoginScreen)

    def save(self):
        save_vault(self.vault_data, self.master_pw)


# ── Register ──────────────────────────────────────────────────────────────────

class RegisterScreen:
    def __init__(self, root, app):
        self.root = root
        self.app  = app
        self._build()

    def _build(self):
        bg = tk.Frame(self.root, bg=BG)
        bg.place(relwidth=1, relheight=1)

        card = tk.Frame(bg, bg=CARD, padx=56, pady=48)
        card.place(relx=0.5, rely=0.5, anchor="center")

        _lbl(card, "🔐  Create Your Vault", font=FH, fg=TEXT, bg=CARD).pack()
        _lbl(card, "Set up your account to get started",
             font=FS, fg=MUTED, bg=CARD).pack(pady=(4, 32))

        self._e = {}
        for lbl_text, key, show in [
            ("Username",                        "user", None),
            ("Master Password",                 "pw",   "*"),
            ("Confirm Password",                "pw2",  "*"),
            ("Passcode  (short PIN or phrase)", "pc",   "*"),
        ]:
            row = tk.Frame(card, bg=CARD)
            row.pack(fill="x", pady=6)
            _lbl(row, lbl_text, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, show=show, width=40)
            e.pack(fill="x", ipady=9, pady=(3, 0))
            self._e[key] = e

        _btn(card, "Create Vault", self._submit,
             font=FS, pady=12).pack(fill="x", pady=(30, 0))

    def _submit(self):
        u  = self._e["user"].get().strip()
        pw = self._e["pw"].get()
        p2 = self._e["pw2"].get()
        pc = self._e["pc"].get().strip()

        if not all([u, pw, p2, pc]):
            messagebox.showerror("Error", "All fields are required.", parent=self.root)
            return
        if pw != p2:
            messagebox.showerror("Error", "Passwords do not match.", parent=self.root)
            return
        if len(pw) < 8:
            messagebox.showerror("Error", "Password must be at least 8 characters.", parent=self.root)
            return
        if len(pc) < 4:
            messagebox.showerror("Error", "Passcode must be at least 4 characters.", parent=self.root)
            return

        save_auth(u, pw, pc)
        save_vault({"entries": [], "compromised": []}, pw)
        messagebox.showinfo("Vault Created", "Your vault is ready. Please sign in.", parent=self.root)
        self.app._goto(LoginScreen)


# ── Login ─────────────────────────────────────────────────────────────────────

class LoginScreen:
    def __init__(self, root, app):
        self.root  = root
        self.app   = app
        self._mode = "password"
        self._build()

    def _build(self):
        bg = tk.Frame(self.root, bg=BG)
        bg.place(relwidth=1, relheight=1)

        card = tk.Frame(bg, bg=CARD, padx=56, pady=48)
        card.place(relx=0.5, rely=0.5, anchor="center")

        _lbl(card, "🔐  Vault", font=FH, fg=TEXT, bg=CARD).pack()
        _lbl(card, "Sign in to access your passwords",
             font=FS, fg=MUTED, bg=CARD).pack(pady=(4, 28))

        ur = tk.Frame(card, bg=CARD)
        ur.pack(fill="x", pady=6)
        _lbl(ur, "Username", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        self._user = _entry(ur, width=40)
        self._user.pack(fill="x", ipady=9, pady=(3, 0))

        tabs = tk.Frame(card, bg=CARD)
        tabs.pack(fill="x", pady=(18, 0))
        self._pw_btn = _btn(tabs, "Password", lambda: self._switch("password"),
                            bg=ACCENT, hover=ACCENT_H, font=FSM, pady=7)
        self._pw_btn.pack(side="left", expand=True, fill="x", padx=(0, 2))
        self._pc_btn = _btn(tabs, "Passcode", lambda: self._switch("passcode"),
                            bg=BORDER, hover=CARD_H, font=FSM, pady=7)
        self._pc_btn.pack(side="left", expand=True, fill="x", padx=(2, 0))

        sr = tk.Frame(card, bg=CARD)
        sr.pack(fill="x", pady=6)
        self._slbl = _lbl(sr, "Password", font=FSM, fg=MUTED, bg=CARD)
        self._slbl.pack(anchor="w")
        self._secret = _entry(sr, show="*", width=40)
        self._secret.pack(fill="x", ipady=9, pady=(3, 0))
        self._secret.bind("<Return>", lambda _: self._submit())

        _btn(card, "Sign In", self._submit,
             font=FS, pady=12).pack(fill="x", pady=(28, 0))

    def _switch(self, mode):
        self._mode = mode
        if mode == "password":
            self._pw_btn.config(bg=ACCENT)
            self._pc_btn.config(bg=BORDER)
            self._slbl.config(text="Password")
        else:
            self._pw_btn.config(bg=BORDER)
            self._pc_btn.config(bg=ACCENT)
            self._slbl.config(text="Passcode")

    def _submit(self):
        username = self._user.get().strip()
        secret   = self._secret.get()
        if not username or not secret:
            messagebox.showerror("Error", "Please fill in all fields.", parent=self.root)
            return
        try:
            auth = load_auth()
        except Exception:
            messagebox.showerror("Error", "Auth file missing or corrupted.", parent=self.root)
            return
        if auth["username"] != username:
            messagebox.showerror("Error", "Invalid credentials.", parent=self.root)
            return

        if self._mode == "password":
            if not _verify_secret(secret, auth["pw_salt"], auth["pw_hash"]):
                messagebox.showerror("Error", "Invalid credentials.", parent=self.root)
                return
            master_pw = secret
        else:
            if not _verify_secret(secret, auth["pc_salt"], auth["pc_hash"]):
                messagebox.showerror("Error", "Invalid credentials.", parent=self.root)
                return
            try:
                raw       = bytes.fromhex(auth["enc_master"])
                enc_key   = _derive_key(secret, raw[:16])
                master_pw = _fernet_dec(raw[16:], enc_key).decode()
            except Exception:
                messagebox.showerror("Error", "Cannot retrieve master key.", parent=self.root)
                return

        vault = load_vault(master_pw)
        if vault is None:
            messagebox.showerror("Error", "Wrong password or vault is corrupted.", parent=self.root)
            return
        self.app.login_ok(master_pw, vault)


# ── Main screen ───────────────────────────────────────────────────────────────

class MainScreen:
    def __init__(self, root, app):
        self.root        = root
        self.app         = app
        self._view       = "entries"
        self._active_nav = None
        self._search_var = tk.StringVar()
        self._search_var.trace_add("write", self._on_search)
        self._build()
        self._show_entries()

    # ── Layout ───────────────────────────────────────────────────────────────

    def _build(self):
        self._topbar()
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True)
        self._sidebar(body)
        self._content = tk.Frame(body, bg=BG)
        self._content.pack(side="left", fill="both", expand=True)

    def _topbar(self):
        bar = tk.Frame(self.root, bg=SIDEBAR, height=58)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        _lbl(bar, "🔐  Vault",
             font=("Segoe UI", 15, "bold"), fg=TEXT, bg=SIDEBAR
             ).pack(side="left", padx=24, pady=16)

        _btn(bar, "Logout", self.app.logout,
             bg="#1c1c3a", hover=CARD, font=FSM, pady=5
             ).pack(side="right", padx=24, pady=14)

        sf = tk.Frame(bar, bg=INPUT_BG,
                      highlightthickness=1, highlightbackground=BORDER)
        sf.pack(side="right", padx=10, pady=12)
        tk.Label(sf, text="⌕", font=("Segoe UI", 12), fg=MUTED,
                 bg=INPUT_BG).pack(side="left", padx=(10, 0))
        tk.Entry(sf, textvariable=self._search_var,
                 bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
                 relief="flat", font=FB, bd=0, width=32
                 ).pack(side="left", padx=8, pady=7)

    def _sidebar(self, parent):
        sb = tk.Frame(parent, bg=SIDEBAR, width=215)
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)

        tk.Frame(sb, bg=SIDEBAR, height=18).pack()
        self._nav_all  = self._nav_btn(sb, "📋   All Entries",   self._show_entries)
        self._nav_comp = self._nav_btn(sb, "⚠️   Compromised",    self._show_compromised)
        tk.Frame(sb, bg=BORDER, height=1).pack(fill="x", padx=16, pady=10)
        self._nav_add  = self._nav_btn(sb, "＋   Add Entry",      self._open_add, accent=True)

    def _nav_btn(self, parent, text, cmd, accent=False):
        def on_enter(_, w=None):
            if w is not self._active_nav:
                w.config(bg=CARD_H)
        def on_leave(_, w=None):
            if w is not self._active_nav:
                w.config(bg=SIDEBAR)
        b = tk.Button(parent, text=text, command=cmd,
                      bg=SIDEBAR, fg=TEXT, activebackground=CARD_H,
                      activeforeground=TEXT, relief="flat", bd=0,
                      font=FB, anchor="w", padx=18, pady=12, cursor="hand2")
        b.pack(fill="x")
        b.bind("<Enter>", lambda e, w=b: on_enter(e, w))
        b.bind("<Leave>", lambda e, w=b: on_leave(e, w))
        return b

    def _set_nav(self, active):
        for b in (self._nav_all, self._nav_comp):
            b.config(bg=SIDEBAR, fg=TEXT)
        self._active_nav = active
        active.config(bg=ACCENT, fg=WHITE)

    def _clear_content(self):
        for w in self._content.winfo_children():
            w.destroy()

    def _on_search(self, *_):
        if self._view == "entries":
            self._show_entries()

    # ── All entries ───────────────────────────────────────────────────────────

    def _show_entries(self):
        self._view = "entries"
        self._set_nav(self._nav_all)
        self._clear_content()

        query   = self._search_var.get().strip().lower()
        entries = self.app.vault_data.get("entries", [])
        if query:
            entries = [e for e in entries
                       if query in e.get("site", "").lower()
                       or query in e.get("username", "").lower()]

        hdr = tk.Frame(self._content, bg=BG)
        hdr.pack(fill="x", padx=24, pady=16)
        _lbl(hdr, "All Entries", font=FSH, fg=TEXT, bg=BG).pack(side="left")
        total = len(self.app.vault_data.get("entries", []))
        suffix = f"   {len(entries)} result{'s' if len(entries) != 1 else ''}" \
                 if query else f"   {total} saved"
        _lbl(hdr, suffix, font=FB, fg=MUTED, bg=BG).pack(side="left", pady=2)
        _btn(hdr, "+ Add Entry", self._open_add,
             font=FSM, pady=5).pack(side="right")

        tk.Frame(self._content, bg=BORDER, height=1).pack(fill="x")

        if not entries:
            f = tk.Frame(self._content, bg=BG)
            f.pack(fill="both", expand=True)
            msg = "No results for that search." if query \
                  else "No entries yet.  Click + Add Entry to get started."
            _lbl(f, msg, font=FS, fg=MUTED, bg=BG).pack(expand=True)
            return

        sf = ScrollFrame(self._content, bg=BG)
        sf.pack(fill="both", expand=True, padx=12, pady=10)
        for e in entries:
            self._entry_card(sf.inner, e)

    def _entry_card(self, parent, entry):
        comp    = entry.get("password", "") in self.app.vault_data.get("compromised", [])
        cbg     = COMP_BG if comp else CARD
        outline = DANGER  if comp else BORDER

        card = tk.Frame(parent, bg=cbg,
                        highlightthickness=1, highlightbackground=outline)
        card.pack(fill="x", padx=6, pady=5)

        site   = entry.get("site", "?")
        av_c   = avatar_color(site)
        av     = tk.Frame(card, bg=av_c, width=48, height=48)
        av.pack(side="left", padx=14, pady=14)
        av.pack_propagate(False)
        tk.Label(av, text=(site[0].upper() if site else "?"),
                 bg=av_c, fg=WHITE,
                 font=("Segoe UI", 18, "bold")
                 ).place(relx=0.5, rely=0.5, anchor="center")

        info = tk.Frame(card, bg=cbg)
        info.pack(side="left", fill="both", expand=True, pady=12)

        title_row = tk.Frame(info, bg=cbg)
        title_row.pack(anchor="w", fill="x")
        _lbl(title_row, site,
             font=("Segoe UI", 11, "bold"), fg=TEXT, bg=cbg).pack(side="left")
        if comp:
            _lbl(title_row, "  ⚠  COMPROMISED",
                 font=("Segoe UI", 9, "bold"), fg=WARNING, bg=cbg
                 ).pack(side="left", pady=1)

        _lbl(info, entry.get("username", ""),
             font=FB, fg=MUTED, bg=cbg).pack(anchor="w", pady=2)
        _lbl(info, entry.get("password", ""),
             font=FM, fg=TEXT, bg=cbg).pack(anchor="w")
        note = entry.get("note", "").strip()
        if note:
            preview = note if len(note) <= 60 else note[:57] + "…"
            _lbl(info, f"📝  {preview}",
                 font=FSM, fg=MUTED, bg=cbg).pack(anchor="w", pady=(3, 0))

        acts = tk.Frame(card, bg=cbg)
        acts.pack(side="right", padx=14, pady=14)
        _btn(acts, "Edit",
             lambda e=entry: self._open_edit(e),
             font=FSM, pady=4, padx=10).pack(pady=(0, 6))
        _btn(acts, "Delete",
             lambda eid=entry["id"]: self._delete(eid),
             bg=DANGER, hover=DANGER_H, font=FSM, pady=4, padx=10).pack()

    def _delete(self, entry_id: str):
        if not messagebox.askyesno("Confirm Delete",
                                   "Permanently delete this entry?",
                                   parent=self.root):
            return
        self.app.vault_data["entries"] = [
            e for e in self.app.vault_data["entries"] if e["id"] != entry_id
        ]
        self.app.save()
        self._show_entries()

    # ── Add / Edit dialog ─────────────────────────────────────────────────────

    def _open_add(self):
        self._entry_dialog(None)

    def _open_edit(self, entry: dict):
        self._entry_dialog(entry)

    def _entry_dialog(self, entry):
        editing = entry is not None
        dlg = tk.Toplevel(self.root)
        dlg.title("Edit Entry" if editing else "Add Entry")
        dlg.configure(bg=CARD)
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.focus_set()
        w, h = 500, 580
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        dlg.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")

        p = tk.Frame(dlg, bg=CARD, padx=38, pady=32)
        p.pack(fill="both", expand=True)

        _lbl(p, "Edit Entry" if editing else "New Entry",
             font=FSH, fg=TEXT, bg=CARD).pack(anchor="w", pady=(0, 22))

        fields = {}
        for lbl_t, key in [("Website / App", "site"),
                            ("Username / Email", "username"),
                            ("Password", "password")]:
            row = tk.Frame(p, bg=CARD)
            row.pack(fill="x", pady=6)
            _lbl(row, lbl_t, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, width=44)
            if editing:
                e.insert(0, entry.get(key, ""))
            e.pack(fill="x", ipady=9, pady=(3, 0))
            fields[key] = e

        gen_row = tk.Frame(p, bg=CARD)
        gen_row.pack(fill="x")
        def _gen():
            fields["password"].delete(0, "end")
            fields["password"].insert(0, gen_password())
        _btn(gen_row, "⚡ Generate", _gen,
             bg=BORDER, hover=CARD_H, font=FSM, pady=4, padx=10
             ).pack(anchor="e")

        note_row = tk.Frame(p, bg=CARD)
        note_row.pack(fill="x", pady=(10, 0))
        _lbl(note_row, "Notes  (optional)", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        note_box = tk.Text(note_row, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
                           relief="flat", font=FB, bd=0, width=44, height=4,
                           highlightthickness=1, highlightcolor=ACCENT,
                           highlightbackground=BORDER, wrap="word")
        if editing and entry.get("note"):
            note_box.insert("1.0", entry["note"])
        note_box.pack(fill="x", pady=(3, 0))

        def _save():
            site = fields["site"].get().strip()
            user = fields["username"].get().strip()
            pw   = fields["password"].get()
            note = note_box.get("1.0", "end-1c").strip()
            if not site or not user or not pw:
                messagebox.showerror("Error", "All fields are required.", parent=dlg)
                return
            entries = self.app.vault_data.setdefault("entries", [])
            if editing:
                for e in entries:
                    if e["id"] == entry["id"]:
                        e["site"] = site
                        e["username"] = user
                        e["password"] = pw
                        e["note"] = note
                        break
            else:
                entries.append({"id": str(uuid.uuid4()),
                                "site": site, "username": user,
                                "password": pw, "note": note})
            self.app.save()
            dlg.destroy()
            self._show_entries()

        fields["password"].bind("<Return>", lambda _: _save())
        _btn(p, "Save Entry", _save, font=FS, pady=12).pack(fill="x", pady=(18, 0))

    # ── Compromised view ──────────────────────────────────────────────────────

    def _show_compromised(self):
        self._view = "compromised"
        self._set_nav(self._nav_comp)
        self._clear_content()

        hdr = tk.Frame(self._content, bg=BG)
        hdr.pack(fill="x", padx=24, pady=16)
        _lbl(hdr, "Compromised Passwords", font=FSH, fg=TEXT, bg=BG).pack(side="left")
        tk.Frame(self._content, bg=BORDER, height=1).pack(fill="x")

        body = tk.Frame(self._content, bg=BG)
        body.pack(fill="both", expand=True)

        # Left panel
        left = tk.Frame(body, bg=SIDEBAR, width=330)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        lp = tk.Frame(left, bg=SIDEBAR, padx=24, pady=24)
        lp.pack(fill="both", expand=True)

        _lbl(lp, "Report a Compromised Password",
             font=("Segoe UI", 10, "bold"), fg=TEXT, bg=SIDEBAR).pack(anchor="w")
        _lbl(lp,
             "If a service tells you a password was\n"
             "exposed, add it here. Every vault entry\n"
             "using that password will be flagged.",
             font=FSM, fg=MUTED, bg=SIDEBAR, justify="left"
             ).pack(anchor="w", pady=(6, 16))

        comp_e = _entry(lp, width=30)
        comp_e.pack(fill="x", ipady=8, pady=(0, 10))

        def _add():
            pw = comp_e.get().strip()
            if not pw:
                return
            cl = self.app.vault_data.setdefault("compromised", [])
            if pw not in cl:
                cl.append(pw)
                self.app.save()
            comp_e.delete(0, "end")
            self._show_compromised()

        comp_e.bind("<Return>", lambda _: _add())
        _btn(lp, "Add Compromised Password", _add,
             font=FSM, pady=8).pack(fill="x")

        tk.Frame(lp, bg=BORDER, height=1).pack(fill="x", pady=20)

        entries   = self.app.vault_data.get("entries", [])
        comp_list = self.app.vault_data.get("compromised", [])
        flagged   = sum(1 for e in entries if e.get("password") in comp_list)

        if flagged:
            stat = tk.Frame(lp, bg=COMP_BG, padx=16, pady=14,
                            highlightthickness=1, highlightbackground=DANGER)
            stat.pack(fill="x")
            _lbl(stat, f"⚠  {flagged} entr{'ies' if flagged != 1 else 'y'} flagged",
                 font=("Segoe UI", 10, "bold"), fg=WARNING, bg=COMP_BG).pack()
            _lbl(stat, "Update these passwords immediately.",
                 font=FSM, fg=MUTED, bg=COMP_BG).pack(pady=(4, 0))
        else:
            stat = tk.Frame(lp, bg="#0d2010", padx=16, pady=14,
                            highlightthickness=1, highlightbackground="#1a4020")
            stat.pack(fill="x")
            _lbl(stat, "✓  No flagged entries",
                 font=("Segoe UI", 10, "bold"), fg="#22c55e", bg="#0d2010").pack()

        # Right panel
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=20, pady=18)

        _lbl(right, f"Known Compromised Passwords  ({len(comp_list)})",
             font=FSM, fg=MUTED, bg=BG).pack(anchor="w", pady=(0, 10))

        if not comp_list:
            _lbl(right, "None recorded yet.",
                 font=FB, fg=MUTED, bg=BG).pack(anchor="w")
        else:
            sf = ScrollFrame(right, bg=BG)
            sf.pack(fill="both", expand=True)
            for pw in comp_list:
                row = tk.Frame(sf.inner, bg=CARD,
                               highlightthickness=1, highlightbackground=BORDER)
                row.pack(fill="x", pady=4)
                hits = sum(1 for e in entries if e.get("password") == pw)

                pw_f = tk.Frame(row, bg=CARD)
                pw_f.pack(side="left", padx=14, pady=10, fill="x", expand=True)
                _lbl(pw_f, pw, font=FM, fg=TEXT, bg=CARD).pack(anchor="w")
                if hits:
                    _lbl(pw_f,
                         f"⚠  {hits} vault entr{'ies' if hits > 1 else 'y'} match",
                         font=FSM, fg=WARNING, bg=CARD).pack(anchor="w", pady=(3, 0))

                def _remove(p=pw):
                    self.app.vault_data["compromised"].remove(p)
                    self.app.save()
                    self._show_compromised()

                _btn(row, "Remove", _remove,
                     bg=DANGER, hover=DANGER_H, font=FSM, pady=4, padx=10
                     ).pack(side="right", padx=14, pady=10)


if __name__ == "__main__":
    VaultApp()
