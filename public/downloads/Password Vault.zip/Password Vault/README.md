# Vault — Password Manager

A local, encrypted password manager with a dark-themed GUI built with Python and Tkinter.

## Features

- **Encrypted storage** — vault data is encrypted with Fernet (AES-128-CBC) using a key derived from your master password via PBKDF2-HMAC-SHA256 (390,000 iterations)
- **Two login methods** — sign in with your master password or a shorter passcode
- **Password generator** — generates secure 16-character passwords using letters, digits, and symbols
- **Compromised password tracker** — flag known-breached passwords; any vault entry using one is highlighted with a warning
- **Search** — filter entries by site name or username in real time
- **Notes** — optional notes field per entry

## Requirements

- Python 3.8+
- `cryptography` library

Install the dependency:

```bash
pip install cryptography
```

## Usage

```bash
python Vault.py
```

On first launch you will be prompted to create an account with a username, master password, and passcode. After that, sign in with either credential.

## Data Files

Both files are created automatically in the same directory as `Vault.py`:

| File | Contents |
|------|----------|
| `auth.dat` | Hashed credentials and encrypted master key (JSON) |
| `vault.dat` | AES-encrypted vault entries (binary) |

**Do not delete these files** — `auth.dat` is required to log in and `vault.dat` holds all your passwords.

## Security Notes

- The master password never leaves your machine; it is hashed with PBKDF2-HMAC-SHA256 and a random 32-byte salt before storage.
- The vault blob is encrypted with a fresh random 16-byte salt on every save, so identical data produces a different ciphertext each time.
- The passcode login recovers the master password from an encrypted copy stored in `auth.dat`; the passcode itself is also hashed separately.
- Passwords are displayed in plain text in the GUI — use the app on a trusted, private machine.
