import base64
import hashlib
import hmac
import json
import os
import secrets
import string
import uuid
import tkinter as tk
from tkinter import messagebox, filedialog
from datetime import datetime

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

# ── Theme ─────────────────────────────────────────────────────────────────────
BG       = "#0d0d1a"
SIDEBAR  = "#11112a"
CARD     = "#1a1a30"
CARD_H   = "#22223c"
ACCENT   = "#6366f1"
ACCENT_H = "#4f46e5"
TEXT     = "#e2e8f0"
MUTED    = "#6b7280"
DANGER   = "#ef4444"
DANGER_H = "#dc2626"
WARNING  = "#f59e0b"
SUCCESS  = "#22c55e"
BORDER   = "#2a2a45"
INPUT_BG = "#0a0a1f"
WHITE    = "#ffffff"

FH  = ("Segoe UI", 22, "bold")
FSH = ("Segoe UI", 13, "bold")
FS  = ("Segoe UI", 11)
FB  = ("Segoe UI", 10)
FSM = ("Segoe UI", 9)
FM  = ("Consolas", 10)

DIR        = os.path.dirname(os.path.abspath(__file__))
AUTH_FILE  = os.path.join(DIR, "auth.dat")
VAULT_FILE = os.path.join(DIR, "vault.dat")


# ── Vault structure ───────────────────────────────────────────────────────────

def _empty_vault() -> dict:
    return {
        "identity":     {"full_name": "", "dob": "", "ssn": "", "notes": ""},
        "accounts":     [],
        "debts":        [],
        "assets":       [],
        "bills":        [],
        "instructions": "",
    }


# ── Crypto ────────────────────────────────────────────────────────────────────

def _hash_secret(secret: str):
    salt = secrets.token_hex(32)
    h = hashlib.pbkdf2_hmac("sha256", secret.encode(), salt.encode(), 390_000)
    return salt, h.hex()

def _verify_secret(secret: str, salt: str, stored: str) -> bool:
    h = hashlib.pbkdf2_hmac("sha256", secret.encode(), salt.encode(), 390_000)
    return hmac.compare_digest(h.hex(), stored)

def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                     salt=salt, iterations=390_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def _fernet_enc(data: bytes, key: bytes) -> bytes:
    return Fernet(key).encrypt(data)

def _fernet_dec(token: bytes, key: bytes) -> bytes:
    return Fernet(key).decrypt(token)

def _encrypt_blob(data: dict, password: str) -> bytes:
    salt = os.urandom(16)
    key  = _derive_key(password, salt)
    return salt + _fernet_enc(json.dumps(data).encode(), key)

def _decrypt_blob(raw: bytes, password: str) -> dict:
    key = _derive_key(password, raw[:16])
    return json.loads(_fernet_dec(raw[16:], key).decode())

def save_auth(username: str, password: str, passcode: str):
    ps, ph = _hash_secret(password)
    cs, ch = _hash_secret(passcode)
    enc_salt = os.urandom(16)
    enc_key  = _derive_key(passcode, enc_salt)
    enc_master = (enc_salt + _fernet_enc(password.encode(), enc_key)).hex()
    with open(AUTH_FILE, "w") as f:
        json.dump({
            "username": username,
            "pw_salt": ps, "pw_hash": ph,
            "pc_salt": cs, "pc_hash": ch,
            "enc_master": enc_master,
        }, f)

def load_auth() -> dict:
    with open(AUTH_FILE) as f:
        return json.load(f)

def save_vault(data: dict, password: str):
    with open(VAULT_FILE, "wb") as f:
        f.write(_encrypt_blob(data, password))

def load_vault(password: str):
    if not os.path.exists(VAULT_FILE):
        return _empty_vault()
    try:
        with open(VAULT_FILE, "rb") as f:
            data = _decrypt_blob(f.read(), password)
        # Migrate old password-manager format
        if "entries" in data and "accounts" not in data:
            migrated = _empty_vault()
            for e in data.get("entries", []):
                migrated["accounts"].append({
                    "id":             e.get("id", str(uuid.uuid4())),
                    "type":           "online",
                    "institution":    e.get("site", ""),
                    "username":       e.get("username", ""),
                    "password":       e.get("password", ""),
                    "account_number": "",
                    "notes":          e.get("note", ""),
                })
            return migrated
        return data
    except Exception:
        return None

def gen_password(length: int = 16) -> str:
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return "".join(secrets.choice(chars) for _ in range(length))

def export_vault_txt(vault: dict, path: str, mask_passwords: bool = True):
    lines = [
        "=" * 62,
        "  DIGITAL ESTATE VAULT",
        f"  Exported: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "=" * 62, "",
    ]

    ident = vault.get("identity", {})
    lines += [
        "─── IDENTITY " + "─" * 49,
        f"  Full Name    : {ident.get('full_name', '')}",
        f"  Date of Birth: {ident.get('dob', '')}",
        f"  SSN          : {ident.get('ssn', '')}",
        f"  Notes        : {ident.get('notes', '')}",
        "",
    ]

    accounts = vault.get("accounts", [])
    lines += [f"─── ACCOUNTS ({len(accounts)}) " + "─" * 44]
    for a in accounts:
        pw = ("●" * 8) if mask_passwords else a.get("password", "")
        lines += [
            f"  Type          : {a.get('type', '')}",
            f"  Institution   : {a.get('institution', '')}",
            f"  Username      : {a.get('username', '')}",
            f"  Password      : {pw}",
            f"  Account #     : {a.get('account_number', '')}",
            f"  Notes         : {a.get('notes', '')}",
            "  " + "·" * 44,
        ]
    lines.append("")

    debts = vault.get("debts", [])
    lines += [f"─── DEBTS ({len(debts)}) " + "─" * 47]
    for d in debts:
        lines += [
            f"  Type          : {d.get('type', '')}",
            f"  Provider      : {d.get('provider', '')}",
            f"  Account #     : {d.get('account_number', '')}",
            f"  Balance       : {d.get('balance', '')}",
            f"  Monthly Pymt  : {d.get('monthly_payment', '')}",
            f"  Notes         : {d.get('notes', '')}",
            "  " + "·" * 44,
        ]
    lines.append("")

    assets = vault.get("assets", [])
    lines += [f"─── ASSETS ({len(assets)}) " + "─" * 46]
    for a in assets:
        lines += [
            f"  Type          : {a.get('type', '')}",
            f"  Description   : {a.get('description', '')}",
            f"  Value         : {a.get('value', '')}",
            f"  Location      : {a.get('location', '')}",
            f"  Notes         : {a.get('notes', '')}",
            "  " + "·" * 44,
        ]
    lines.append("")

    bills = vault.get("bills", [])
    lines += [f"─── BILLS ({len(bills)}) " + "─" * 47]
    for b in bills:
        lines += [
            f"  Name          : {b.get('name', '')}",
            f"  Amount        : {b.get('amount', '')}",
            f"  Due Date      : {b.get('due_date', '')}",
            f"  Frequency     : {b.get('frequency', '')}",
            f"  Auto-Pay      : {b.get('auto_pay', '')}",
            f"  Notes         : {b.get('notes', '')}",
            "  " + "·" * 44,
        ]
    lines.append("")

    lines += [
        "─── INSTRUCTIONS " + "─" * 45,
        vault.get("instructions", ""),
        "",
        "=" * 62,
        "  END OF ESTATE VAULT",
        "=" * 62,
    ]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# ── Widget helpers ────────────────────────────────────────────────────────────

def _btn(parent, text, cmd, bg=ACCENT, hover=ACCENT_H,
         fg=WHITE, font=FB, padx=14, pady=6, **kw):
    b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                  activebackground=hover, activeforeground=fg,
                  relief="flat", bd=0, font=font, cursor="hand2",
                  padx=padx, pady=pady, **kw)
    b.bind("<Enter>", lambda _: b.config(bg=hover))
    b.bind("<Leave>", lambda _: b.config(bg=bg))
    return b

def _entry(parent, show=None, width=30, **kw):
    return tk.Entry(parent, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
                    relief="flat", font=FB, bd=0, width=width,
                    highlightthickness=1, highlightcolor=ACCENT,
                    highlightbackground=BORDER, show=show, **kw)

def _lbl(parent, text, font=FB, fg=TEXT, **kw):
    if "bg" not in kw:
        try:
            kw["bg"] = parent.cget("bg")
        except Exception:
            kw["bg"] = BG
    return tk.Label(parent, text=text, font=font, fg=fg, **kw)

def _textbox(parent, height=4, width=44, **kw):
    return tk.Text(parent, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
                   relief="flat", font=FB, bd=0, width=width, height=height,
                   highlightthickness=1, highlightcolor=ACCENT,
                   highlightbackground=BORDER, wrap="word", **kw)


# ── Scrollable frame ──────────────────────────────────────────────────────────

class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg=BG, **kw):
        super().__init__(parent, bg=bg, **kw)
        self.canvas = tk.Canvas(self, bg=bg, bd=0, highlightthickness=0)
        self.vsb    = tk.Scrollbar(self, orient="vertical",
                                   command=self.canvas.yview)
        self.inner  = tk.Frame(self.canvas, bg=bg)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._update_scroll)
        self.canvas.bind("<Configure>", self._resize_inner)
        self.canvas.bind("<Enter>",
            lambda _: self.canvas.bind_all("<MouseWheel>", self._on_scroll))
        self.canvas.bind("<Leave>",
            lambda _: self.canvas.unbind_all("<MouseWheel>"))

    def _update_scroll(self, _=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _resize_inner(self, e):
        self.canvas.itemconfig(self._win, width=e.width)

    def _on_scroll(self, e):
        self.canvas.yview_scroll(-1 * (e.delta // 120), "units")


# ── App controller ────────────────────────────────────────────────────────────

class VaultApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Estate Vault")
        self.root.configure(bg=BG)
        self.root.minsize(980, 660)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        w, h = 1200, 780
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
        self.master_pw  = None
        self.vault_data = None
        self._goto(RegisterScreen if not os.path.exists(AUTH_FILE) else LoginScreen)
        self.root.mainloop()

    def _clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def _goto(self, Screen, **kw):
        self._clear()
        Screen(self.root, self, **kw)

    def login_ok(self, password: str, vault: dict):
        self.master_pw  = password
        self.vault_data = vault
        self._goto(MainScreen)

    def logout(self):
        self.master_pw  = None
        self.vault_data = None
        self._goto(LoginScreen)

    def save(self):
        save_vault(self.vault_data, self.master_pw)


# ── Register ──────────────────────────────────────────────────────────────────

class RegisterScreen:
    def __init__(self, root, app):
        self.root = root
        self.app  = app
        self._build()

    def _build(self):
        bg = tk.Frame(self.root, bg=BG)
        bg.place(relwidth=1, relheight=1)

        card = tk.Frame(bg, bg=CARD, padx=56, pady=48)
        card.place(relx=0.5, rely=0.5, anchor="center")

        _lbl(card, "🏛  Create Your Estate Vault", font=FH, fg=TEXT, bg=CARD).pack()
        _lbl(card, "Secure your digital legacy for those you trust",
             font=FS, fg=MUTED, bg=CARD).pack(pady=(4, 32))

        self._e = {}
        for lbl_text, key, show in [
            ("Username",                        "user", None),
            ("Master Password",                 "pw",   "*"),
            ("Confirm Password",                "pw2",  "*"),
            ("Passcode  (short PIN or phrase)", "pc",   "*"),
        ]:
            row = tk.Frame(card, bg=CARD)
            row.pack(fill="x", pady=6)
            _lbl(row, lbl_text, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, show=show, width=40)
            e.pack(fill="x", ipady=9, pady=(3, 0))
            self._e[key] = e

        _btn(card, "Create Vault", self._submit,
             font=FS, pady=12).pack(fill="x", pady=(30, 0))

    def _submit(self):
        u  = self._e["user"].get().strip()
        pw = self._e["pw"].get()
        p2 = self._e["pw2"].get()
        pc = self._e["pc"].get().strip()

        if not all([u, pw, p2, pc]):
            messagebox.showerror("Error", "All fields are required.", parent=self.root)
            return
        if pw != p2:
            messagebox.showerror("Error", "Passwords do not match.", parent=self.root)
            return
        if len(pw) < 8:
            messagebox.showerror("Error", "Password must be at least 8 characters.", parent=self.root)
            return
        if len(pc) < 4:
            messagebox.showerror("Error", "Passcode must be at least 4 characters.", parent=self.root)
            return

        save_auth(u, pw, pc)
        save_vault(_empty_vault(), pw)
        messagebox.showinfo("Vault Created",
                            "Your estate vault is ready. Please sign in.",
                            parent=self.root)
        self.app._goto(LoginScreen)


# ── Login ─────────────────────────────────────────────────────────────────────

class LoginScreen:
    def __init__(self, root, app):
        self.root  = root
        self.app   = app
        self._mode = "password"
        self._build()

    def _build(self):
        bg = tk.Frame(self.root, bg=BG)
        bg.place(relwidth=1, relheight=1)

        card = tk.Frame(bg, bg=CARD, padx=56, pady=48)
        card.place(relx=0.5, rely=0.5, anchor="center")

        _lbl(card, "🏛  Estate Vault", font=FH, fg=TEXT, bg=CARD).pack()
        _lbl(card, "Sign in to access your estate records",
             font=FS, fg=MUTED, bg=CARD).pack(pady=(4, 28))

        ur = tk.Frame(card, bg=CARD)
        ur.pack(fill="x", pady=6)
        _lbl(ur, "Username", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        self._user = _entry(ur, width=40)
        self._user.pack(fill="x", ipady=9, pady=(3, 0))

        tabs = tk.Frame(card, bg=CARD)
        tabs.pack(fill="x", pady=(18, 0))
        self._pw_btn = _btn(tabs, "Password", lambda: self._switch("password"),
                            bg=ACCENT, hover=ACCENT_H, font=FSM, pady=7)
        self._pw_btn.pack(side="left", expand=True, fill="x", padx=(0, 2))
        self._pc_btn = _btn(tabs, "Passcode", lambda: self._switch("passcode"),
                            bg=BORDER, hover=CARD_H, font=FSM, pady=7)
        self._pc_btn.pack(side="left", expand=True, fill="x", padx=(2, 0))

        sr = tk.Frame(card, bg=CARD)
        sr.pack(fill="x", pady=6)
        self._slbl = _lbl(sr, "Password", font=FSM, fg=MUTED, bg=CARD)
        self._slbl.pack(anchor="w")
        self._secret = _entry(sr, show="*", width=40)
        self._secret.pack(fill="x", ipady=9, pady=(3, 0))
        self._secret.bind("<Return>", lambda _: self._submit())

        _btn(card, "Sign In", self._submit,
             font=FS, pady=12).pack(fill="x", pady=(28, 0))

    def _switch(self, mode):
        self._mode = mode
        if mode == "password":
            self._pw_btn.config(bg=ACCENT)
            self._pc_btn.config(bg=BORDER)
            self._slbl.config(text="Password")
        else:
            self._pw_btn.config(bg=BORDER)
            self._pc_btn.config(bg=ACCENT)
            self._slbl.config(text="Passcode")

    def _submit(self):
        username = self._user.get().strip()
        secret   = self._secret.get()
        if not username or not secret:
            messagebox.showerror("Error", "Please fill in all fields.", parent=self.root)
            return
        try:
            auth = load_auth()
        except Exception:
            messagebox.showerror("Error", "Auth file missing or corrupted.", parent=self.root)
            return
        if auth["username"] != username:
            messagebox.showerror("Error", "Invalid credentials.", parent=self.root)
            return

        if self._mode == "password":
            if not _verify_secret(secret, auth["pw_salt"], auth["pw_hash"]):
                messagebox.showerror("Error", "Invalid credentials.", parent=self.root)
                return
            master_pw = secret
        else:
            if not _verify_secret(secret, auth["pc_salt"], auth["pc_hash"]):
                messagebox.showerror("Error", "Invalid credentials.", parent=self.root)
                return
            try:
                raw       = bytes.fromhex(auth["enc_master"])
                enc_key   = _derive_key(secret, raw[:16])
                master_pw = _fernet_dec(raw[16:], enc_key).decode()
            except Exception:
                messagebox.showerror("Error", "Cannot retrieve master key.", parent=self.root)
                return

        vault = load_vault(master_pw)
        if vault is None:
            messagebox.showerror("Error", "Wrong password or vault is corrupted.", parent=self.root)
            return
        self.app.login_ok(master_pw, vault)


# ── Main screen ───────────────────────────────────────────────────────────────

class MainScreen:
    def __init__(self, root, app):
        self.root        = root
        self.app         = app
        self._view       = None
        self._active_nav = None
        self._search_var = tk.StringVar()
        self._search_var.trace_add("write", self._on_search)
        self._build()
        self._show_overview()

    # ── Layout ───────────────────────────────────────────────────────────────

    def _build(self):
        self._topbar()
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True)
        self._sidebar(body)
        self._content = tk.Frame(body, bg=BG)
        self._content.pack(side="left", fill="both", expand=True)

    def _topbar(self):
        bar = tk.Frame(self.root, bg=SIDEBAR, height=58)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        _lbl(bar, "🏛  Estate Vault",
             font=("Segoe UI", 15, "bold"), fg=TEXT, bg=SIDEBAR
             ).pack(side="left", padx=24, pady=16)

        _btn(bar, "Logout", self.app.logout,
             bg="#1c1c3a", hover=CARD, font=FSM, pady=5
             ).pack(side="right", padx=24, pady=14)

        sf = tk.Frame(bar, bg=INPUT_BG,
                      highlightthickness=1, highlightbackground=BORDER)
        sf.pack(side="right", padx=10, pady=12)
        tk.Label(sf, text="⌕", font=("Segoe UI", 12), fg=MUTED,
                 bg=INPUT_BG).pack(side="left", padx=(10, 0))
        tk.Entry(sf, textvariable=self._search_var,
                 bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
                 relief="flat", font=FB, bd=0, width=28
                 ).pack(side="left", padx=8, pady=7)

    def _sidebar(self, parent):
        sb = tk.Frame(parent, bg=SIDEBAR, width=225)
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)

        tk.Frame(sb, bg=SIDEBAR, height=18).pack()

        self._nav_overview     = self._nav_btn(sb, "📊   Overview",      self._show_overview)
        self._nav_identity     = self._nav_btn(sb, "👤   Identity",       self._show_identity)
        self._nav_accounts     = self._nav_btn(sb, "🏦   Accounts",       self._show_accounts)
        self._nav_debts        = self._nav_btn(sb, "💳   Debts",          self._show_debts)
        self._nav_assets       = self._nav_btn(sb, "🏠   Assets",         self._show_assets)
        self._nav_bills        = self._nav_btn(sb, "📄   Bills",          self._show_bills)
        self._nav_instructions = self._nav_btn(sb, "📝   Instructions",   self._show_instructions)

        tk.Frame(sb, bg=BORDER, height=1).pack(fill="x", padx=16, pady=14)

        _btn(sb, "📤  Export Vault", self._do_export,
             bg="#162616", hover="#1e3a1e", font=FSM, pady=10
             ).pack(fill="x", padx=12)

    def _nav_btn(self, parent, text, cmd):
        def on_enter(_, w=None):
            if w is not self._active_nav:
                w.config(bg=CARD_H)
        def on_leave(_, w=None):
            if w is not self._active_nav:
                w.config(bg=SIDEBAR)
        b = tk.Button(parent, text=text, command=cmd,
                      bg=SIDEBAR, fg=TEXT, activebackground=CARD_H,
                      activeforeground=TEXT, relief="flat", bd=0,
                      font=FB, anchor="w", padx=18, pady=12, cursor="hand2")
        b.pack(fill="x")
        b.bind("<Enter>", lambda e, w=b: on_enter(e, w))
        b.bind("<Leave>", lambda e, w=b: on_leave(e, w))
        return b

    def _all_navs(self):
        return [self._nav_overview, self._nav_identity, self._nav_accounts,
                self._nav_debts, self._nav_assets, self._nav_bills,
                self._nav_instructions]

    def _set_nav(self, active):
        for b in self._all_navs():
            b.config(bg=SIDEBAR, fg=TEXT)
        self._active_nav = active
        active.config(bg=ACCENT, fg=WHITE)

    def _clear_content(self):
        for w in self._content.winfo_children():
            w.destroy()

    def _on_search(self, *_):
        if self._view in ("accounts", "debts", "assets", "bills"):
            getattr(self, f"_show_{self._view}")()

    # ── Shared UI helpers ─────────────────────────────────────────────────────

    def _section_header(self, title, count="", btn_text="", btn_cmd=None):
        hdr = tk.Frame(self._content, bg=BG)
        hdr.pack(fill="x", padx=24, pady=16)
        _lbl(hdr, title, font=FSH, fg=TEXT, bg=BG).pack(side="left")
        if count:
            _lbl(hdr, f"   {count}", font=FB, fg=MUTED, bg=BG).pack(side="left", pady=2)
        if btn_text and btn_cmd:
            _btn(hdr, btn_text, btn_cmd, font=FSM, pady=5).pack(side="right")
        tk.Frame(self._content, bg=BORDER, height=1).pack(fill="x")

    def _empty_state(self, msg):
        f = tk.Frame(self._content, bg=BG)
        f.pack(fill="both", expand=True)
        _lbl(f, msg, font=FS, fg=MUTED, bg=BG).pack(expand=True)

    def _make_dialog(self, title, w, h) -> tk.Toplevel:
        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.configure(bg=CARD)
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()
        dlg.focus_set()
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        dlg.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
        return dlg

    def _delete_item(self, key, item_id, refresh_fn):
        if not messagebox.askyesno("Confirm Delete",
                                   "Permanently delete this item?",
                                   parent=self.root):
            return
        self.app.vault_data[key] = [
            i for i in self.app.vault_data[key] if i["id"] != item_id
        ]
        self.app.save()
        refresh_fn()

    def _list_view(self, key, nav_btn, title, add_fn, card_fn):
        self._view = key
        self._set_nav(nav_btn)
        self._clear_content()

        query = self._search_var.get().strip().lower()
        items = self.app.vault_data.get(key, [])
        total = len(items)
        if query:
            items = [i for i in items if query in json.dumps(i).lower()]
        suffix = (f"{len(items)} result{'s' if len(items) != 1 else ''}"
                  if query else f"{total} saved")

        self._section_header(title, suffix, "+ Add", add_fn)

        if not items:
            msg = "No results." if query else f"No {title.lower()} yet — click + Add to get started."
            self._empty_state(msg)
            return

        sf = ScrollFrame(self._content, bg=BG)
        sf.pack(fill="both", expand=True, padx=12, pady=10)
        for item in items:
            card_fn(sf.inner, item)

    # ── Overview ──────────────────────────────────────────────────────────────

    def _show_overview(self):
        self._view = "overview"
        self._set_nav(self._nav_overview)
        self._clear_content()

        sf = ScrollFrame(self._content, bg=BG)
        sf.pack(fill="both", expand=True, padx=24, pady=20)
        p = sf.inner

        _lbl(p, "Estate Overview", font=FSH, fg=TEXT, bg=BG).pack(anchor="w")
        _lbl(p, "A snapshot of your digital estate",
             font=FB, fg=MUTED, bg=BG).pack(anchor="w", pady=(2, 18))

        name = self.app.vault_data.get("identity", {}).get("full_name", "").strip()
        if name:
            _lbl(p, f"👤  {name}",
                 font=("Segoe UI", 12, "bold"), fg=ACCENT, bg=BG
                 ).pack(anchor="w", pady=(0, 14))

        # Stat cards
        row = tk.Frame(p, bg=BG)
        row.pack(fill="x", pady=(0, 22))
        for label, key, icon in [
            ("Accounts", "accounts", "🏦"),
            ("Debts",    "debts",    "💳"),
            ("Assets",   "assets",   "🏠"),
            ("Bills",    "bills",    "📄"),
        ]:
            count = len(self.app.vault_data.get(key, []))
            c = tk.Frame(row, bg=CARD, padx=20, pady=16,
                         highlightthickness=1, highlightbackground=BORDER)
            c.pack(side="left", expand=True, fill="x", padx=(0, 10))
            _lbl(c, icon,      font=("Segoe UI", 20),          fg=ACCENT, bg=CARD).pack()
            _lbl(c, str(count), font=("Segoe UI", 22, "bold"), fg=TEXT,   bg=CARD).pack()
            _lbl(c, label,     font=FSM,                        fg=MUTED,  bg=CARD).pack()

        # Quick previews
        for section, key, go_fn in [
            ("Recent Accounts", "accounts", self._show_accounts),
            ("Recent Bills",    "bills",    self._show_bills),
        ]:
            items = self.app.vault_data.get(key, [])[-3:]
            if not items:
                continue
            hr = tk.Frame(p, bg=BG)
            hr.pack(fill="x", pady=(14, 4))
            _lbl(hr, section, font=("Segoe UI", 10, "bold"), fg=TEXT, bg=BG).pack(side="left")
            _btn(hr, "View All →", go_fn,
                 bg=BORDER, hover=CARD_H, font=FSM, pady=3).pack(side="right")
            tk.Frame(p, bg=BORDER, height=1).pack(fill="x", pady=(0, 6))
            for item in items:
                r = tk.Frame(p, bg=CARD, padx=14, pady=10,
                             highlightthickness=1, highlightbackground=BORDER)
                r.pack(fill="x", pady=3)
                if key == "accounts":
                    _lbl(r, f"{item.get('institution','?')}  ·  {item.get('type','')}",
                         font=FB, fg=TEXT, bg=CARD).pack(anchor="w")
                    _lbl(r, item.get("username", ""),
                         font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
                else:
                    _lbl(r, item.get("name", "?"), font=FB, fg=TEXT, bg=CARD).pack(anchor="w")
                    _lbl(r, f"{item.get('amount','')}  ·  Due {item.get('due_date','')}",
                         font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")

        inst = self.app.vault_data.get("instructions", "").strip()
        if inst:
            tk.Frame(p, bg=BORDER, height=1).pack(fill="x", pady=(18, 8))
            _lbl(p, "📝  Instructions Preview",
                 font=("Segoe UI", 10, "bold"), fg=TEXT, bg=BG).pack(anchor="w")
            preview = inst[:220] + ("…" if len(inst) > 220 else "")
            _lbl(p, preview, font=FSM, fg=MUTED, bg=BG,
                 wraplength=720, justify="left").pack(anchor="w", pady=(4, 0))

    # ── Identity ──────────────────────────────────────────────────────────────

    def _show_identity(self):
        self._view = "identity"
        self._set_nav(self._nav_identity)
        self._clear_content()
        self._section_header("Identity", btn_text="Edit", btn_cmd=self._edit_identity)

        ident = self.app.vault_data.get("identity", {})
        p = tk.Frame(self._content, bg=BG, padx=36, pady=24)
        p.pack(fill="both", expand=True)

        for label, key in [("Full Name", "full_name"),
                            ("Date of Birth", "dob"),
                            ("SSN", "ssn")]:
            row = tk.Frame(p, bg=BG)
            row.pack(fill="x", pady=8)
            _lbl(row, label, font=FSM, fg=MUTED, bg=BG).pack(anchor="w")
            val = ident.get(key, "").strip() or "—"
            _lbl(row, val, font=("Segoe UI", 12), fg=TEXT, bg=BG).pack(anchor="w")
            tk.Frame(p, bg=BORDER, height=1).pack(fill="x")

        notes = ident.get("notes", "").strip()
        if notes:
            tk.Frame(p, bg=BG, height=8).pack()
            _lbl(p, "Notes", font=FSM, fg=MUTED, bg=BG).pack(anchor="w")
            _lbl(p, notes, font=FB, fg=TEXT, bg=BG,
                 wraplength=720, justify="left").pack(anchor="w", pady=(4, 0))

    def _edit_identity(self):
        ident = self.app.vault_data.get("identity", {})
        dlg = self._make_dialog("Edit Identity", 520, 480)
        p   = tk.Frame(dlg, bg=CARD, padx=38, pady=30)
        p.pack(fill="both", expand=True)
        _lbl(p, "Edit Identity", font=FSH, fg=TEXT, bg=CARD).pack(anchor="w", pady=(0, 20))

        fields = {}
        for lbl_t, key in [("Full Name",              "full_name"),
                            ("Date of Birth  (MM/DD/YYYY)", "dob"),
                            ("SSN  (optional)",        "ssn")]:
            row = tk.Frame(p, bg=CARD)
            row.pack(fill="x", pady=6)
            _lbl(row, lbl_t, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, width=44)
            e.insert(0, ident.get(key, ""))
            e.pack(fill="x", ipady=9, pady=(3, 0))
            fields[key] = e

        note_row = tk.Frame(p, bg=CARD)
        note_row.pack(fill="x", pady=(10, 0))
        _lbl(note_row, "Notes  (optional)", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        nb = _textbox(note_row, height=3)
        nb.insert("1.0", ident.get("notes", ""))
        nb.pack(fill="x", pady=(3, 0))

        def _save():
            self.app.vault_data["identity"] = {
                "full_name": fields["full_name"].get().strip(),
                "dob":       fields["dob"].get().strip(),
                "ssn":       fields["ssn"].get().strip(),
                "notes":     nb.get("1.0", "end-1c").strip(),
            }
            self.app.save()
            dlg.destroy()
            self._show_identity()

        _btn(p, "Save", _save, font=FS, pady=12).pack(fill="x", pady=(18, 0))

    # ── Accounts ──────────────────────────────────────────────────────────────

    def _show_accounts(self):
        self._list_view("accounts", self._nav_accounts, "Accounts",
                        self._add_account, self._account_card)

    def _account_card(self, parent, acc):
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x", padx=6, pady=5)

        info = tk.Frame(card, bg=CARD)
        info.pack(side="left", fill="both", expand=True, padx=16, pady=14)

        top = tk.Frame(info, bg=CARD)
        top.pack(anchor="w", fill="x")
        _lbl(top, acc.get("institution", "?"),
             font=("Segoe UI", 11, "bold"), fg=TEXT, bg=CARD).pack(side="left")
        if acc.get("type"):
            _lbl(top, f"  [{acc['type']}]", font=FSM, fg=MUTED, bg=CARD).pack(side="left")

        _lbl(info, f"👤  {acc.get('username', '')}",
             font=FB, fg=MUTED, bg=CARD).pack(anchor="w", pady=(4, 2))
        _lbl(info, "🔑  ●●●●●●●●",
             font=FM, fg=MUTED, bg=CARD).pack(anchor="w")
        if acc.get("notes"):
            prev = acc["notes"][:60] + ("…" if len(acc["notes"]) > 60 else "")
            _lbl(info, f"📝  {prev}", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w", pady=(3, 0))

        acts = tk.Frame(card, bg=CARD)
        acts.pack(side="right", padx=14, pady=14)
        _btn(acts, "Edit",   lambda a=acc: self._account_dialog(a),
             font=FSM, pady=4, padx=10).pack(pady=(0, 6))
        _btn(acts, "Delete", lambda aid=acc["id"]: self._delete_item("accounts", aid, self._show_accounts),
             bg=DANGER, hover=DANGER_H, font=FSM, pady=4, padx=10).pack()

    def _add_account(self):
        self._account_dialog(None)

    def _account_dialog(self, acc):
        editing = acc is not None
        dlg = self._make_dialog("Edit Account" if editing else "Add Account", 540, 610)
        p   = tk.Frame(dlg, bg=CARD, padx=38, pady=28)
        p.pack(fill="both", expand=True)
        _lbl(p, "Edit Account" if editing else "New Account",
             font=FSH, fg=TEXT, bg=CARD).pack(anchor="w", pady=(0, 18))

        fields = {}
        for lbl_t, key in [
            ("Type  (bank, credit card, investment, crypto…)", "type"),
            ("Institution / Name",                             "institution"),
            ("Username / Email",                               "username"),
            ("Password",                                       "password"),
            ("Account Number  (optional)",                     "account_number"),
        ]:
            row = tk.Frame(p, bg=CARD)
            row.pack(fill="x", pady=5)
            _lbl(row, lbl_t, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, width=44)
            if editing:
                e.insert(0, acc.get(key, ""))
            e.pack(fill="x", ipady=8, pady=(3, 0))
            fields[key] = e

        gen_row = tk.Frame(p, bg=CARD)
        gen_row.pack(fill="x")
        def _gen():
            fields["password"].delete(0, "end")
            fields["password"].insert(0, gen_password())
        _btn(gen_row, "⚡ Generate Password", _gen,
             bg=BORDER, hover=CARD_H, font=FSM, pady=4, padx=10).pack(anchor="e")

        note_row = tk.Frame(p, bg=CARD)
        note_row.pack(fill="x", pady=(8, 0))
        _lbl(note_row, "Notes  (optional)", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        nb = _textbox(note_row, height=3)
        if editing and acc.get("notes"):
            nb.insert("1.0", acc["notes"])
        nb.pack(fill="x", pady=(3, 0))

        def _save():
            if not fields["institution"].get().strip():
                messagebox.showerror("Error", "Institution is required.", parent=dlg)
                return
            entry = {k: fields[k].get().strip() for k in fields}
            entry["notes"] = nb.get("1.0", "end-1c").strip()
            accs = self.app.vault_data.setdefault("accounts", [])
            if editing:
                entry["id"] = acc["id"]
                for i, a in enumerate(accs):
                    if a["id"] == acc["id"]:
                        accs[i] = entry
                        break
            else:
                entry["id"] = str(uuid.uuid4())
                accs.append(entry)
            self.app.save()
            dlg.destroy()
            self._show_accounts()

        _btn(p, "Save", _save, font=FS, pady=12).pack(fill="x", pady=(14, 0))

    # ── Debts ─────────────────────────────────────────────────────────────────

    def _show_debts(self):
        self._list_view("debts", self._nav_debts, "Debts",
                        self._add_debt, self._debt_card)

    def _debt_card(self, parent, debt):
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x", padx=6, pady=5)

        info = tk.Frame(card, bg=CARD)
        info.pack(side="left", fill="both", expand=True, padx=16, pady=14)

        top = tk.Frame(info, bg=CARD)
        top.pack(anchor="w", fill="x")
        _lbl(top, debt.get("provider", "?"),
             font=("Segoe UI", 11, "bold"), fg=TEXT, bg=CARD).pack(side="left")
        if debt.get("type"):
            _lbl(top, f"  [{debt['type']}]", font=FSM, fg=MUTED, bg=CARD).pack(side="left")

        if debt.get("balance"):
            _lbl(info, f"💰  Balance: {debt['balance']}",
                 font=FB, fg=WARNING, bg=CARD).pack(anchor="w", pady=(4, 2))
        if debt.get("monthly_payment"):
            _lbl(info, f"📆  Monthly: {debt['monthly_payment']}",
                 font=FB, fg=MUTED, bg=CARD).pack(anchor="w")
        if debt.get("notes"):
            prev = debt["notes"][:60] + ("…" if len(debt["notes"]) > 60 else "")
            _lbl(info, f"📝  {prev}", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w", pady=(3, 0))

        acts = tk.Frame(card, bg=CARD)
        acts.pack(side="right", padx=14, pady=14)
        _btn(acts, "Edit",   lambda d=debt: self._debt_dialog(d),
             font=FSM, pady=4, padx=10).pack(pady=(0, 6))
        _btn(acts, "Delete", lambda did=debt["id"]: self._delete_item("debts", did, self._show_debts),
             bg=DANGER, hover=DANGER_H, font=FSM, pady=4, padx=10).pack()

    def _add_debt(self):
        self._debt_dialog(None)

    def _debt_dialog(self, debt):
        editing = debt is not None
        dlg = self._make_dialog("Edit Debt" if editing else "Add Debt", 520, 620)
        p   = tk.Frame(dlg, bg=CARD, padx=38, pady=28)
        p.pack(fill="both", expand=True)
        _lbl(p, "Edit Debt" if editing else "New Debt",
             font=FSH, fg=TEXT, bg=CARD).pack(anchor="w", pady=(0, 18))

        fields = {}
        for lbl_t, key in [
            ("Type  (mortgage, student loan, auto, medical…)", "type"),
            ("Provider / Lender",                               "provider"),
            ("Account Number  (optional)",                      "account_number"),
            ("Balance",                                         "balance"),
            ("Monthly Payment",                                 "monthly_payment"),
        ]:
            row = tk.Frame(p, bg=CARD)
            row.pack(fill="x", pady=5)
            _lbl(row, lbl_t, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, width=44)
            if editing:
                e.insert(0, debt.get(key, ""))
            e.pack(fill="x", ipady=8, pady=(3, 0))
            fields[key] = e

        note_row = tk.Frame(p, bg=CARD)
        note_row.pack(fill="x", pady=(8, 0))
        _lbl(note_row, "Notes  (optional)", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        nb = _textbox(note_row, height=3)
        if editing and debt.get("notes"):
            nb.insert("1.0", debt["notes"])
        nb.pack(fill="x", pady=(3, 0))

        def _save():
            if not fields["provider"].get().strip():
                messagebox.showerror("Error", "Provider is required.", parent=dlg)
                return
            entry = {k: fields[k].get().strip() for k in fields}
            entry["notes"] = nb.get("1.0", "end-1c").strip()
            debts = self.app.vault_data.setdefault("debts", [])
            if editing:
                entry["id"] = debt["id"]
                for i, d in enumerate(debts):
                    if d["id"] == debt["id"]:
                        debts[i] = entry
                        break
            else:
                entry["id"] = str(uuid.uuid4())
                debts.append(entry)
            self.app.save()
            dlg.destroy()
            self._show_debts()

        _btn(p, "Save", _save, font=FS, pady=12).pack(fill="x", pady=(14, 0))

    # ── Assets ────────────────────────────────────────────────────────────────

    def _show_assets(self):
        self._list_view("assets", self._nav_assets, "Assets",
                        self._add_asset, self._asset_card)

    def _asset_card(self, parent, asset):
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x", padx=6, pady=5)

        info = tk.Frame(card, bg=CARD)
        info.pack(side="left", fill="both", expand=True, padx=16, pady=14)

        top = tk.Frame(info, bg=CARD)
        top.pack(anchor="w", fill="x")
        _lbl(top, asset.get("description", "?"),
             font=("Segoe UI", 11, "bold"), fg=TEXT, bg=CARD).pack(side="left")
        if asset.get("type"):
            _lbl(top, f"  [{asset['type']}]", font=FSM, fg=MUTED, bg=CARD).pack(side="left")

        if asset.get("value"):
            _lbl(info, f"💵  Value: {asset['value']}",
                 font=FB, fg=SUCCESS, bg=CARD).pack(anchor="w", pady=(4, 2))
        if asset.get("location"):
            _lbl(info, f"📍  {asset['location']}",
                 font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        if asset.get("notes"):
            prev = asset["notes"][:60] + ("…" if len(asset["notes"]) > 60 else "")
            _lbl(info, f"📝  {prev}", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w", pady=(3, 0))

        acts = tk.Frame(card, bg=CARD)
        acts.pack(side="right", padx=14, pady=14)
        _btn(acts, "Edit",   lambda a=asset: self._asset_dialog(a),
             font=FSM, pady=4, padx=10).pack(pady=(0, 6))
        _btn(acts, "Delete", lambda aid=asset["id"]: self._delete_item("assets", aid, self._show_assets),
             bg=DANGER, hover=DANGER_H, font=FSM, pady=4, padx=10).pack()

    def _add_asset(self):
        self._asset_dialog(None)

    def _asset_dialog(self, asset):
        editing = asset is not None
        dlg = self._make_dialog("Edit Asset" if editing else "Add Asset", 520, 510)
        p   = tk.Frame(dlg, bg=CARD, padx=38, pady=28)
        p.pack(fill="both", expand=True)
        _lbl(p, "Edit Asset" if editing else "New Asset",
             font=FSH, fg=TEXT, bg=CARD).pack(anchor="w", pady=(0, 18))

        fields = {}
        for lbl_t, key in [
            ("Type  (property, vehicle, investment, jewelry…)", "type"),
            ("Description",                                      "description"),
            ("Estimated Value",                                  "value"),
            ("Location  (optional)",                             "location"),
        ]:
            row = tk.Frame(p, bg=CARD)
            row.pack(fill="x", pady=5)
            _lbl(row, lbl_t, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, width=44)
            if editing:
                e.insert(0, asset.get(key, ""))
            e.pack(fill="x", ipady=8, pady=(3, 0))
            fields[key] = e

        note_row = tk.Frame(p, bg=CARD)
        note_row.pack(fill="x", pady=(8, 0))
        _lbl(note_row, "Notes  (optional)", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        nb = _textbox(note_row, height=3)
        if editing and asset.get("notes"):
            nb.insert("1.0", asset["notes"])
        nb.pack(fill="x", pady=(3, 0))

        def _save():
            if not fields["description"].get().strip():
                messagebox.showerror("Error", "Description is required.", parent=dlg)
                return
            entry = {k: fields[k].get().strip() for k in fields}
            entry["notes"] = nb.get("1.0", "end-1c").strip()
            assets = self.app.vault_data.setdefault("assets", [])
            if editing:
                entry["id"] = asset["id"]
                for i, a in enumerate(assets):
                    if a["id"] == asset["id"]:
                        assets[i] = entry
                        break
            else:
                entry["id"] = str(uuid.uuid4())
                assets.append(entry)
            self.app.save()
            dlg.destroy()
            self._show_assets()

        _btn(p, "Save", _save, font=FS, pady=12).pack(fill="x", pady=(14, 0))

    # ── Bills ─────────────────────────────────────────────────────────────────

    def _show_bills(self):
        self._list_view("bills", self._nav_bills, "Bills",
                        self._add_bill, self._bill_card)

    def _bill_card(self, parent, bill):
        card = tk.Frame(parent, bg=CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x", padx=6, pady=5)

        info = tk.Frame(card, bg=CARD)
        info.pack(side="left", fill="both", expand=True, padx=16, pady=14)

        _lbl(info, bill.get("name", "?"),
             font=("Segoe UI", 11, "bold"), fg=TEXT, bg=CARD).pack(anchor="w")

        row2 = tk.Frame(info, bg=CARD)
        row2.pack(anchor="w", pady=(4, 2))
        if bill.get("amount"):
            _lbl(row2, f"💰  {bill['amount']}", font=FB, fg=TEXT, bg=CARD).pack(side="left", padx=(0, 14))
        if bill.get("due_date"):
            _lbl(row2, f"📅  Due: {bill['due_date']}", font=FB, fg=MUTED, bg=CARD).pack(side="left", padx=(0, 14))
        if bill.get("frequency"):
            _lbl(row2, f"🔄  {bill['frequency']}", font=FSM, fg=MUTED, bg=CARD).pack(side="left")
        if bill.get("auto_pay"):
            _lbl(info, f"✅  Auto-pay: {bill['auto_pay']}",
                 font=FSM, fg=SUCCESS, bg=CARD).pack(anchor="w")
        if bill.get("notes"):
            prev = bill["notes"][:60] + ("…" if len(bill["notes"]) > 60 else "")
            _lbl(info, f"📝  {prev}", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w", pady=(3, 0))

        acts = tk.Frame(card, bg=CARD)
        acts.pack(side="right", padx=14, pady=14)
        _btn(acts, "Edit",   lambda b=bill: self._bill_dialog(b),
             font=FSM, pady=4, padx=10).pack(pady=(0, 6))
        _btn(acts, "Delete", lambda bid=bill["id"]: self._delete_item("bills", bid, self._show_bills),
             bg=DANGER, hover=DANGER_H, font=FSM, pady=4, padx=10).pack()

    def _add_bill(self):
        self._bill_dialog(None)

    def _bill_dialog(self, bill):
        editing = bill is not None
        dlg = self._make_dialog("Edit Bill" if editing else "Add Bill", 520, 620)
        p   = tk.Frame(dlg, bg=CARD, padx=38, pady=28)
        p.pack(fill="both", expand=True)
        _lbl(p, "Edit Bill" if editing else "New Bill",
             font=FSH, fg=TEXT, bg=CARD).pack(anchor="w", pady=(0, 18))

        fields = {}
        for lbl_t, key in [
            ("Bill Name",                              "name"),
            ("Amount",                                 "amount"),
            ("Due Date  (e.g. 15th or 2025-01-15)",   "due_date"),
            ("Frequency  (monthly, annual, etc.)",     "frequency"),
            ("Auto-Pay  (yes / no / bank name)",       "auto_pay"),
        ]:
            row = tk.Frame(p, bg=CARD)
            row.pack(fill="x", pady=5)
            _lbl(row, lbl_t, font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
            e = _entry(row, width=44)
            if editing:
                e.insert(0, bill.get(key, ""))
            e.pack(fill="x", ipady=8, pady=(3, 0))
            fields[key] = e

        note_row = tk.Frame(p, bg=CARD)
        note_row.pack(fill="x", pady=(8, 0))
        _lbl(note_row, "Notes  (optional)", font=FSM, fg=MUTED, bg=CARD).pack(anchor="w")
        nb = _textbox(note_row, height=3)
        if editing and bill.get("notes"):
            nb.insert("1.0", bill["notes"])
        nb.pack(fill="x", pady=(3, 0))

        def _save():
            if not fields["name"].get().strip():
                messagebox.showerror("Error", "Bill name is required.", parent=dlg)
                return
            entry = {k: fields[k].get().strip() for k in fields}
            entry["notes"] = nb.get("1.0", "end-1c").strip()
            bills = self.app.vault_data.setdefault("bills", [])
            if editing:
                entry["id"] = bill["id"]
                for i, b in enumerate(bills):
                    if b["id"] == bill["id"]:
                        bills[i] = entry
                        break
            else:
                entry["id"] = str(uuid.uuid4())
                bills.append(entry)
            self.app.save()
            dlg.destroy()
            self._show_bills()

        _btn(p, "Save", _save, font=FS, pady=12).pack(fill="x", pady=(14, 0))

    # ── Instructions ──────────────────────────────────────────────────────────

    def _show_instructions(self):
        self._view = "instructions"
        self._set_nav(self._nav_instructions)
        self._clear_content()
        self._section_header("Instructions")

        p = tk.Frame(self._content, bg=BG, padx=28, pady=18)
        p.pack(fill="both", expand=True)

        _lbl(p,
             "Write what your family or executor should know — accounts to close, "
             "wishes, important contacts, or anything else.",
             font=FSM, fg=MUTED, bg=BG, wraplength=720, justify="left"
             ).pack(anchor="w", pady=(0, 10))

        self._inst_box = tk.Text(
            p, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT,
            relief="flat", font=("Segoe UI", 11), bd=0,
            highlightthickness=1, highlightcolor=ACCENT,
            highlightbackground=BORDER, wrap="word")
        self._inst_box.insert("1.0", self.app.vault_data.get("instructions", ""))
        self._inst_box.pack(fill="both", expand=True)

        _btn(p, "Save Instructions", self._save_instructions,
             font=FS, pady=10).pack(anchor="e", pady=(12, 0))

    def _save_instructions(self):
        self.app.vault_data["instructions"] = self._inst_box.get("1.0", "end-1c").strip()
        self.app.save()
        messagebox.showinfo("Saved", "Instructions saved.", parent=self.root)

    # ── Export ────────────────────────────────────────────────────────────────

    def _do_export(self):
        mask = messagebox.askyesno(
            "Export — Password Visibility",
            "Mask passwords in the exported file?\n\n"
            "Yes → shown as  ●●●●●●●●\n"
            "No  → shown in plain text",
            parent=self.root,
        )
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Save Estate Vault Export",
            defaultextension=".txt",
            filetypes=[("Text file", "*.txt"), ("All files", "*.*")],
            initialfile="estate_vault_export.txt",
        )
        if not path:
            return
        try:
            export_vault_txt(self.app.vault_data, path, mask_passwords=mask)
            messagebox.showinfo("Exported", f"Vault exported to:\n{path}", parent=self.root)
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc), parent=self.root)


if __name__ == "__main__":
    VaultApp()
