# Estate Vault

A local, encrypted desktop app for organizing your digital estate — accounts, debts, assets, bills, and final instructions — so your family or executor has everything they need.

## Requirements

- Python 3.8+
- `cryptography` library

Install the dependency:

```
pip install cryptography
```

## Running

```
python Estate.py
```

## First Launch — Registration

On first run you'll be prompted to create your vault:

| Field | Notes |
|---|---|
| Username | Your display name for login |
| Master Password | At least 8 characters — used to encrypt all vault data |
| Confirm Password | Must match |
| Passcode | At least 4 characters — a short PIN or phrase for quick login |

Click **Create Vault**. Two files are created in the same folder:

- `auth.dat` — hashed credentials (never stores your password in plain text)
- `vault.dat` — AES-encrypted vault data

## Logging In

You can sign in with either:

- **Password tab** — your full master password
- **Passcode tab** — your shorter PIN/phrase (the app retrieves the master key internally)

## Sections

### Overview
A dashboard showing counts of accounts, debts, assets, and bills, with quick previews of recent entries and a snippet of your instructions.

### Identity
Store your full name, date of birth, SSN, and general notes. Click **Edit** to update.

### Accounts
Track online accounts, bank accounts, credit cards, investments, crypto, etc. Each entry holds:
- Type, Institution, Username, Password, Account Number, Notes

Use the **Generate Password** button to create a random 16-character password when adding an account.

### Debts
Record outstanding debts (mortgage, student loans, auto, medical, etc.) with:
- Type, Provider, Account Number, Balance, Monthly Payment, Notes

### Assets
Document valuable assets (property, vehicles, investments, jewelry, etc.) with:
- Type, Description, Estimated Value, Location, Notes

### Bills
Log recurring bills with:
- Name, Amount, Due Date, Frequency, Auto-Pay status, Notes

### Instructions
A free-text area for anything your family or executor should know — accounts to close, wishes, important contacts, etc. Click **Save Instructions** when done.

## Search

Use the search bar in the top-right to filter entries across Accounts, Debts, Assets, and Bills simultaneously.

## Exporting

Click **Export Vault** in the sidebar to save a plain-text summary of your entire vault. You'll be asked whether to mask or reveal passwords in the exported file.

The export is saved as a `.txt` file and is **not encrypted** — store it securely.

## Security Notes

- All vault data is encrypted with AES-128 (Fernet) using a key derived from your master password via PBKDF2-HMAC-SHA256 with 390,000 iterations.
- Passwords are never stored in plain text. Credential verification uses constant-time comparison to prevent timing attacks.
- The passcode login works by decrypting a locally stored (encrypted) copy of the master key — your master password is never stored directly.
- Data never leaves your machine; there is no network connection.

## File Locations

Both data files are stored in the same directory as `Estate.py`:

| File | Purpose |
|---|---|
| `auth.dat` | Hashed login credentials |
| `vault.dat` | Encrypted vault contents |

Back up these two files together to preserve your vault.
