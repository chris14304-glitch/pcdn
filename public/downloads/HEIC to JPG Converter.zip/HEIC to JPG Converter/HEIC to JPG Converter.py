import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinterdnd2 import DND_FILES, TkinterDnD
from pillow_heif import register_heif_opener
from PIL import Image

register_heif_opener()


def collect_heic_files(paths):
    """Return a list of .heic file paths from a mix of files and folders."""
    heic_files = []
    for path in paths:
        path = path.strip()
        if os.path.isdir(path):
            for f in os.listdir(path):
                if f.lower().endswith(".heic"):
                    heic_files.append(os.path.join(path, f))
        elif path.lower().endswith(".heic") and os.path.isfile(path):
            heic_files.append(path)
    return heic_files


def parse_drop_data(data):
    """Parse the raw drop data string into a list of paths (handles spaces in paths)."""
    # tkinterdnd2 wraps paths with spaces in curly braces
    paths = []
    raw = data.strip()
    i = 0
    while i < len(raw):
        if raw[i] == "{":
            end = raw.index("}", i)
            paths.append(raw[i + 1:end])
            i = end + 1
        elif raw[i] == " ":
            i += 1
        else:
            # unbraced token — read until next space or end
            end = raw.find(" ", i)
            if end == -1:
                paths.append(raw[i:])
                break
            paths.append(raw[i:end])
            i = end + 1
    return paths


class App(TkinterDnD.Tk):
    def __init__(self):
        super().__init__()
        self.title("Public Cyber Defense Network HEIC → JPG Converter")
        self.resizable(False, False)
        self.configure(bg="#1e1e2e")

        self._build_ui()

    def _build_ui(self):
        pad = dict(padx=16, pady=8)

        # ── Drop zone ─────────────────────────────────────────────────────────
        self.drop_frame = tk.Label(
            self,
            text="Drag & drop HEIC files or a folder here\n\nor click to browse",
            bg="#313244",
            fg="#cdd6f4",
            font=("Segoe UI", 13),
            relief="flat",
            cursor="hand2",
            width=52,
            height=8,
        )
        self.drop_frame.pack(padx=16, pady=(16, 8))
        self.drop_frame.drop_target_register(DND_FILES)
        self.drop_frame.dnd_bind("<<Drop>>", self._on_drop)
        self.drop_frame.bind("<Button-1>", self._on_browse)
        self.drop_frame.bind("<Enter>", lambda e: self.drop_frame.config(bg="#45475a"))
        self.drop_frame.bind("<Leave>", lambda e: self.drop_frame.config(bg="#313244"))

        # ── Output folder row ─────────────────────────────────────────────────
        row = tk.Frame(self, bg="#1e1e2e")
        row.pack(fill="x", **pad)

        tk.Label(row, text="Save to:", bg="#1e1e2e", fg="#a6adc8",
                 font=("Segoe UI", 10)).pack(side="left")

        self.out_var = tk.StringVar(value="Same folder as source")
        self.out_entry = tk.Entry(row, textvariable=self.out_var, width=36,
                                  bg="#313244", fg="#cdd6f4", insertbackground="#cdd6f4",
                                  relief="flat", font=("Segoe UI", 10))
        self.out_entry.pack(side="left", padx=(6, 4))

        tk.Button(row, text="Browse", command=self._choose_output,
                  bg="#45475a", fg="#cdd6f4", relief="flat",
                  font=("Segoe UI", 10), cursor="hand2",
                  activebackground="#585b70", activeforeground="#cdd6f4"
                  ).pack(side="left")

        # ── Log box ───────────────────────────────────────────────────────────
        self.log = tk.Text(self, height=10, width=58, state="disabled",
                           bg="#181825", fg="#a6e3a1", font=("Consolas", 9),
                           relief="flat", wrap="word")
        self.log.pack(padx=16, pady=(0, 8))

        # ── Status bar ────────────────────────────────────────────────────────
        self.status_var = tk.StringVar(value="Ready")
        tk.Label(self, textvariable=self.status_var, bg="#1e1e2e", fg="#6c7086",
                 font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=16, pady=(0, 12))

    # ── Event handlers ─────────────────────────────────────────────────────────

    def _on_drop(self, event):
        paths = parse_drop_data(event.data)
        self._start_conversion(paths)

    def _on_browse(self, event=None):
        paths = filedialog.askopenfilenames(
            title="Select HEIC files",
            filetypes=[("HEIC files", "*.heic *.HEIC"), ("All files", "*.*")],
        )
        if paths:
            self._start_conversion(list(paths))

    def _choose_output(self):
        folder = filedialog.askdirectory(title="Select output folder")
        if folder:
            self.out_var.set(folder)

    # ── Conversion ─────────────────────────────────────────────────────────────

    def _start_conversion(self, paths):
        threading.Thread(target=self._convert, args=(paths,), daemon=True).start()

    def _convert(self, paths):
        heic_files = collect_heic_files(paths)
        if not heic_files:
            self._log("No HEIC files found in the dropped items.\n", color="#f38ba8")
            return

        total = len(heic_files)
        self._log(f"Found {total} file(s) to convert...\n")
        self.status_var.set(f"Converting 0 / {total}…")

        success = 0
        for i, src in enumerate(heic_files, 1):
            out_dir = self.out_var.get()
            if out_dir == "Same folder as source":
                out_dir = os.path.dirname(src)
            os.makedirs(out_dir, exist_ok=True)

            basename = os.path.splitext(os.path.basename(src))[0] + ".jpg"
            dest = os.path.join(out_dir, basename)
            try:
                img = Image.open(src)
                img.save(dest, "JPEG")
                self._log(f"  ✓  {os.path.basename(src)}  →  {basename}\n")
                success += 1
            except Exception as exc:
                self._log(f"  ✗  {os.path.basename(src)}: {exc}\n", color="#f38ba8")

            self.status_var.set(f"Converting {i} / {total}…")

        self._log(f"\nDone — {success}/{total} converted.\n", color="#89dceb")
        self.status_var.set(f"Done — {success}/{total} converted.")

    def _log(self, msg, color="#a6e3a1"):
        def _write():
            self.log.configure(state="normal")
            self.log.insert("end", msg)
            self.log.tag_add(color, "end - %dc" % len(msg), "end")
            self.log.tag_config(color, foreground=color)
            self.log.see("end")
            self.log.configure(state="disabled")
        self.after(0, _write)


if __name__ == "__main__":
    app = App()
    app.mainloop()
