# HEIC to JPG Converter

A simple drag-and-drop desktop tool to convert HEIC images (iPhone/Apple format) to JPG.

---

## Requirements

- Python 3.8+
- The following Python packages:

```
pip install pillow pillow-heif tkinterdnd2
```

---

## How to Run

```
python "HEIC to JPG Converter.py"
```

---

## How to Use

### Converting Files

You have two ways to add files:

**Drag & Drop**
- Drag a single `.heic` file onto the drop zone
- Drag multiple `.heic` files at once
- Drag an entire folder — the tool will find all `.heic` files inside it

**Browse**
- Click the drop zone to open a file picker and select one or more `.heic` files

### Choosing Where to Save

By default, converted `.jpg` files are saved in the **same folder as the source file**.

To save to a different location:
1. Click the **Browse** button next to the "Save to:" field
2. Select your desired output folder

All converted files keep their original filename, just with a `.jpg` extension.

### Reading the Log

| Symbol | Meaning |
|--------|---------|
| ✓ | File converted successfully |
| ✗ | Conversion failed (error shown inline) |

The status bar at the bottom shows live progress and a final summary when complete.

---

## Notes

- Only `.heic` / `.HEIC` files are processed; other file types are ignored
- The output folder is created automatically if it does not exist
- Conversion runs in the background — the window stays responsive during large batches
